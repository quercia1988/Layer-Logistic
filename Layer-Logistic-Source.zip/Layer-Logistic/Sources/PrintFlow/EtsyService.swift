import Foundation
import Security

@MainActor
final class EtsyService: ObservableObject {
    @Published private(set) var isWorking = false
    @Published private(set) var message = "Non collegato"
    var hasToken: Bool { EtsyTokenKeychain().read() != nil }

    func saveToken(_ token: String) throws {
        try EtsyTokenKeychain().save(token.trimmingCharacters(in: .whitespacesAndNewlines)); message = "Token Etsy salvato"
    }
    func removeToken() { EtsyTokenKeychain().remove(); message = "Non collegato" }

    func publishDraft(product: ProductTemplate, settings: AppSettings) async -> Bool {
        guard let configuration = configuration(settings), let token = EtsyTokenKeychain().read(),
              let taxonomy = Int(settings.etsyTaxonomyID ?? ""), let shipping = Int(settings.etsyShippingProfileID ?? ""), let returns = Int(settings.etsyReturnPolicyID ?? "") else {
            message = "Completa API key, Shop ID, token e ID profili Etsy nelle Impostazioni."; return false
        }
        isWorking = true; defer { isWorking = false }
        do {
            let endpoint = URL(string: "https://openapi.etsy.com/v3/application/shops/\(configuration.shopID)/listings")!
            var request = authorizedRequest(url: endpoint, apiKey: configuration.apiKey, token: token)
            request.httpMethod = "POST"; request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
            let fields: [String: String] = [
                "quantity": "\(max(product.defaultQuantity, 1))", "title": product.listingTitle ?? product.name,
                "description": product.listingDescription ?? product.notes, "price": "\(max(product.finishingCost, 1))",
                "who_made": "i_did", "when_made": "made_to_order", "taxonomy_id": "\(taxonomy)",
                "shipping_profile_id": "\(shipping)", "return_policy_id": "\(returns)", "type": "physical"
            ]
            request.httpBody = fields.map { "\($0.key)=\($0.value.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "")" }.joined(separator: "&").data(using: .utf8)
            let (_, response) = try await URLSession.shared.data(for: request); try validate(response)
            message = "Bozza pubblicata su Etsy"; return true
        } catch { message = error.localizedDescription; return false }
    }

    func importOrders(settings: AppSettings, into store: OrderStore) async {
        guard let configuration = configuration(settings), let token = EtsyTokenKeychain().read() else { message = "Configura Etsy nelle Impostazioni."; return }
        isWorking = true; defer { isWorking = false }
        do {
            var components = URLComponents(string: "https://openapi.etsy.com/v3/application/shops/\(configuration.shopID)/receipts")!
            components.queryItems = [URLQueryItem(name: "was_paid", value: "true"), URLQueryItem(name: "was_shipped", value: "false"), URLQueryItem(name: "limit", value: "100")]
            let request = authorizedRequest(url: components.url!, apiKey: configuration.apiKey, token: token)
            let (data, response) = try await URLSession.shared.data(for: request); try validate(response)
            let envelope = try JSONDecoder().decode(EtsyReceipts.self, from: data)
            var imported = 0
            for receipt in envelope.results where !store.orders.contains(where: { $0.marketplace == .etsy && $0.storeOrderID == String(receipt.receiptID) }) {
                let name = receipt.name?.isEmpty == false ? receipt.name! : "Cliente Etsy"
                let customer = store.customers.first(where: { $0.name == name }) ?? Customer(name: name, company: "Etsy", email: receipt.buyerEmail ?? "", phone: "")
                if !store.customers.contains(where: { $0.id == customer.id }) { store.customers.append(customer) }
                let line = receipt.transactions?.first
                let total = receipt.grandtotal.map { Double($0.amount) / Double(max($0.divisor, 1)) } ?? 0
                let next = (store.orders.compactMap { Int($0.code.replacingOccurrences(of: "3D-", with: "")) }.max() ?? 1000) + 1
                store.add(PrintOrder(code: "3D-\(next)", title: line?.title ?? "Ordine Etsy", customerID: customer.id, material: .pla, color: "Da definire", quantity: line?.quantity ?? 1, price: total, dueDate: .now.addingTimeInterval(86400 * 7), status: .quote, notes: "Importato automaticamente da Etsy", marketplace: .etsy, storeOrderID: String(receipt.receiptID)))
                imported += 1
            }
            message = imported == 0 ? "Nessun nuovo ordine Etsy" : "Importati \(imported) ordini Etsy"
        } catch { message = error.localizedDescription }
    }

    private func configuration(_ settings: AppSettings) -> (apiKey: String, shopID: String)? {
        guard let key = settings.etsyAPIKey, !key.isEmpty, let shop = settings.etsyShopID, !shop.isEmpty else { return nil }
        return (key, shop)
    }
    private func authorizedRequest(url: URL, apiKey: String, token: String) -> URLRequest {
        var request = URLRequest(url: url); request.setValue(apiKey, forHTTPHeaderField: "x-api-key"); request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization"); return request
    }
    private func validate(_ response: URLResponse) throws { guard let http = response as? HTTPURLResponse, 200..<300 ~= http.statusCode else { throw EtsyError.requestFailed } }
}

private struct EtsyReceipts: Decodable {
    struct Money: Decodable { let amount: Int; let divisor: Int }
    struct Transaction: Decodable { let title: String?; let quantity: Int? }
    struct Receipt: Decodable {
        let receiptID: Int64; let name: String?; let buyerEmail: String?; let grandtotal: Money?; let transactions: [Transaction]?
        enum CodingKeys: String, CodingKey { case receiptID = "receipt_id", name, buyerEmail = "buyer_email", grandtotal, transactions }
    }
    let results: [Receipt]
}
private enum EtsyError: LocalizedError { case requestFailed; var errorDescription: String? { "Etsy ha rifiutato la richiesta. Verifica autorizzazione, permessi e dati della Developer App." } }
private struct EtsyTokenKeychain {
    private let service = "it.layerlogistic.etsy", account = "oauth-token"
    func read() -> String? { let q: [String: Any] = [kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:service,kSecAttrAccount as String:account,kSecReturnData as String:true,kSecMatchLimit as String:kSecMatchLimitOne]; var item:CFTypeRef?; guard SecItemCopyMatching(q as CFDictionary,&item)==errSecSuccess,let data=item as? Data else{return nil};return String(data:data,encoding:.utf8) }
    func save(_ value:String)throws{guard !value.isEmpty else{throw EtsyError.requestFailed};let key:[String:Any]=[kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:service,kSecAttrAccount as String:account];let data=Data(value.utf8);let status=SecItemUpdate(key as CFDictionary,[kSecValueData as String:data] as CFDictionary);if status==errSecItemNotFound{var add=key;add[kSecValueData as String]=data;guard SecItemAdd(add as CFDictionary,nil)==errSecSuccess else{throw EtsyError.requestFailed}}else if status != errSecSuccess{throw EtsyError.requestFailed}}
    func remove(){SecItemDelete([kSecClass as String:kSecClassGenericPassword,kSecAttrService as String:service,kSecAttrAccount as String:account] as CFDictionary)}
}
