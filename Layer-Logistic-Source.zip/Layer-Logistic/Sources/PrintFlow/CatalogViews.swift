import SwiftUI

struct ProductsView: View {
    @EnvironmentObject private var store: OrderStore
    @State private var editing: ProductTemplate?
    @State private var showNew = false
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                VStack(alignment: .leading, spacing: 4) { Text("Prodotti").font(.largeTitle.bold()); Text("Modelli riutilizzabili per creare preventivi in pochi secondi.").foregroundStyle(.secondary) }
                Spacer(); Button("Nuovo prodotto", systemImage: "plus") { showNew = true }.buttonStyle(.borderedProminent)
            }.padding(24)
            Table(store.products) {
                TableColumn("Prodotto") { p in VStack(alignment: .leading) { Text(p.name).fontWeight(.semibold); Text(p.sku).font(.caption).foregroundStyle(.secondary) } }
                TableColumn("Materiale") { Text($0.material.rawValue) }.width(90)
                TableColumn("Peso") { Text("\($0.weightGrams.formatted()) g") }.width(90)
                TableColumn("Stampa") { Text("\($0.printHours.formatted()) h") }.width(90)
                TableColumn("") { p in Button("Modifica") { editing = p }.buttonStyle(.borderless) }.width(75)
            }
        }.sheet(isPresented: $showNew) { ProductEditor(product: nil) }.sheet(item: $editing) { ProductEditor(product: $0) }
    }
}

struct ProductEditor: View {
    @EnvironmentObject private var store: OrderStore
    @EnvironmentObject private var listingAssistant: ListingAssistantService
    @EnvironmentObject private var etsy: EtsyService
    @Environment(\.dismiss) private var dismiss
    @State private var draft: ProductTemplate
    private let isNew: Bool
    init(product: ProductTemplate?) {
        isNew = product == nil
        _draft = State(initialValue: product ?? ProductTemplate(name: "", sku: "", material: .pla, color: "", weightGrams: 0, printHours: 0, defaultQuantity: 1, finishingCost: 0, notes: ""))
    }
    var body: some View {
        VStack(spacing: 16) {
            Text(isNew ? "Nuovo prodotto" : "Modifica prodotto").font(.title2.bold()).frame(maxWidth: .infinity, alignment: .leading)
            Form {
                TextField("Nome", text: $draft.name); TextField("SKU", text: $draft.sku)
                Picker("Materiale", selection: $draft.material) { ForEach(Material.allCases) { Text($0.rawValue).tag($0) } }
                TextField("Colore", text: $draft.color)
                TextField("Peso per pezzo (g)", value: $draft.weightGrams, format: .number)
                TextField("Ore per pezzo", value: $draft.printHours, format: .number)
                Stepper("Quantità predefinita: \(draft.defaultQuantity)", value: $draft.defaultQuantity, in: 1...999)
                TextField("Finitura (€)", value: $draft.finishingCost, format: .number)
                TextField("Note", text: $draft.notes)
                Section("Annuncio di vendita") {
                    HStack {
                        Button(listingAssistant.isGenerating ? "Generazione…" : "Genera con IA", systemImage: "sparkles") { generateListing() }
                            .buttonStyle(.borderedProminent).tint(CleanWorkshopTheme.purple).disabled(listingAssistant.isGenerating || draft.name.isEmpty)
                        if let error = listingAssistant.errorMessage {
                            Text(error).font(.caption).foregroundStyle(.red)
                            if error.localizedCaseInsensitiveContains("credito") {
                                Button("Aggiungi credito", systemImage: "creditcard.fill") { NSWorkspace.shared.open(URL(string: "https://platform.openai.com/settings/organization/billing")!) }
                            }
                        }
                    }
                    TextField("Titolo annuncio", text: Binding(get: { draft.listingTitle ?? "" }, set: { draft.listingTitle = $0 }))
                    TextEditor(text: Binding(get: { draft.listingDescription ?? "" }, set: { draft.listingDescription = $0 })).frame(height: 115)
                    HStack {
                        Button("Copia annuncio", systemImage: "doc.on.doc") { copyListing() }.disabled((draft.listingDescription ?? "").isEmpty)
                        Button("Apri Etsy", systemImage: "arrow.up.right.square") { copyListing(); NSWorkspace.shared.open(URL(string: "https://www.etsy.com/your/shops/me/listing-editor")!) }
                        Button(etsy.isWorking ? "Pubblicazione…" : "Pubblica bozza Etsy", systemImage: "paperplane.fill") { Task { _ = await etsy.publishDraft(product: draft, settings: store.settings) } }.disabled(etsy.isWorking || (draft.listingDescription ?? "").isEmpty)
                        Button("Apri Vinted", systemImage: "arrow.up.right.square") { copyListing(); NSWorkspace.shared.open(URL(string: "https://www.vinted.it/items/new")!) }
                    }
                    Text(etsy.message).font(.caption).foregroundStyle(.secondary)
                    Text("Per Vinted normale l’annuncio viene copiato e si apre la pagina ufficiale: Vinted non offre un’API pubblica per la pubblicazione automatica.").font(.caption).foregroundStyle(.secondary)
                }
            }
            HStack { if !isNew { Button("Elimina", role: .destructive) { store.products.removeAll { $0.id == draft.id }; dismiss() } }; Spacer(); Button("Annulla") { dismiss() }; Button("Salva") { save() }.buttonStyle(.borderedProminent).disabled(draft.name.isEmpty) }
        }.padding(24).frame(width: 620, height: 760)
    }
    private func save() { if let i = store.products.firstIndex(where: { $0.id == draft.id }) { store.products[i] = draft } else { store.products.append(draft) }; dismiss() }
    private func generateListing() { Task { if let result = await listingAssistant.generate(for: draft) { draft.listingTitle = result.title; draft.listingDescription = result.description } } }
    private func copyListing() { NSPasteboard.general.clearContents(); NSPasteboard.general.setString([draft.listingTitle, draft.listingDescription].compactMap { $0 }.joined(separator: "\n\n"), forType: .string) }
}

enum PackagingAdvisor {
    static func advice(length: Double, width: Double, height: Double, weightGrams: Double, fragile: Bool) -> String {
        let maxSide = max(length, max(width, height))
        var parts: [String] = []
        if maxSide <= 20 && weightGrams < 500 { parts.append("Usa una scatola a onda singola con 2-3 cm di margine.") }
        else { parts.append("Usa una scatola a doppia onda dimensionata con 4-5 cm di margine.") }
        if fragile { parts.append("Avvolgi il pezzo con pluriball e bloccalo su tutti i lati con riempitivo antiurto.") }
        else { parts.append("Proteggi spigoli e superfici con carta alveolare o pluriball leggero.") }
        if weightGrams > 2000 { parts.append("Rinforza fondo e chiusura con nastro telato a schema H.") }
        parts.append("Esegui la prova di scuotimento: il contenuto non deve muoversi.")
        return parts.joined(separator: " ")
    }
}
