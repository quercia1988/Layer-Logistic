import Foundation
import Security

@MainActor
final class ListingAssistantService: ObservableObject {
    @Published private(set) var isGenerating = false
    @Published private(set) var errorMessage: String?

    var isConfigured: Bool { OpenAIKeychain().read() != nil }

    func saveAPIKey(_ key: String) throws { try OpenAIKeychain().save(key.trimmingCharacters(in: .whitespacesAndNewlines)) }
    func removeAPIKey() { OpenAIKeychain().remove() }

    func generate(for product: ProductTemplate) async -> (title: String, description: String)? {
        guard let key = OpenAIKeychain().read(), !key.isEmpty else { errorMessage = "Configura la chiave OpenAI nelle Impostazioni."; return nil }
        isGenerating = true; errorMessage = nil
        defer { isGenerating = false }
        do {
            var request = URLRequest(url: URL(string: "https://api.openai.com/v1/responses")!)
            request.httpMethod = "POST"
            request.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            let input = """
            Crea un annuncio in italiano per un prodotto stampato in 3D. Restituisci esclusivamente JSON valido con le chiavi title e description. Titolo massimo 120 caratteri. Descrizione professionale, concreta, senza promesse non verificabili; specifica che colori e piccole imperfezioni di stratificazione possono variare. Dati: nome \(product.name); SKU \(product.sku); materiale \(product.material.rawValue); colore \(product.color); peso \(product.weightGrams) g; note \(product.notes).
            """
            let body: [String: Any] = ["model": "gpt-5.4-mini", "reasoning": ["effort": "low"], "input": input, "max_output_tokens": 700]
            request.httpBody = try JSONSerialization.data(withJSONObject: body)
            let (data, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse, 200..<300 ~= http.statusCode else {
                if let apiError = try? JSONDecoder().decode(OpenAIErrorEnvelope.self, from: data) {
                    throw AssistantError.api(code: apiError.error.code, message: apiError.error.message)
                }
                throw AssistantError.requestFailed
            }
            let api = try JSONDecoder().decode(ResponseEnvelope.self, from: data)
            guard let text = api.output.compactMap(\.content).flatMap({ $0 }).first(where: { $0.type == "output_text" })?.text,
                  let jsonData = stripCodeFence(text).data(using: .utf8),
                  let result = try? JSONDecoder().decode(ListingResult.self, from: jsonData) else { throw AssistantError.invalidResponse }
            return (result.title, result.description)
        } catch {
            errorMessage = error.localizedDescription
            return nil
        }
    }

    private func stripCodeFence(_ text: String) -> String {
        text.replacingOccurrences(of: "```json", with: "").replacingOccurrences(of: "```", with: "").trimmingCharacters(in: .whitespacesAndNewlines)
    }
}

private struct ListingResult: Decodable { let title: String; let description: String }
private struct ResponseEnvelope: Decodable {
    struct Output: Decodable { let content: [Content]? }
    struct Content: Decodable { let type: String; let text: String? }
    let output: [Output]
}
private struct OpenAIErrorEnvelope: Decodable { struct APIError: Decodable { let message: String; let code: String? }; let error: APIError }
private enum AssistantError: LocalizedError {
    case requestFailed, invalidResponse, api(code: String?, message: String)
    var errorDescription: String? {
        switch self {
        case .requestFailed: return "Impossibile contattare OpenAI. Controlla la connessione internet."
        case .invalidResponse: return "La risposta IA non contiene un annuncio valido."
        case let .api(code, message):
            let normalized = message.lowercased()
            if code == "insufficient_quota" || normalized.contains("no credits") || normalized.contains("quota") || normalized.contains("billing") { return "Credito API OpenAI esaurito. Aggiungi credito per continuare." }
            else if code == "invalid_api_key" { return "Chiave OpenAI non valida. Sostituiscila nelle Impostazioni." }
            else if code == "model_not_found" { return "Il modello IA non è disponibile per questo progetto." }
            else { return "Errore OpenAI: \(message)" }
        }
    }
}

private struct OpenAIKeychain {
    private let service = "it.layerlogistic.openai"
    private let account = "api-key"
    func read() -> String? {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: account, kSecReturnData as String: true, kSecMatchLimit as String: kSecMatchLimitOne]
        var item: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &item) == errSecSuccess, let data = item as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }
    func save(_ value: String) throws {
        guard !value.isEmpty else { throw AssistantError.invalidResponse }
        let key: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: account]
        let data = Data(value.utf8)
        let status = SecItemUpdate(key as CFDictionary, [kSecValueData as String: data] as CFDictionary)
        if status == errSecItemNotFound { var add = key; add[kSecValueData as String] = data; guard SecItemAdd(add as CFDictionary, nil) == errSecSuccess else { throw AssistantError.requestFailed } }
        else if status != errSecSuccess { throw AssistantError.requestFailed }
    }
    func remove() { SecItemDelete([kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: account] as CFDictionary) }
}
