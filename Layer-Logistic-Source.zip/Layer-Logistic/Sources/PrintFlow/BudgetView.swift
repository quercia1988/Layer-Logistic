import SwiftUI

struct BudgetView: View {
    @EnvironmentObject private var store: OrderStore
    @State private var showExpense = false
    @State private var editing: BusinessExpense?
    @State private var selectedYear = Calendar.current.component(.year, from: .now)
    @State private var newAllocationName = ""

    private var yearExpenses: [BusinessExpense] { store.expenses.filter { Calendar.current.component(.year, from: $0.date) == selectedYear } }
    private var revenue: Double { store.orders.filter { $0.status == .delivered && Calendar.current.component(.year, from: $0.createdAt) == selectedYear }.reduce(0) { $0 + $1.price } }
    private var costs: Double { yearExpenses.reduce(0) { $0 + $1.amount } }
    private var directCosts: Double { completedOrders.reduce(0) { $0 + store.quote(for: $1).directCosts } }
    private var grossProfit: Double { completedOrders.reduce(0) { $0 + store.profit(for: $1) } }
    private var completedOrders: [PrintOrder] { store.orders.filter { $0.status == .delivered && Calendar.current.component(.year, from: $0.createdAt) == selectedYear } }
    private var allocationNames: [String] { store.settings.revenueAllocationCategories ?? ExpenseCategory.allCases.map(\.rawValue) }
    private var allocationTotal: Double { allocationNames.reduce(0) { $0 + percentage(for: $1) } }
    private var totalBudget: Double { allocationNames.reduce(0) { $0 + allocatedRevenue(for: $1) } }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                HStack {
                    VStack(alignment: .leading, spacing: 4) { Text("Budget aziendale").font(.largeTitle.bold()); Text("Controllo ricavi, costi di gestione e investimenti.").foregroundStyle(.secondary) }
                    Spacer()
                    Picker("Anno", selection: $selectedYear) { ForEach((selectedYear - 3)...(selectedYear + 1), id: \.self) { Text(String($0)).tag($0) } }.frame(width: 110)
                    Button("Registra spesa", systemImage: "plus") { showExpense = true }.buttonStyle(.borderedProminent)
                }
                HStack(spacing: 14) {
                    BudgetMetric(title: "Ricavi", value: revenue, icon: "arrow.up.circle.fill", color: .green)
                    BudgetMetric(title: "Costi diretti", value: directCosts, icon: "wrench.and.screwdriver.fill", color: .orange)
                    BudgetMetric(title: "Guadagno lordo", value: grossProfit, icon: "chart.line.uptrend.xyaxis", color: grossProfit >= 0 ? .green : .red)
                    BudgetMetric(title: "Utile dopo spese", value: grossProfit - costs, icon: "banknote.fill", color: grossProfit >= costs ? .purple : .red)
                }
                HStack(spacing: 16) {
                    Image(systemName: "percent").font(.title2.bold()).foregroundStyle(.green)
                        .frame(width: 46, height: 46).background(.green.opacity(0.10)).clipShape(RoundedRectangle(cornerRadius: 12))
                    VStack(alignment: .leading, spacing: 3) {
                        Text("Margine di utile").font(.headline)
                        Text("Percentuale applicata ai costi diretti di ogni preventivo, prima dell’IVA.").font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                    TextField("Margine", value: profitMargin, format: .number.precision(.fractionLength(0...2)))
                        .textFieldStyle(.roundedBorder).frame(width: 90)
                    Text("%").font(.headline).foregroundStyle(.secondary)
                    Stepper("", value: profitMargin, in: 0...500, step: 1).labelsHidden()
                }.padding(16).background(Color.green.opacity(0.06)).clipShape(RoundedRectangle(cornerRadius: 14)).overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.green.opacity(0.20)))
                HStack(spacing: 12) {
                    Image(systemName: allocationTotal == 100 ? "checkmark.circle.fill" : "exclamationmark.triangle.fill").foregroundStyle(allocationTotal == 100 ? .green : .orange)
                    VStack(alignment: .leading, spacing: 3) {
                        Text("Ripartizione automatica degli incassi: \(allocationTotal.formatted())%").fontWeight(.semibold)
                        Text(allocationTotal == 100 ? "Ogni vendita completata viene distribuita integralmente tra le categorie." : "Modifica le percentuali: la somma deve essere 100%.").font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                    Button("Ripristina voci") { store.settings.revenueAllocationCategories = ExpenseCategory.allCases.map(\.rawValue); store.settings.revenueAllocationPercentages = defaultAllocations }
                }.padding(14).background((allocationTotal == 100 ? Color.green : Color.orange).opacity(0.08)).clipShape(RoundedRectangle(cornerRadius: 12)).overlay(RoundedRectangle(cornerRadius: 12).stroke((allocationTotal == 100 ? Color.green : Color.orange).opacity(0.2)))
                VStack(alignment: .leading, spacing: 14) {
                    HStack { Text("Ripartizione incassi e spese").font(.title2.bold()); Spacer(); Text("Incassi allocati: \(totalBudget.euro)").foregroundStyle(.secondary) }
                    HStack {
                        TextField("Nuova voce, ad esempio Marketing", text: $newAllocationName)
                            .textFieldStyle(.roundedBorder)
                        Button("Aggiungi voce", systemImage: "plus") { addAllocation() }
                            .buttonStyle(.borderedProminent).disabled(newAllocationName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                    }
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 270), spacing: 14)], spacing: 14) {
                        ForEach(allocationNames, id: \.self) { name in
                            CategoryBudgetCard(name: name, symbol: symbol(for: name), spent: spent(for: name), revenue: revenue,
                                               percentage: percentageBinding(for: name),
                                               rename: { renameAllocation(name, to: $0) }, delete: { deleteAllocation(name) })
                        }
                    }
                }
                VStack(alignment: .leading, spacing: 12) {
                    Text("Movimenti").font(.title2.bold())
                    if yearExpenses.isEmpty { ContentUnavailableView("Nessuna spesa registrata", systemImage: "tray", description: Text("Aggiungi ricambi, forniture e altri costi di gestione.")) }
                    ForEach(yearExpenses.sorted { $0.date > $1.date }) { expense in
                        HStack(spacing: 14) {
                            Image(systemName: expense.category.symbol).frame(width: 38, height: 38).background(.purple.opacity(0.09)).foregroundStyle(.purple).clipShape(RoundedRectangle(cornerRadius: 10))
                            VStack(alignment: .leading, spacing: 3) { Text(expense.title).fontWeight(.semibold); Text("\(expense.category.rawValue) · \(expense.supplier)").font(.caption).foregroundStyle(.secondary) }
                            Spacer(); Text(expense.date, format: .dateTime.day().month(.abbreviated).year()).foregroundStyle(.secondary); Text(expense.amount.euro).fontWeight(.semibold).frame(width: 95, alignment: .trailing); Button("Modifica") { editing = expense }.buttonStyle(.borderless)
                        }.padding(13).background(Color(nsColor: .textBackgroundColor)).clipShape(RoundedRectangle(cornerRadius: 12)).overlay(RoundedRectangle(cornerRadius: 12).stroke(.secondary.opacity(0.13)))
                    }
                }
            }.padding(24)
        }.background(Color(nsColor: .windowBackgroundColor))
        .sheet(isPresented: $showExpense) { ExpenseEditor(expense: nil) }
        .sheet(item: $editing) { ExpenseEditor(expense: $0) }
    }

    private func spent(for name: String) -> Double { yearExpenses.filter { $0.category.rawValue == name }.reduce(0) { $0 + $1.amount } }
    private var profitMargin: Binding<Double> { Binding(
        get: { store.settings.profitMarginPercent ?? 30 },
        set: { store.settings.profitMarginPercent = min(max($0, 0), 500) }
    ) }
    private func allocatedRevenue(for name: String) -> Double { revenue * percentage(for: name) / 100 }
    private func percentage(for name: String) -> Double { store.settings.revenueAllocationPercentages?[name] ?? defaultAllocations[name] ?? 0 }
    private func percentageBinding(for name: String) -> Binding<Double> { Binding(get: { percentage(for: name) }, set: { value in var all = store.settings.revenueAllocationPercentages ?? defaultAllocations; all[name] = max(0, value); store.settings.revenueAllocationPercentages = all }) }
    private func symbol(for name: String) -> String { ExpenseCategory.allCases.first { $0.rawValue == name }?.symbol ?? "folder.fill" }
    private func addAllocation() {
        let name = newAllocationName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty, !allocationNames.contains(where: { $0.localizedCaseInsensitiveCompare(name) == .orderedSame }) else { return }
        store.settings.revenueAllocationCategories = allocationNames + [name]
        var values = store.settings.revenueAllocationPercentages ?? defaultAllocations; values[name] = 0; store.settings.revenueAllocationPercentages = values
        newAllocationName = ""
    }
    private func deleteAllocation(_ name: String) {
        store.settings.revenueAllocationCategories = allocationNames.filter { $0 != name }
        var values = store.settings.revenueAllocationPercentages ?? defaultAllocations; values.removeValue(forKey: name); store.settings.revenueAllocationPercentages = values
    }
    private func renameAllocation(_ oldName: String, to proposed: String) {
        let name = proposed.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty, name != oldName, !allocationNames.contains(where: { $0 != oldName && $0.localizedCaseInsensitiveCompare(name) == .orderedSame }) else { return }
        store.settings.revenueAllocationCategories = allocationNames.map { $0 == oldName ? name : $0 }
        var values = store.settings.revenueAllocationPercentages ?? defaultAllocations; values[name] = values.removeValue(forKey: oldName) ?? 0; store.settings.revenueAllocationPercentages = values
    }
    private var defaultAllocations: [String: Double] {
        [ExpenseCategory.spareParts.rawValue: 10, ExpenseCategory.supplies.rawValue: 20, ExpenseCategory.maintenance.rawValue: 10, ExpenseCategory.energy.rawValue: 10, ExpenseCategory.packaging.rawValue: 10, ExpenseCategory.software.rawValue: 5, ExpenseCategory.printerReplacement.rawValue: 25, ExpenseCategory.other.rawValue: 10]
    }
}

struct BudgetMetric: View {
    let title: String, value: Double, icon: String
    let color: Color
    var body: some View { VStack(alignment: .leading, spacing: 10) { Image(systemName: icon).font(.title2).foregroundStyle(color); Text(value.euro).font(.title2.bold()).minimumScaleFactor(0.7).lineLimit(1); Text(title).foregroundStyle(.secondary) }.padding(17).frame(maxWidth: .infinity, alignment: .leading).background(Color(nsColor: .textBackgroundColor)).clipShape(RoundedRectangle(cornerRadius: 14)).overlay(RoundedRectangle(cornerRadius: 14).stroke(.secondary.opacity(0.14))) }
}

struct CategoryBudgetCard: View {
    let name: String, symbol: String, spent: Double, revenue: Double
    @Binding var percentage: Double
    let rename: (String) -> Void
    let delete: () -> Void
    @State private var editingName = ""
    @State private var isRenaming = false
    private var allocation: Double { revenue * percentage / 100 }
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                if isRenaming {
                    TextField("Nome voce", text: $editingName).textFieldStyle(.roundedBorder)
                        .onSubmit { rename(editingName); isRenaming = false }
                } else { Label(name, systemImage: symbol).fontWeight(.semibold) }
                Spacer()
                Menu { Button("Rinomina", systemImage: "pencil") { editingName = name; isRenaming = true }; Button("Elimina voce", systemImage: "trash", role: .destructive, action: delete) } label: { Image(systemName: "ellipsis.circle") }.menuStyle(.borderlessButton).frame(width: 24)
            }
            HStack(alignment: .firstTextBaseline) { Text(allocation.euro).font(.title3.bold()); Text("dagli incassi").font(.caption).foregroundStyle(.secondary); Spacer(); TextField("%", value: $percentage, format: .number).textFieldStyle(.roundedBorder).frame(width: 55); Text("%").foregroundStyle(.secondary) }
            ProgressView(value: allocation > 0 ? min(spent / allocation, 1) : 0).tint(spent > allocation ? .red : .purple)
            HStack { Text("Speso \(spent.euro)").font(.caption).foregroundStyle(.secondary); Spacer(); Text("Residuo \((allocation - spent).euro)").font(.caption).foregroundStyle(allocation >= spent ? .green : .red) }
        }.padding(15).background(Color(nsColor: .textBackgroundColor)).clipShape(RoundedRectangle(cornerRadius: 13)).overlay(RoundedRectangle(cornerRadius: 13).stroke(.secondary.opacity(0.14)))
    }
}

struct ExpenseEditor: View {
    @EnvironmentObject private var store: OrderStore
    @Environment(\.dismiss) private var dismiss
    @State private var draft: BusinessExpense
    private let isNew: Bool
    init(expense: BusinessExpense?) { isNew = expense == nil; _draft = State(initialValue: expense ?? BusinessExpense(date: .now, title: "", category: .supplies, amount: 0, supplier: "", notes: "")) }
    var body: some View {
        VStack(spacing: 16) {
            Text(isNew ? "Registra spesa" : "Modifica spesa").font(.title2.bold()).frame(maxWidth: .infinity, alignment: .leading)
            Form { TextField("Descrizione", text: $draft.title); Picker("Categoria", selection: $draft.category) { ForEach(ExpenseCategory.allCases) { Label($0.rawValue, systemImage: $0.symbol).tag($0) } }; TextField("Importo (€)", value: $draft.amount, format: .number); DatePicker("Data", selection: $draft.date, displayedComponents: .date); TextField("Fornitore", text: $draft.supplier); TextEditor(text: $draft.notes).frame(height: 70) }
            HStack { if !isNew { Button("Elimina", role: .destructive) { store.expenses.removeAll { $0.id == draft.id }; dismiss() } }; Spacer(); Button("Annulla") { dismiss() }; Button("Salva") { save() }.buttonStyle(.borderedProminent).disabled(draft.title.isEmpty || draft.amount <= 0) }
        }.padding(24).frame(width: 500, height: 500)
    }
    private func save() { if let i = store.expenses.firstIndex(where: { $0.id == draft.id }) { store.expenses[i] = draft } else { store.expenses.append(draft) }; dismiss() }
}
