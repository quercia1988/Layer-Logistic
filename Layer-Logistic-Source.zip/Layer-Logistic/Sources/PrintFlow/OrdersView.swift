import SwiftUI

enum OrderBucket: String, CaseIterable, Identifiable {
    case waiting = "In attesa"
    case todo = "Da fare"
    case production = "In stampa"
    case fulfilled = "Evasi"
    case completed = "Completati"
    var id: String { rawValue }
    func contains(_ status: OrderStatus) -> Bool {
        switch self {
        case .waiting: status == .quote
        case .todo: status == .confirmed
        case .production: status == .printing || status == .finishing
        case .fulfilled: status == .ready
        case .completed: status == .delivered
        }
    }
}

struct OrdersView: View {
    @EnvironmentObject private var store: OrderStore
    @EnvironmentObject private var etsy: EtsyService
    @Binding var showNewOrder: Bool
    let bucket: OrderBucket
    var marketplacesOnly = false
    @State private var search = ""
    @State private var orderToEdit: PrintOrder?

    private var visible: [PrintOrder] {
        store.orders.filter { order in
            bucket.contains(order.status) && (!marketplacesOnly || (order.marketplace ?? .direct) != .direct) &&
            (search.isEmpty || order.title.localizedCaseInsensitiveContains(search) || order.code.localizedCaseInsensitiveContains(search) || (store.customer(for: order)?.company.localizedCaseInsensitiveContains(search) ?? false))
        }
    }

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                VStack(alignment: .leading, spacing: 3) { Text(marketplacesOnly ? "Ordini store" : bucket.rawValue).font(.largeTitle.bold()); Text(marketplacesOnly ? "In arrivo da Etsy e Vinted" : "Gestione ordini").foregroundStyle(.secondary) }
                Text("\(visible.count)").foregroundStyle(.secondary)
                Spacer()
                if marketplacesOnly {
                    Button(etsy.isWorking ? "Sincronizzazione…" : "Ricevi ordini Etsy", systemImage: "arrow.triangle.2.circlepath") { Task { await etsy.importOrders(settings: store.settings, into: store) } }.disabled(etsy.isWorking)
                }
                Button("Nuovo ordine", systemImage: "plus") { showNewOrder = true }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.large)
                    .tint(CleanWorkshopTheme.purple)
            }.padding(24)
            if marketplacesOnly { Text(etsy.message).font(.caption).foregroundStyle(.secondary).frame(maxWidth: .infinity, alignment: .leading).padding(.horizontal, 24).padding(.bottom, 8) }
            List {
                ForEach(visible) { order in
                    OrderRow(order: order)
                        .padding(.vertical, 5)
                        .contentShape(Rectangle())
                        .onTapGesture { orderToEdit = order }
                        .contextMenu {
                            Button("Modifica", systemImage: "pencil") { orderToEdit = order }
                        }
                }
                .onDelete { store.delete(at: $0, from: visible) }
            }.searchable(text: $search, prompt: "Cerca codice, ordine o cliente")
        }
        .sheet(item: $orderToEdit) { EditOrderView(order: $0) }
    }
}

struct CustomersView: View {
    @EnvironmentObject private var store: OrderStore
    @State private var selectedCustomer: Customer?
    @State private var showNewCustomer = false
    @State private var search = ""
    private var visibleCustomers: [Customer] { store.customers.filter { search.isEmpty || $0.name.localizedCaseInsensitiveContains(search) || $0.company.localizedCaseInsensitiveContains(search) || $0.email.localizedCaseInsensitiveContains(search) } }
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                VStack(alignment: .leading, spacing: 3) { Text("Clienti").font(.largeTitle.bold()); Text("Rubrica e schede contatto").foregroundStyle(.secondary) }
                Spacer()
                Button("Nuovo contatto", systemImage: "person.badge.plus") { showNewCustomer = true }.buttonStyle(.borderedProminent).tint(.purple)
            }.padding(24)
            List(visibleCustomers) { customer in
                HStack(spacing: 14) {
                    Text(customer.name.prefix(1)).font(.headline).frame(width: 38, height: 38).background(.purple.opacity(0.14)).foregroundStyle(.purple).clipShape(Circle())
                    VStack(alignment: .leading) {
                        Text(customer.name).fontWeight(.semibold)
                        Text(customer.company).font(.caption).foregroundStyle(.secondary)
                    }
                    Spacer()
                    VStack(alignment: .leading, spacing: 2) { Text(customer.email.isEmpty ? "Email non inserita" : customer.email); Text(customer.phone.isEmpty ? "Telefono non inserito" : customer.phone).font(.caption) }.foregroundStyle(.secondary).frame(width: 220, alignment: .leading)
                    Text("\(store.orders.filter { $0.customerID == customer.id }.count) ordini").foregroundStyle(.secondary).frame(width: 80)
                    Image(systemName: "chevron.right").foregroundStyle(.tertiary)
                }.padding(.vertical, 7)
                .contentShape(Rectangle()).onTapGesture { selectedCustomer = customer }
                .contextMenu { Button("Apri scheda contatto", systemImage: "person.text.rectangle") { selectedCustomer = customer } }
            }
        }.searchable(text: $search, prompt: "Cerca cliente, azienda o email")
        .sheet(item: $selectedCustomer) { CustomerContactCard(customer: $0) }
        .sheet(isPresented: $showNewCustomer) { CustomerContactCard(customer: nil) }
    }
}

struct CustomerContactCard: View {
    @EnvironmentObject private var store: OrderStore
    @Environment(\.dismiss) private var dismiss
    @State private var draft: Customer
    private let isNew: Bool

    init(customer: Customer?) {
        isNew = customer == nil
        _draft = State(initialValue: customer ?? Customer(name: "", company: "", email: "", phone: ""))
    }

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 14) {
                Text(draft.name.isEmpty ? "?" : String(draft.name.prefix(1))).font(.title.bold()).frame(width: 58, height: 58).background(.purple.opacity(0.14)).foregroundStyle(.purple).clipShape(Circle())
                VStack(alignment: .leading, spacing: 3) { Text(isNew ? "Nuovo contatto" : draft.name).font(.title2.bold()); Text(draft.company.isEmpty ? "Cliente" : draft.company).foregroundStyle(.secondary) }
                Spacer()
                if !draft.email.isEmpty { Button("Email", systemImage: "envelope.fill") { openEmail() } }
                if !draft.phone.isEmpty { Button("Chiama", systemImage: "phone.fill") { openPhone() } }
            }.padding(22)
            Divider()
            Form {
                Section("Contatto") {
                    TextField("Nome e cognome", text: $draft.name)
                    TextField("Azienda", text: $draft.company)
                    TextField("Email", text: $draft.email)
                    TextField("Telefono", text: $draft.phone)
                }
                Section("Indirizzo") {
                    TextField("Via e numero civico", text: optionalBinding(\.address))
                    HStack { TextField("CAP", text: optionalBinding(\.postalCode)).frame(width: 90); TextField("Città", text: optionalBinding(\.city)); TextField("Provincia", text: optionalBinding(\.province)).frame(width: 100) }
                }
                Section("Dati fiscali") {
                    TextField("Partita IVA", text: optionalBinding(\.vatNumber))
                    TextField("Codice fiscale", text: optionalBinding(\.taxCode))
                }
                Section("Note") { TextEditor(text: optionalBinding(\.notes)).frame(height: 80) }
                if !isNew {
                    Section("Attività") {
                        LabeledContent("Ordini associati", value: "\(store.orders.filter { $0.customerID == draft.id }.count)")
                        LabeledContent("Totale ordini", value: store.orders.filter { $0.customerID == draft.id }.reduce(0) { $0 + $1.price }.euro)
                    }
                }
            }.formStyle(.grouped)
            Divider()
            HStack {
                if !isNew { Button("Elimina", role: .destructive) { deleteCustomer() }.disabled(store.orders.contains { $0.customerID == draft.id }).help("Un cliente con ordini associati non può essere eliminato") }
                Spacer(); Button("Annulla") { dismiss() }; Button("Salva") { save() }.buttonStyle(.borderedProminent).tint(.purple).disabled(draft.name.trimmingCharacters(in: .whitespaces).isEmpty)
            }.padding(18)
        }.frame(width: 620, height: 700)
    }

    private func optionalBinding(_ keyPath: WritableKeyPath<Customer, String?>) -> Binding<String> { Binding(get: { draft[keyPath: keyPath] ?? "" }, set: { draft[keyPath: keyPath] = $0.isEmpty ? nil : $0 }) }
    private func save() { if let index = store.customers.firstIndex(where: { $0.id == draft.id }) { store.customers[index] = draft } else { store.customers.append(draft) }; dismiss() }
    private func deleteCustomer() { guard !store.orders.contains(where: { $0.customerID == draft.id }) else { return }; store.customers.removeAll { $0.id == draft.id }; dismiss() }
    private func openEmail() { if let encoded = draft.email.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed), let url = URL(string: "mailto:\(encoded)") { NSWorkspace.shared.open(url) } }
    private func openPhone() { let number = draft.phone.filter { $0.isNumber || $0 == "+" }; if let url = URL(string: "tel:\(number)") { NSWorkspace.shared.open(url) } }
}
