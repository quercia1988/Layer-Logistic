import Foundation
import SwiftUI

struct ProductionPlanItem: Identifiable {
    let id: UUID
    let order: PrintOrder
    let printer: PrinterProfile?
    let plannedStart: Date
    let plannedFinish: Date
    let hours: Double
    let isAtRisk: Bool
    let urgencyScore: Double
}

struct MaintenanceAdvice: Identifiable {
    enum Priority: Int { case urgent = 0, soon = 1, routine = 2 }
    let id: UUID
    let printer: PrinterProfile
    let priority: Priority
    let title: String
    let timing: String
    let tasks: [String]
    let projectedHoursRemaining: Double
}

enum ProductionPlanner {
    static func makePlan(orders: [PrintOrder], printers: [PrinterProfile], now: Date = .now) -> [ProductionPlanItem] {
        let candidates = orders.filter { [.confirmed, .printing, .finishing].contains($0.status) }
            .sorted { lhs, rhs in
                if lhs.status == .printing && rhs.status != .printing { return true }
                if rhs.status == .printing && lhs.status != .printing { return false }
                return lhs.dueDate < rhs.dueDate
            }
        var available = Dictionary(uniqueKeysWithValues: printers.map { ($0.id, now) })
        var result: [ProductionPlanItem] = []
        for order in candidates {
            let duration = order.status == .finishing ? 1 : max(0.25, (order.printHours ?? 0) * Double(max(order.quantity, 1)))
            let selected: PrinterProfile?
            if let id = order.printerID, let exact = printers.first(where: { $0.id == id }) { selected = exact }
            else { selected = printers.min { (available[$0.id] ?? now) < (available[$1.id] ?? now) } }
            let start = order.status == .printing ? now : (selected.flatMap { available[$0.id] } ?? now)
            let finish = start.addingTimeInterval(duration * 3600)
            if let selected { available[selected.id] = finish }
            let slackHours = order.dueDate.timeIntervalSince(finish) / 3600
            let risk = finish > order.dueDate
            result.append(ProductionPlanItem(id: order.id, order: order, printer: selected, plannedStart: start, plannedFinish: finish, hours: duration, isAtRisk: risk, urgencyScore: 100 - slackHours))
        }
        return result.sorted { $0.plannedStart < $1.plannedStart }
    }

    static func maintenancePlan(printers: [PrinterProfile], productionPlan: [ProductionPlanItem]) -> [MaintenanceAdvice] {
        printers.map { printer in
            let scheduled = productionPlan.filter { $0.printer?.id == printer.id }.reduce(0) { $0 + $1.hours }
            let remaining = printer.hoursUntilMaintenance - scheduled
            let interval = max(printer.maintenanceIntervalHours ?? 500, 1)
            let priority: MaintenanceAdvice.Priority = printer.hoursUntilMaintenance <= 0 || remaining <= 0 ? .urgent : remaining <= max(50, interval * 0.10) ? .soon : .routine
            let title = priority == .urgent ? "Manutenzione necessaria" : priority == .soon ? "Manutenzione da programmare" : "Controllo preventivo"
            let timing: String
            if printer.hoursUntilMaintenance <= 0 { timing = "Prima di avviare una nuova stampa" }
            else if remaining <= 0 { timing = "Prima di completare i lavori già pianificati" }
            else if priority == .soon { timing = "Entro \(max(remaining, 0).formatted(.number.precision(.fractionLength(0)))) ore di stampa" }
            else { timing = "Tra circa \(max(remaining, 0).formatted(.number.precision(.fractionLength(0)))) ore di stampa" }
            return MaintenanceAdvice(id: printer.id, printer: printer, priority: priority, title: title, timing: timing, tasks: maintenanceTasks(for: printer), projectedHoursRemaining: remaining)
        }.sorted { $0.priority.rawValue == $1.priority.rawValue ? $0.projectedHoursRemaining < $1.projectedHoursRemaining : $0.priority.rawValue < $1.priority.rawValue }
    }

    private static func maintenanceTasks(for printer: PrinterProfile) -> [String] {
        let maker = printer.manufacturer.lowercased(), model = printer.model.lowercased()
        var tasks = ["Pulisci piano di stampa e ugello", "Controlla tensione cinghie, viti e cablaggi", "Rimuovi polvere da ventole e prese d’aria"]
        if maker.contains("bambu") {
            tasks += model.contains("a1") ? ["Pulisci e lubrifica le guide lineari X/Y/Z", "Controlla tubo PTFE e taglierina filamento"] : ["Pulisci le barre in carbonio X senza lubrificarle", "Lubrifica le viti Z e controlla PTFE/AMS"]
        } else if maker.contains("prusa") {
            tasks += ["Pulisci e lubrifica leggermente aste e cuscinetti", "Controlla ingranaggi estrusore e sensore filamento"]
        } else if maker.contains("anycubic") || model.contains("kobra") {
            tasks += ["Controlla ruote V-slot e eccentrici senza serrarli troppo", "Pulisci e lubrifica le viti Z", "Verifica estrusore e tubo PTFE"]
        } else if maker.contains("creality") {
            tasks += ["Controlla ruote V-slot, eccentrici e cinghie", "Lubrifica la vite Z e verifica l’estrusore"]
        } else {
            tasks += ["Lubrifica guide e viti secondo il manuale del produttore", "Controlla estrusore e percorso filamento"]
        }
        if let custom = printer.maintenanceNotes, !custom.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { tasks.insert(custom, at: 0) }
        return tasks
    }
}

struct ProductionAssistantView: View {
    @EnvironmentObject private var store: OrderStore
    private var plan: [ProductionPlanItem] { ProductionPlanner.makePlan(orders: store.orders, printers: store.printers) }
    private var risks: [ProductionPlanItem] { plan.filter(\.isAtRisk) }
    private var maintenance: [MaintenanceAdvice] { ProductionPlanner.maintenancePlan(printers: store.printers, productionPlan: plan) }
    private var maintenanceDue: [MaintenanceAdvice] { maintenance.filter { $0.priority != .routine } }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                HStack {
                    VStack(alignment: .leading, spacing: 5) {
                        Text("Assistente produzione").font(.largeTitle.bold())
                        Text("Piano ottimizzato per rispettare le scadenze, aggiornato con i dati degli ordini.").foregroundStyle(.secondary)
                    }
                    Spacer()
                    Image(systemName: "sparkles").font(.system(size: 28, weight: .semibold)).foregroundStyle(.white).frame(width: 58, height: 58).background(LinearGradient(colors: [.purple, .indigo], startPoint: .topLeading, endPoint: .bottomTrailing)).clipShape(RoundedRectangle(cornerRadius: 17))
                }
                if let next = plan.first {
                    VStack(alignment: .leading, spacing: 10) {
                        Label("PROSSIMA AZIONE CONSIGLIATA", systemImage: "bolt.fill").font(.caption.bold()).foregroundStyle(.purple)
                        Text(next.order.status == .printing ? "Continua \(next.order.title)" : "Avvia \(next.order.title)").font(.title2.bold())
                        Text("Su \(next.printer?.displayName ?? "una stampante disponibile") · \(next.hours.formatted(.number.precision(.fractionLength(1)))) ore stimate · consegna \(next.order.dueDate.formatted(date: .abbreviated, time: .shortened))")
                            .foregroundStyle(.secondary)
                    }.padding(20).frame(maxWidth: .infinity, alignment: .leading).background(LinearGradient(colors: [.purple.opacity(0.13), .indigo.opacity(0.06)], startPoint: .topLeading, endPoint: .bottomTrailing)).clipShape(RoundedRectangle(cornerRadius: 18)).overlay(RoundedRectangle(cornerRadius: 18).stroke(.purple.opacity(0.22)))
                }
                HStack(spacing: 14) {
                    MetricCard(title: "Lavori pianificati", value: "\(plan.count)", icon: "calendar", color: .blue)
                    MetricCard(title: "A rischio ritardo", value: "\(risks.count)", icon: "exclamationmark.triangle.fill", color: risks.isEmpty ? .green : .red)
                    MetricCard(title: "Ore macchina", value: "\(plan.reduce(0) { $0 + $1.hours }.formatted(.number.precision(.fractionLength(1))))", icon: "clock.fill", color: .purple)
                    MetricCard(title: "Manutenzioni", value: "\(maintenanceDue.count)", icon: "wrench.and.screwdriver.fill", color: maintenanceDue.isEmpty ? .green : .orange)
                }
                VStack(alignment: .leading, spacing: 12) {
                    HStack { Text("Manutenzione consigliata").font(.title2.bold()); Spacer(); Text("Calcolata sulle ore pianificate").font(.caption).foregroundStyle(.secondary) }
                    if maintenanceDue.isEmpty { Label("Nessuna manutenzione urgente: il parco macchine è in ordine.", systemImage: "checkmark.circle.fill").foregroundStyle(.green).padding(16).frame(maxWidth: .infinity, alignment: .leading).background(.green.opacity(0.07)).clipShape(RoundedRectangle(cornerRadius: 13)) }
                    ForEach(maintenance) { advice in
                        VStack(alignment: .leading, spacing: 12) {
                            HStack(alignment: .top) {
                                PrinterThumbnail(printer: advice.printer, size: 54)
                                VStack(alignment: .leading, spacing: 3) { Text(advice.printer.displayName).font(.headline); Text(advice.title).font(.caption.bold()).foregroundStyle(advice.priority == .urgent ? .red : advice.priority == .soon ? .orange : .green); Label(advice.timing, systemImage: "calendar.badge.clock").font(.caption).foregroundStyle(.secondary) }
                                Spacer()
                                Button("Segna eseguita", systemImage: "checkmark.circle") { store.markMaintenanceCompleted(printerID: advice.printer.id) }.disabled(advice.priority == .routine)
                            }
                            VStack(alignment: .leading, spacing: 6) { ForEach(advice.tasks, id: \.self) { task in Label(task, systemImage: "checkmark.square").font(.callout) } }
                        }.padding(16).background((advice.priority == .urgent ? Color.red : advice.priority == .soon ? Color.orange : Color.secondary).opacity(0.06)).clipShape(RoundedRectangle(cornerRadius: 14)).overlay(RoundedRectangle(cornerRadius: 14).stroke((advice.priority == .urgent ? Color.red : advice.priority == .soon ? Color.orange : Color.secondary).opacity(0.18)))
                    }
                }
                VStack(alignment: .leading, spacing: 12) {
                    Text("Piano di stampa consigliato").font(.title2.bold())
                    if plan.isEmpty { ContentUnavailableView("Nessun lavoro da pianificare", systemImage: "checkmark.circle", description: Text("Gli ordini confermati appariranno qui.")) }
                    ForEach(plan) { item in
                        HStack(spacing: 14) {
                            VStack { Circle().fill(item.isAtRisk ? .red : .green).frame(width: 10, height: 10); Rectangle().fill(.secondary.opacity(0.2)).frame(width: 2, height: 45) }
                            VStack(alignment: .leading, spacing: 4) {
                                HStack { Text(item.order.title).fontWeight(.semibold); if item.isAtRisk { Text("A RISCHIO").font(.caption2.bold()).foregroundStyle(.red).padding(.horizontal, 7).padding(.vertical, 3).background(.red.opacity(0.10)).clipShape(Capsule()) } }
                                Text("\(item.printer?.displayName ?? "Stampante da assegnare") · \(item.order.code)").font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer()
                            VStack(alignment: .trailing, spacing: 3) { Text(item.plannedStart, format: .dateTime.day().month(.abbreviated).hour().minute()); Text("fine \(item.plannedFinish.formatted(date: .omitted, time: .shortened))").font(.caption).foregroundStyle(item.isAtRisk ? .red : .secondary) }
                        }.padding(14).background(Color(nsColor: .controlBackgroundColor).opacity(0.72)).clipShape(RoundedRectangle(cornerRadius: 13))
                    }
                }
            }.padding(28)
        }.background(LinearGradient(colors: [.purple.opacity(0.05), Color(nsColor: .windowBackgroundColor)], startPoint: .topLeading, endPoint: .bottomTrailing))
    }
}
