import Foundation
import AppKit

struct MailAccountInfo: Identifiable, Hashable {
    var id: String { "\(name)|\(email)" }
    let name: String
    let email: String
}

struct ImportedMailMessage {
    let sender: String
    let subject: String
    let preview: String
    let receivedAt: Date
}

@MainActor
final class EmailConnectionService: ObservableObject {
    @Published private(set) var accounts: [MailAccountInfo] = []
    @Published private(set) var status = "Nessun account collegato"
    @Published private(set) var isWorking = false

    func discoverAccounts() {
        isWorking = true
        defer { isWorking = false }
        let script = """
        tell application "Mail"
            set output to ""
            repeat with acc in every account
                set accountName to name of acc
                set accountEmail to ""
                try
                    set addressesList to email addresses of acc
                    if (count of addressesList) > 0 then set accountEmail to item 1 of addressesList
                end try
                set output to output & accountName & ASCII character 31 & accountEmail & ASCII character 30
            end repeat
            return output
        end tell
        """
        do {
            let value = try execute(script)
            accounts = value.components(separatedBy: String(UnicodeScalar(30))).compactMap { row in
                let parts = row.components(separatedBy: String(UnicodeScalar(31)))
                guard let name = parts.first, !name.isEmpty else { return nil }
                return MailAccountInfo(name: name, email: parts.count > 1 ? parts[1] : "")
            }
            status = accounts.isEmpty ? "Nessun account trovato in Mail" : "Trovati \(accounts.count) account"
        } catch { status = error.localizedDescription }
    }

    func importUnreadMessages(limit: Int = 25) -> [ImportedMailMessage] {
        isWorking = true
        defer { isWorking = false }
        let script = """
        tell application "Mail"
            set output to ""
            set unreadList to messages of inbox whose read status is false
            set messageCount to count of unreadList
            if messageCount > \(limit) then set messageCount to \(limit)
            repeat with i from 1 to messageCount
                set msg to item i of unreadList
                set senderText to sender of msg
                set subjectText to subject of msg
                set bodyText to content of msg
                if (length of bodyText) > 700 then set bodyText to text 1 thru 700 of bodyText
                set bodyText to my cleanText(bodyText)
                set output to output & senderText & ASCII character 31 & subjectText & ASCII character 31 & bodyText & ASCII character 30
            end repeat
            return output
        end tell
        on cleanText(inputText)
            set AppleScript's text item delimiters to {return, linefeed, ASCII character 30, ASCII character 31}
            set pieces to text items of inputText
            set AppleScript's text item delimiters to " "
            set cleanValue to pieces as text
            set AppleScript's text item delimiters to ""
            return cleanValue
        end cleanText
        """
        do {
            let value = try execute(script)
            let messages = value.components(separatedBy: String(UnicodeScalar(30))).compactMap { row -> ImportedMailMessage? in
                let fields = row.components(separatedBy: String(UnicodeScalar(31)))
                guard fields.count >= 3, !fields[1].isEmpty else { return nil }
                return ImportedMailMessage(sender: fields[0], subject: fields[1], preview: fields[2], receivedAt: .now)
            }
            status = messages.isEmpty ? "Nessuna email non letta" : "Importate \(messages.count) email"
            return messages
        } catch { status = error.localizedDescription; return [] }
    }

    func openInternetAccounts() {
        if let url = URL(string: "x-apple.systempreferences:com.apple.Internet-Accounts-Settings.extension") { NSWorkspace.shared.open(url) }
    }

    private func execute(_ source: String) throws -> String {
        guard let script = NSAppleScript(source: source) else { throw MailConnectionError.invalidScript }
        var details: NSDictionary?
        let result = script.executeAndReturnError(&details)
        if let details {
            let message = details[NSAppleScript.errorMessage] as? String ?? "Accesso a Mail non riuscito"
            throw MailConnectionError.appleScript(message)
        }
        return result.stringValue ?? ""
    }
}

private enum MailConnectionError: LocalizedError {
    case invalidScript, appleScript(String)
    var errorDescription: String? {
        switch self {
        case .invalidScript: "Impossibile preparare il collegamento a Mail"
        case .appleScript(let message): "Mail: \(message). Controlla Privacy e sicurezza → Automazione."
        }
    }
}
