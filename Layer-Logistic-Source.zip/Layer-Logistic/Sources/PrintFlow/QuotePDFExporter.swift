import SwiftUI
import AppKit

@MainActor
enum QuotePDFExporter {
    static func export(order: PrintOrder, store: OrderStore) {
        let panel = NSSavePanel()
        panel.allowedContentTypes = [.pdf]
        panel.nameFieldStringValue = "Preventivo-\(order.code).pdf"
        guard panel.runModal() == .OK, let url = panel.url else { return }

        let view = QuotePDFView(order: order,
                                customer: store.customer(for: order),
                                printer: store.printers.first { $0.id == order.printerID },
                                filament: store.filaments.first { $0.id == order.filamentID },
                                companyName: store.settings.companyName,
                                electricityPrice: store.settings.electricityPricePerKWh,
                                breakdown: store.quote(for: order))
            .frame(width: 595, height: 842)
        let hosting = NSHostingView(rootView: view)
        hosting.frame = NSRect(x: 0, y: 0, width: 595, height: 842)
        let data = hosting.dataWithPDF(inside: hosting.bounds)
        try? data.write(to: url, options: .atomic)
    }
}

private struct QuotePDFView: View {
    let order: PrintOrder
    let customer: Customer?
    let printer: PrinterProfile?
    let filament: FilamentSpool?
    let companyName: String
    let electricityPrice: Double
    let breakdown: QuoteBreakdown

    var body: some View {
        VStack(alignment: .leading, spacing: 24) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 5) {
                    Text(companyName).font(.system(size: 25, weight: .bold)).foregroundStyle(.purple)
                    Text("Stampa 3D e prototipazione").foregroundStyle(.secondary)
                }
                Spacer()
                VStack(alignment: .trailing) {
                    Text("PREVENTIVO").font(.system(size: 22, weight: .bold))
                    Text(order.code).font(.headline).foregroundStyle(.secondary)
                    Text(Date.now, format: .dateTime.day().month().year())
                }
            }
            Divider()
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 5) {
                    Text("CLIENTE").font(.caption.bold()).foregroundStyle(.secondary)
                    Text(customer?.company ?? "-").font(.headline)
                    Text(customer?.name ?? "")
                    Text(customer?.email ?? "")
                }
                Spacer()
                VStack(alignment: .trailing, spacing: 5) {
                    Text("CONSEGNA PREVISTA").font(.caption.bold()).foregroundStyle(.secondary)
                    Text(order.dueDate, format: .dateTime.day().month(.wide).year()).font(.headline)
                }
            }
            VStack(alignment: .leading, spacing: 8) {
                Text(order.title).font(.title2.bold())
                Text("\(order.quantity) pz · \(order.material.rawValue) \(order.color)")
                Text("Stampante: \(printer?.displayName ?? "Non specificata")")
                Text("Filamento: \(filament?.name ?? "Costo materiale standard")")
            }.padding(16).frame(maxWidth: .infinity, alignment: .leading).background(Color.purple.opacity(0.07)).clipShape(RoundedRectangle(cornerRadius: 10))
            VStack(spacing: 0) {
                pdfRow("Materiale (\(((order.weightGrams ?? 0) * Double(order.quantity)).formatted()) g)", breakdown.material)
                pdfRow("Energia (\(electricityPrice.euro)/kWh)", breakdown.energy)
                pdfRow("Usura macchina", breakdown.wear)
                pdfRow("Finitura", breakdown.finishing)
                pdfRow("Materiali aggiuntivi", breakdown.extras)
                pdfRow("Imballaggio", breakdown.packaging)
                pdfRow("Spedizione", breakdown.shipping)
                pdfRow("Lavorazione e gestione", breakdown.profit)
                Divider()
                pdfRow("Imponibile", breakdown.subtotal, bold: true)
                pdfRow("IVA \(breakdown.vatPercent.formatted())%", breakdown.vat)
                HStack { Text("TOTALE").font(.title3.bold()); Spacer(); Text(breakdown.total.euro).font(.title2.bold()).foregroundStyle(.purple) }.padding(.vertical, 14)
            }
            if !order.notes.isEmpty {
                VStack(alignment: .leading, spacing: 6) { Text("NOTE").font(.caption.bold()).foregroundStyle(.secondary); Text(order.notes) }
            }
            Spacer()
            Divider()
            Text("Preventivo generato con PrintFlow. Validità 30 giorni salvo diversa indicazione.").font(.caption).foregroundStyle(.secondary)
        }.padding(44).background(.white).foregroundStyle(.black)
    }

    private func pdfRow(_ label: String, _ value: Double, bold: Bool = false) -> some View {
        HStack { Text(label).fontWeight(bold ? .semibold : .regular); Spacer(); Text(value.euro).fontWeight(bold ? .semibold : .regular) }.padding(.vertical, 9)
    }
}
