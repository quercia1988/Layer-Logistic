import SwiftUI

@main
struct PrintFlowApp: App {
    @StateObject private var store = OrderStore()
    @StateObject private var telegram = TelegramBotService()
    @StateObject private var email = EmailConnectionService()
    @StateObject private var printerConnection = PrinterConnectionService()
    @StateObject private var listingAssistant = ListingAssistantService()
    @StateObject private var etsy = EtsyService()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(store)
                .environmentObject(telegram)
                .environmentObject(email)
                .environmentObject(printerConnection)
                .environmentObject(listingAssistant)
                .environmentObject(etsy)
                .frame(minWidth: 1050, minHeight: 680)
                .task {
                    telegram.attach(store)
                    if store.settings.telegramBotEnabled == true { telegram.start() }
                }
        }
        .windowStyle(.titleBar)
        .commands {
            CommandGroup(replacing: .newItem) {
                Button("Nuovo ordine") { NotificationCenter.default.post(name: .newOrder, object: nil) }
                    .keyboardShortcut("n")
            }
        }
    }
}

extension Notification.Name { static let newOrder = Notification.Name("PrintFlow.newOrder") }
