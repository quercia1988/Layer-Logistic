import SwiftUI

enum SidebarItem: String, CaseIterable, Identifiable {
    case dashboard = "Panoramica", assistant = "Assistente IA", storeOrders = "Ordini store", waiting = "In attesa", todo = "Da fare", production = "In stampa", fulfilled = "Evasi", completed = "Completati", shipping = "Spedizioni", customerCare = "Customer Care", purchasing = "Acquisti", archive = "Archivio file", products = "Prodotti", budget = "Budget aziendale", customers = "Clienti", inventory = "Magazzino", machines = "Stampanti", settings = "Impostazioni"
    var id: String { rawValue }
    var icon: String {
        switch self {
        case .dashboard: "square.grid.2x2"
        case .assistant: "sparkles"
        case .storeOrders: "storefront.fill"
        case .waiting: "clock"
        case .todo: "list.clipboard"
        case .production: "printer.fill"
        case .fulfilled: "shippingbox"
        case .completed: "checkmark.circle.fill"
        case .shipping: "truck.box.fill"
        case .customerCare: "envelope.badge"
        case .purchasing: "cart.badge.plus"
        case .archive: "externaldrive.fill"
        case .products: "square.grid.2x2.fill"
        case .budget: "chart.pie.fill"
        case .customers: "person.2"
        case .inventory: "cylinder.split.1x2"
        case .machines: "printer"
        case .settings: "gearshape"
        }
    }
}

struct ContentView: View {
    @EnvironmentObject private var store: OrderStore
    @State private var selection: SidebarItem? = .dashboard
    @State private var showNewOrder = false

    var body: some View {
        NavigationSplitView {
            VStack(spacing: 0) {
                HStack(spacing: 12) {
                    Group { if let data = store.settings.companyLogoPNG, let logo = NSImage(data: data) { Image(nsImage: logo).resizable().scaledToFit().padding(7) } else { Image(systemName: "cube.fill").font(.system(size: 21, weight: .semibold)).foregroundStyle(.white) } }.frame(width: 42, height: 42).background(CleanWorkshopTheme.heroGradient).clipShape(RoundedRectangle(cornerRadius: 13, style: .continuous)).shadow(color: CleanWorkshopTheme.purple.opacity(0.22), radius: 10, y: 5)
                    VStack(alignment: .leading, spacing: 1) { Text("Layer Logistic").font(.title3.bold()); Text("CLEAN WORKSHOP").font(.system(size: 9, weight: .bold)).tracking(1.2).foregroundStyle(.secondary) }
                    Spacer()
                }.padding(.horizontal, 18).padding(.top, 20).padding(.bottom, 15)
                List(selection: $selection) {
                    Section { ForEach([SidebarItem.dashboard, .assistant]) { sidebarRow($0) } }
                    Section("Ordini") { ForEach([SidebarItem.storeOrders, .waiting, .todo, .production, .fulfilled, .completed]) { sidebarRow($0) } }
                    Section("Produzione e logistica") { ForEach([SidebarItem.shipping, .archive]) { sidebarRow($0) } }
                    Section("Gestione") { ForEach([SidebarItem.products, .machines, .inventory, .customers, .customerCare, .purchasing, .budget]) { sidebarRow($0) } }
                    Section { sidebarRow(.settings) }
                }.listStyle(.sidebar).scrollContentBackground(.hidden)
                HStack(spacing: 10) { Image(systemName: "building.2.fill").foregroundStyle(CleanWorkshopTheme.purple).frame(width: 34, height: 34).background(CleanWorkshopTheme.softPurple).clipShape(RoundedRectangle(cornerRadius: 10)); VStack(alignment: .leading, spacing: 2) { Text(store.settings.companyName).font(.caption.bold()).lineLimit(1); HStack(spacing: 4) { Circle().fill(.green).frame(width: 6, height: 6); Text("Workspace attivo").font(.caption2).foregroundStyle(.secondary) } }; Spacer(); Image(systemName: "chevron.up.chevron.down").font(.caption2).foregroundStyle(.secondary) }.padding(11).workshopCard(radius: 13).padding(12)
            }
            .background(CleanWorkshopTheme.sidebar)
            .navigationSplitViewColumnWidth(min: 220, ideal: 245, max: 280)
        } detail: {
            Group {
                switch selection ?? .dashboard {
                case .dashboard: DashboardView(showNewOrder: $showNewOrder)
                case .assistant: ProductionAssistantView()
                case .storeOrders: OrdersView(showNewOrder: $showNewOrder, bucket: .waiting, marketplacesOnly: true)
                case .waiting: OrdersView(showNewOrder: $showNewOrder, bucket: .waiting)
                case .todo: OrdersView(showNewOrder: $showNewOrder, bucket: .todo)
                case .production: OrdersView(showNewOrder: $showNewOrder, bucket: .production)
                case .fulfilled: OrdersView(showNewOrder: $showNewOrder, bucket: .fulfilled)
                case .completed: OrdersView(showNewOrder: $showNewOrder, bucket: .completed)
                case .shipping: ShippingHubView()
                case .customerCare: CustomerCareView()
                case .purchasing: PurchasingView()
                case .archive: FileArchiveView()
                case .products: ProductsView()
                case .budget: BudgetView()
                case .customers: CustomersView()
                case .inventory: InventoryView()
                case .machines: PrintersView()
                case .settings: SettingsView()
                }
            }
            .workshopPage()
            .toolbar {
                ToolbarItem(placement: .primaryAction) {
                    Button { showNewOrder = true } label: { Label("Nuovo ordine", systemImage: "plus") }
                }
            }
        }
        .tint(CleanWorkshopTheme.purple)
        .preferredColorScheme(store.settings.appearance == "light" ? .light : store.settings.appearance == "dark" ? .dark : nil)
        .sheet(isPresented: $showNewOrder) { NewOrderView() }
        .onReceive(NotificationCenter.default.publisher(for: .newOrder)) { _ in showNewOrder = true }
    }

    private func orderCount(for item: SidebarItem) -> Int? {
        if item == .assistant {
            return ProductionPlanner.makePlan(orders: store.orders, printers: store.printers).filter(\.isAtRisk).count
        }
        if item == .storeOrders {
            return store.orders.filter { $0.status == .quote && ($0.marketplace ?? .direct) != .direct }.count
        }
        let bucket: OrderBucket
        switch item {
        case .waiting: bucket = .waiting
        case .todo: bucket = .todo
        case .production: bucket = .production
        case .fulfilled: bucket = .fulfilled
        case .completed: bucket = .completed
        default: return nil
        }
        return store.orders.filter { bucket.contains($0.status) }.count
    }

    private func sidebarRow(_ item: SidebarItem) -> some View {
        HStack(spacing: 10) {
            Image(systemName: item.icon).font(.system(size: 14, weight: .semibold)).foregroundStyle(selection == item ? CleanWorkshopTheme.purple : .secondary).frame(width: 25)
            Text(item.rawValue).fontWeight(selection == item ? .semibold : .regular).foregroundStyle(selection == item ? CleanWorkshopTheme.purple : .primary)
            Spacer()
            if let count = orderCount(for: item), count > 0 {
                Text("\(count)").font(.caption2.bold()).foregroundStyle(selection == item ? CleanWorkshopTheme.purple : .secondary).padding(.horizontal, 7).padding(.vertical, 3).background(selection == item ? CleanWorkshopTheme.softPurple : Color.secondary.opacity(0.10)).clipShape(Capsule())
            }
        }
        .padding(.vertical, 5)
        .contentShape(RoundedRectangle(cornerRadius: 9))
        .listRowBackground(selection == item ? CleanWorkshopTheme.softPurple : Color.clear)
        .tag(item)
    }
}

struct DashboardView: View {
    @EnvironmentObject private var store: OrderStore
    @Binding var showNewOrder: Bool
    private var active: [PrintOrder] { store.orders.filter { $0.status != .delivered } }
    private var revenue: Double { store.orders.filter { Calendar.current.isDate($0.createdAt, equalTo: .now, toGranularity: .month) }.reduce(0) { $0 + $1.price } }
    private var monthlyProfit: Double { store.orders.filter { $0.status == .delivered && Calendar.current.isDate($0.createdAt, equalTo: .now, toGranularity: .month) }.reduce(0) { $0 + store.profit(for: $1) } }
    private var plan: [ProductionPlanItem] { ProductionPlanner.makePlan(orders: store.orders, printers: store.printers) }
    @State private var search = ""
    private var recentOrders: [PrintOrder] { store.orders.filter { search.isEmpty || $0.title.localizedCaseInsensitiveContains(search) || $0.code.localizedCaseInsensitiveContains(search) }.prefix(4).map { $0 } }

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                HStack(spacing: 14) {
                    VStack(alignment: .leading, spacing: 3) {
                        Text("Panoramica").font(.largeTitle.bold()).tracking(-0.7)
                        Text("Produzione, ordini e scorte sotto controllo").font(.callout).foregroundStyle(.secondary)
                    }
                    Spacer()
                    HStack(spacing: 8) { Image(systemName: "magnifyingglass").foregroundStyle(.secondary); TextField("Cerca ordini, clienti, file…", text: $search).textFieldStyle(.plain); Text("⌘K").font(.caption2).foregroundStyle(.secondary).padding(5).background(.secondary.opacity(0.08)).clipShape(RoundedRectangle(cornerRadius: 5)) }.padding(.horizontal, 12).frame(width: 300, height: 38).background(CleanWorkshopTheme.card).clipShape(RoundedRectangle(cornerRadius: 10)).overlay(RoundedRectangle(cornerRadius: 10).stroke(CleanWorkshopTheme.border))
                    Button { } label: { Image(systemName: "bell").frame(width: 22, height: 22) }.buttonStyle(.bordered).controlSize(.large).overlay(alignment: .topTrailing) { if !store.lowStockFilaments.isEmpty { Circle().fill(.red).frame(width: 8, height: 8).overlay(Circle().stroke(CleanWorkshopTheme.card, lineWidth: 2)).offset(x: 2, y: -2) } }
                    Button("Nuovo ordine", systemImage: "plus") { showNewOrder = true }.buttonStyle(.borderedProminent).controlSize(.large).tint(CleanWorkshopTheme.purple)
                }
                HStack(spacing: 14) {
                    MetricCard(title: "In stampa", value: "\(active.filter { $0.status == .printing }.count)", icon: "printer.fill", color: .purple)
                    MetricCard(title: "Completati", value: "\(store.orders.filter { $0.status == .delivered }.count)", icon: "checkmark.circle.fill", color: .green)
                    MetricCard(title: "Fatturato mese", value: revenue.euro, icon: "cube.fill", color: .purple)
                    MetricCard(title: "Guadagno mese", value: monthlyProfit.euro, icon: "eurosign.circle.fill", color: monthlyProfit >= 0 ? .green : .red)
                }
                HStack(alignment: .top, spacing: 16) {
                    ProductionScheduleCard(plan: plan).frame(maxWidth: .infinity)
                    PrinterGridCard(printers: store.printers, orders: store.orders).frame(width: 420)
                }
                HStack(alignment: .top, spacing: 16) {
                    LowStockCard().frame(width: 390)
                    RecentOrdersCard(orders: recentOrders).frame(maxWidth: .infinity)
                }
            }.padding(24)
        }.background(Color(nsColor: .underPageBackgroundColor))
    }
}

struct ProductionScheduleCard: View {
    let plan: [ProductionPlanItem]
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack { Text("Pianificazione produzione").font(.headline); Spacer(); Label("Oggi", systemImage: "calendar").font(.callout).foregroundStyle(.secondary) }
            if plan.isEmpty { ContentUnavailableView("Nessuna stampa pianificata", systemImage: "calendar.badge.checkmark") }
            ForEach(plan.prefix(4)) { item in
                HStack(spacing: 12) {
                    VStack(alignment: .leading, spacing: 3) { Text(item.printer?.model ?? "Da assegnare").fontWeight(.medium); Text(item.plannedStart, format: .dateTime.hour().minute()).font(.caption).foregroundStyle(.secondary) }.frame(width: 105, alignment: .leading)
                    VStack(alignment: .leading, spacing: 6) {
                        HStack { Text(item.order.title).font(.callout.weight(.semibold)).lineLimit(1); Spacer(); Text("\(item.hours.formatted(.number.precision(.fractionLength(1)))) h").font(.caption).foregroundStyle(.secondary) }
                        ProgressView(value: item.order.status == .printing ? 0.6 : 0.12).tint(item.isAtRisk ? .red : .cyan)
                    }.padding(10).background((item.isAtRisk ? Color.red : Color.cyan).opacity(0.07)).clipShape(RoundedRectangle(cornerRadius: 9)).overlay(RoundedRectangle(cornerRadius: 9).stroke((item.isAtRisk ? Color.red : Color.cyan).opacity(0.3)))
                }
            }
        }.padding(18).workshopCard()
    }
}

struct PrinterGridCard: View {
    let printers: [PrinterProfile]
    let orders: [PrintOrder]
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack { Text("Stampanti").font(.headline); Spacer(); Text("Visualizza tutte").font(.caption).foregroundStyle(.purple) }
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                ForEach(printers.prefix(4)) { printer in
                    let active = orders.first { $0.printerID == printer.id && $0.status == .printing }
                    VStack(alignment: .leading, spacing: 8) {
                        HStack { PrinterThumbnail(printer: printer, size: 48); Spacer(); Circle().fill(active == nil ? .green : .cyan).frame(width: 8, height: 8) }
                        Text(printer.model).font(.callout.weight(.semibold)).lineLimit(1)
                        Text(active == nil ? "Pronta" : "In stampa").font(.caption).foregroundStyle(active == nil ? .green : .cyan)
                        ProgressView(value: active == nil ? 0 : 0.55).tint(.cyan)
                        Text("\((printer.totalWorkHours ?? 0).formatted()) h totali").font(.caption2).foregroundStyle(.secondary)
                    }.padding(12).background(Color(nsColor: .controlBackgroundColor).opacity(0.55)).clipShape(RoundedRectangle(cornerRadius: 11)).overlay(RoundedRectangle(cornerRadius: 11).stroke(CleanWorkshopTheme.border))
                }
            }
        }.padding(18).workshopCard()
    }
}

struct LowStockCard: View {
    @EnvironmentObject private var store: OrderStore
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack { Text("Scorte basse").font(.headline); Spacer(); Image(systemName: "exclamationmark.triangle.fill").foregroundStyle(.orange) }
            let items = store.lowStockFilaments
            if items.isEmpty { Text("Tutte le scorte sono sopra il minimo.").foregroundStyle(.secondary).padding(.vertical, 22) }
            ForEach(items.prefix(4)) { item in
                HStack { Image(systemName: "cylinder.fill").foregroundStyle(.purple); VStack(alignment: .leading) { Text(item.name).font(.callout.weight(.medium)); Text("\(item.remainingGrams.formatted()) g disponibili").font(.caption).foregroundStyle(.secondary) }; Spacer(); Text("Basso").font(.caption2.bold()).foregroundStyle(.orange).padding(5).background(.orange.opacity(0.1)).clipShape(Capsule()) }
                Divider()
            }
        }.padding(18).workshopCard()
    }
}

struct RecentOrdersCard: View {
    let orders: [PrintOrder]
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack { Text("Ordini recenti").font(.headline); Spacer(); Text("Visualizza tutti").font(.caption).foregroundStyle(.purple) }
            HStack(spacing: 10) {
                ForEach(orders) { order in
                    VStack(alignment: .leading, spacing: 7) {
                        Group { if let data = order.previewPNG, let image = NSImage(data: data) { Image(nsImage: image).resizable().scaledToFill() } else { Image(systemName: "cube.transparent.fill").resizable().scaledToFit().padding(30).foregroundStyle(.purple) } }.frame(maxWidth: .infinity).frame(height: 105).background(Color(nsColor: .controlBackgroundColor)).clipped()
                        Text(order.code).font(.caption.bold()); Text(order.title).font(.caption).lineLimit(1)
                        Label(order.status.rawValue, systemImage: "circle.fill").font(.caption2).foregroundStyle(order.status.color)
                        ProgressView(value: order.status == .delivered ? 1 : order.status == .printing ? 0.6 : 0.15).tint(order.status.color)
                    }.frame(maxWidth: .infinity, alignment: .leading).padding(8).background(Color(nsColor: .controlBackgroundColor).opacity(0.5)).clipShape(RoundedRectangle(cornerRadius: 10)).overlay(RoundedRectangle(cornerRadius: 10).stroke(.secondary.opacity(0.12)))
                }
            }
        }.padding(18).workshopCard()
    }
}

struct MetricCard: View {
    let title: String, value: String, icon: String
    let color: Color
    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: icon).font(.title2.weight(.semibold)).foregroundStyle(color).frame(width: 48, height: 48).background(color.opacity(0.10)).clipShape(Circle())
            VStack(alignment: .leading, spacing: 4) { Text(title).font(.caption).foregroundStyle(.secondary); Text(value).font(.title2.bold()).lineLimit(1).minimumScaleFactor(0.7); Text("Aggiornato ora").font(.caption2).foregroundStyle(.secondary) }
        }.frame(maxWidth: .infinity, minHeight: 76, alignment: .leading).padding(16).workshopCard()
    }
}

struct OrderRow: View {
    @EnvironmentObject private var store: OrderStore
    let order: PrintOrder
    var body: some View {
        HStack(spacing: 14) {
            Group {
                if let data = order.previewPNG, let image = NSImage(data: data) {
                    Image(nsImage: image).resizable().scaledToFill()
                } else {
                    Image(systemName: order.status.symbol).resizable().scaledToFit().padding(11).foregroundStyle(order.status.color).background(order.status.color.opacity(0.12))
                }
            }.frame(width: 52, height: 52).background(Color(nsColor: .controlBackgroundColor)).clipShape(RoundedRectangle(cornerRadius: 11)).overlay(RoundedRectangle(cornerRadius: 11).stroke(.secondary.opacity(0.13)))
            VStack(alignment: .leading, spacing: 3) {
                Text(order.title).fontWeight(.semibold)
                HStack(spacing: 6) {
                    Text("\(order.code) · \(store.customer(for: order)?.company ?? "—")").font(.caption).foregroundStyle(.secondary)
                    if let market = order.marketplace, market != .direct {
                        Label(market.rawValue, systemImage: market.symbol).font(.caption2.bold()).foregroundStyle(market == .etsy ? .orange : .teal).padding(.horizontal, 6).padding(.vertical, 2).background((market == .etsy ? Color.orange : Color.teal).opacity(0.10)).clipShape(Capsule())
                    }
                }
            }
            Spacer()
            Text(order.dueDate, format: .dateTime.day().month(.abbreviated)).foregroundStyle(order.dueDate < .now ? .red : .secondary)
            Menu {
                ForEach(OrderStatus.allCases) { status in Button(status.rawValue) { store.updateStatus(orderID: order.id, to: status) } }
            } label: {
                Text(order.status.rawValue).font(.caption.weight(.medium)).padding(.horizontal, 10).padding(.vertical, 6).background(order.status.color.opacity(0.13)).foregroundStyle(order.status.color).clipShape(Capsule())
            }.menuStyle(.borderlessButton).frame(width: 115)
            VStack(alignment: .trailing, spacing: 2) {
                Text((order.weightGrams == nil ? order.price : store.quote(for: order).total).euro).fontWeight(.semibold)
                Text("guad. \(store.profit(for: order).euro)").font(.caption2).foregroundStyle(store.profit(for: order) >= 0 ? .green : .red)
            }.frame(width: 100, alignment: .trailing)
        }.padding(.vertical, 4)
    }
}
