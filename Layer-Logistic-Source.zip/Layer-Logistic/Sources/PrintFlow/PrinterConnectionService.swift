import Foundation

struct LivePrinterData: Sendable {
    var state: String
    var fileName: String?
    var progress: Double
    var nozzleTemperature: Double?
    var nozzleTarget: Double?
    var bedTemperature: Double?
    var bedTarget: Double?
    var elapsedSeconds: Double?
    var remainingSeconds: Double?
    var updatedAt = Date()
}

@MainActor
final class PrinterConnectionService: ObservableObject {
    @Published private(set) var data: [UUID: LivePrinterData] = [:]
    @Published private(set) var errors: [UUID: String] = [:]
    @Published private(set) var loading: Set<UUID> = []

    func refresh(_ printer: PrinterProfile) {
        guard !loading.contains(printer.id) else { return }
        loading.insert(printer.id); errors[printer.id] = nil
        Task {
            do { data[printer.id] = try await fetch(printer); errors[printer.id] = nil }
            catch { errors[printer.id] = error.localizedDescription }
            loading.remove(printer.id)
        }
    }

    private func fetch(_ printer: PrinterProfile) async throws -> LivePrinterData {
        guard let type = printer.connectionType, type != .none,
              let rawURL = printer.connectionURL?.trimmingCharacters(in: .whitespacesAndNewlines), !rawURL.isEmpty else {
            throw ConnectionError.missingConfiguration
        }
        var base = rawURL
        if !base.contains("://") { base = "http://" + base }
        while base.hasSuffix("/") { base.removeLast() }
        switch type {
        case .moonraker: return try await fetchMoonraker(base: base)
        case .octoPrint: return try await fetchOctoPrint(base: base, apiKey: printer.connectionAPIKey)
        case .none: throw ConnectionError.missingConfiguration
        }
    }

    private func fetchMoonraker(base: String) async throws -> LivePrinterData {
        guard let url = URL(string: base + "/printer/objects/query?print_stats&extruder&heater_bed&display_status") else { throw ConnectionError.invalidURL }
        let (payload, response) = try await URLSession.shared.data(from: url)
        try validate(response)
        let root = try JSONDecoder().decode(MoonrakerResponse.self, from: payload).result.status
        return LivePrinterData(state: root.printStats?.state.capitalized ?? "Online", fileName: root.printStats?.filename,
                               progress: (root.displayStatus?.progress ?? 0) * 100,
                               nozzleTemperature: root.extruder?.temperature, nozzleTarget: root.extruder?.target,
                               bedTemperature: root.heaterBed?.temperature, bedTarget: root.heaterBed?.target,
                               elapsedSeconds: root.printStats?.printDuration, remainingSeconds: nil)
    }

    private func fetchOctoPrint(base: String, apiKey: String?) async throws -> LivePrinterData {
        guard let url = URL(string: base + "/api/job") else { throw ConnectionError.invalidURL }
        var request = URLRequest(url: url)
        if let apiKey, !apiKey.isEmpty { request.setValue(apiKey, forHTTPHeaderField: "X-Api-Key") }
        let (payload, response) = try await URLSession.shared.data(for: request)
        try validate(response)
        let root = try JSONDecoder().decode(OctoPrintJob.self, from: payload)
        return LivePrinterData(state: root.state, fileName: root.job?.file?.name,
                               progress: root.progress?.completion ?? 0,
                               nozzleTemperature: nil, nozzleTarget: nil, bedTemperature: nil, bedTarget: nil,
                               elapsedSeconds: root.progress?.printTime, remainingSeconds: root.progress?.printTimeLeft)
    }

    private func validate(_ response: URLResponse) throws {
        guard let http = response as? HTTPURLResponse, 200..<300 ~= http.statusCode else { throw ConnectionError.server }
    }
}

private enum ConnectionError: LocalizedError {
    case missingConfiguration, invalidURL, server
    var errorDescription: String? {
        switch self {
        case .missingConfiguration: "Configura protocollo e indirizzo della stampante."
        case .invalidURL: "Indirizzo della stampante non valido."
        case .server: "La stampante non ha risposto correttamente. Verifica indirizzo e API key."
        }
    }
}

private struct MoonrakerResponse: Decodable {
    struct Result: Decodable { let status: Status }
    struct Status: Decodable {
        let printStats: PrintStats?; let extruder: Heater?; let heaterBed: Heater?; let displayStatus: DisplayStatus?
        enum CodingKeys: String, CodingKey { case printStats = "print_stats", extruder, heaterBed = "heater_bed", displayStatus = "display_status" }
    }
    struct PrintStats: Decodable { let state: String; let filename: String?; let printDuration: Double?; enum CodingKeys: String, CodingKey { case state, filename, printDuration = "print_duration" } }
    struct Heater: Decodable { let temperature: Double?; let target: Double? }
    struct DisplayStatus: Decodable { let progress: Double? }
    let result: Result
}

private struct OctoPrintJob: Decodable {
    struct Job: Decodable { struct File: Decodable { let name: String? }; let file: File? }
    struct Progress: Decodable { let completion: Double?; let printTime: Double?; let printTimeLeft: Double? }
    let state: String; let job: Job?; let progress: Progress?
}
