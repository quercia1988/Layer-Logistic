import Foundation
import AppKit
import simd

struct STLAnalysis {
    let fileName: String
    let volumeCM3: Double
    let dimensionsMM: SIMD3<Double>
    let triangleCount: Int
    let previewPNG: Data?

    func estimatedGrams(material: Material, infillPercent: Double) -> Double {
        let fraction = 0.20 + 0.80 * max(0, min(infillPercent, 100)) / 100
        return volumeCM3 * material.densityGramsPerCM3 * fraction
    }
}

@MainActor enum STLAnalyzer {
    static func analyze(url: URL) throws -> STLAnalysis {
        let data = try Data(contentsOf: url)
        return try makeAnalysis(fileName: url.lastPathComponent, triangles: isBinary(data) ? parseBinary(data) : parseASCII(data))
    }

    static func analyze3MF(url: URL) throws -> STLAnalysis {
        let temp = FileManager.default.temporaryDirectory.appendingPathComponent("PrintFlow-\(UUID().uuidString)", isDirectory: true)
        try FileManager.default.createDirectory(at: temp, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: temp) }
        let process = Process(); process.executableURL = URL(fileURLWithPath: "/usr/bin/ditto"); process.arguments = ["-x", "-k", url.path, temp.path]
        try process.run(); process.waitUntilExit()
        guard process.terminationStatus == 0 else { throw meshError("Archivio 3MF non leggibile.") }
        let files = FileManager.default.enumerator(at: temp, includingPropertiesForKeys: nil)?.allObjects as? [URL] ?? []
        let embeddedPreview = files
            .filter { ["png", "jpg", "jpeg"].contains($0.pathExtension.lowercased()) }
            .sorted { ($0.lastPathComponent.localizedCaseInsensitiveContains("thumbnail") ? 0 : 1) < ($1.lastPathComponent.localizedCaseInsensitiveContains("thumbnail") ? 0 : 1) }
            .compactMap { try? Data(contentsOf: $0) }
            .first
        guard let modelURL = files.first(where: { $0.pathExtension.lowercased() == "model" }) else { throw meshError("Geometria 3MF non trovata.") }
        let delegate = ThreeMFParser(), parser = XMLParser(contentsOf: modelURL)
        parser?.delegate = delegate
        guard parser?.parse() == true else { throw meshError("Geometria 3MF non valida.") }
        let triangles = delegate.resolvedTriangles()
        let analysis = try makeAnalysis(fileName: url.lastPathComponent, triangles: triangles)
        return STLAnalysis(fileName: analysis.fileName, volumeCM3: analysis.volumeCM3, dimensionsMM: analysis.dimensionsMM, triangleCount: analysis.triangleCount, previewPNG: embeddedPreview ?? analysis.previewPNG)
    }

    private static func makeAnalysis(fileName: String, triangles: [[SIMD3<Double>]]) throws -> STLAnalysis {
        guard !triangles.isEmpty else { throw meshError("Il file non contiene triangoli validi.") }
        var low = SIMD3<Double>(repeating: .greatestFiniteMagnitude), high = SIMD3<Double>(repeating: -.greatestFiniteMagnitude), volume = 0.0
        for t in triangles {
            for p in t { low = simd_min(low, p); high = simd_max(high, p) }
            volume += simd_dot(t[0], simd_cross(t[1], t[2])) / 6
        }
        let dimensions = high - low
        return STLAnalysis(fileName: fileName, volumeCM3: abs(volume) / 1000, dimensionsMM: dimensions, triangleCount: triangles.count, previewPNG: renderPreview(triangles: triangles, low: low, high: high))
    }

    private static func isBinary(_ data: Data) -> Bool {
        guard data.count >= 84 else { return false }
        let count = data.withUnsafeBytes { $0.loadUnaligned(fromByteOffset: 80, as: UInt32.self).littleEndian }
        return 84 + Int(count) * 50 == data.count
    }

    private static func parseBinary(_ data: Data) -> [[SIMD3<Double>]] {
        guard data.count >= 84 else { return [] }
        let count = data.withUnsafeBytes { $0.loadUnaligned(fromByteOffset: 80, as: UInt32.self).littleEndian }
        return (0..<Int(count)).compactMap { index in
            let base = 96 + index * 50; guard base + 36 <= data.count else { return nil }
            return (0..<3).map { vertex in
                let offset = base + vertex * 12
                let v = (0..<3).map { axis -> Double in
                    let bits = data.withUnsafeBytes { $0.loadUnaligned(fromByteOffset: offset + axis * 4, as: UInt32.self).littleEndian }
                    return Double(Float(bitPattern: bits))
                }
                return SIMD3(v[0], v[1], v[2])
            }
        }
    }

    private static func parseASCII(_ data: Data) -> [[SIMD3<Double>]] {
        guard let text = String(data: data, encoding: .utf8) else { return [] }
        let vertices = text.components(separatedBy: .newlines).compactMap { line -> SIMD3<Double>? in
            let p = line.split(whereSeparator: { $0 == " " || $0 == "\t" })
            guard p.count >= 4, p[0].lowercased() == "vertex", let x = Double(p[1]), let y = Double(p[2]), let z = Double(p[3]) else { return nil }
            return SIMD3(x, y, z)
        }
        guard vertices.count >= 3 else { return [] }
        return stride(from: 0, to: vertices.count - 2, by: 3).map { Array(vertices[$0...$0 + 2]) }
    }

    private static func renderPreview(triangles: [[SIMD3<Double>]], low: SIMD3<Double>, high: SIMD3<Double>) -> Data? {
        let size = NSSize(width: 700, height: 500), image = NSImage(size: size)
        let center = (low + high) / 2
        func projected(_ point: SIMD3<Double>) -> SIMD2<Double> {
            let p = point - center
            return SIMD2((p.x - p.y) * 0.866, (p.x + p.y) * 0.5 - p.z)
        }
        let all = triangles.flatMap { $0 }.map(projected)
        guard let minX = all.map(\.x).min(), let maxX = all.map(\.x).max(), let minY = all.map(\.y).min(), let maxY = all.map(\.y).max() else { return nil }
        let drawingScale = min(600 / max(maxX - minX, 1), 400 / max(maxY - minY, 1))
        func depth(_ triangle: [SIMD3<Double>]) -> Double {
            triangle.reduce(0.0) { partial, point in partial + point.x + point.y + point.z }
        }
        let sorted = triangles.sorted { depth($0) < depth($1) }
        image.lockFocus()
        NSGraphicsContext.current?.shouldAntialias = true
        NSColor(calibratedWhite: 0.965, alpha: 1).setFill(); NSBezierPath(rect: NSRect(origin: .zero, size: size)).fill()
        for triangle in sorted {
            let projectedPoints = triangle.map { projected($0) }
            let points: [NSPoint] = projectedPoints.map { point in
                NSPoint(x: size.width / 2 + point.x * drawingScale, y: size.height / 2 - point.y * drawingScale)
            }
            let normal = simd_normalize(simd_cross(triangle[1] - triangle[0], triangle[2] - triangle[0]))
            let light = max(0.28, min(1, 0.55 + normal.z * 0.3 + normal.y * 0.15))
            NSColor(calibratedRed: 0.43 * light, green: 0.25 * light, blue: 0.92 * light, alpha: 1).setFill()
            NSColor(calibratedWhite: 1, alpha: 0.08).setStroke()
            let path = NSBezierPath(); path.move(to: points[0]); path.line(to: points[1]); path.line(to: points[2]); path.close(); path.lineWidth = 0.35; path.fill(); path.stroke()
        }
        image.unlockFocus()
        guard let tiff = image.tiffRepresentation, let rep = NSBitmapImageRep(data: tiff) else { return nil }
        return rep.representation(using: .png, properties: [.compressionFactor: 0.88])
    }

    private static func meshError(_ text: String) -> NSError { NSError(domain: "PrintFlow.Mesh", code: 1, userInfo: [NSLocalizedDescriptionKey: text]) }
}

private struct ThreeMFObject {
    var vertices: [SIMD3<Double>] = []
    var indices: [SIMD3<Int>] = []
    var components: [(id: Int, transform: [Double])] = []
}

private final class ThreeMFParser: NSObject, XMLParserDelegate {
    var objects: [Int: ThreeMFObject] = [:]
    var buildItems: [(id: Int, transform: [Double])] = []
    var scale = 1.0
    private var currentObjectID: Int?

    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes a: [String : String] = [:]) {
        switch elementName.lowercased() {
        case "model": scale = ["micron": 0.001, "centimeter": 10, "meter": 1000, "inch": 25.4, "foot": 304.8][a["unit"]?.lowercased() ?? ""] ?? 1
        case "object": if let id = Int(a["id"] ?? "") { currentObjectID = id; objects[id] = ThreeMFObject() }
        case "vertex": if let id = currentObjectID, let x = Double(a["x"] ?? ""), let y = Double(a["y"] ?? ""), let z = Double(a["z"] ?? "") { objects[id]?.vertices.append(SIMD3(x, y, z)) }
        case "triangle": if let id = currentObjectID, let x = Int(a["v1"] ?? ""), let y = Int(a["v2"] ?? ""), let z = Int(a["v3"] ?? "") { objects[id]?.indices.append(SIMD3(x, y, z)) }
        case "component": if let owner = currentObjectID, let id = Int(a["objectid"] ?? "") { objects[owner]?.components.append((id, transform(a["transform"]))) }
        case "item": if let id = Int(a["objectid"] ?? "") { buildItems.append((id, transform(a["transform"]))) }
        default: break
        }
    }

    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        if elementName.lowercased() == "object" { currentObjectID = nil }
    }

    func resolvedTriangles() -> [[SIMD3<Double>]] {
        let roots = buildItems.isEmpty ? objects.keys.map { (id: $0, transform: identity) } : buildItems
        return roots.flatMap { resolve(id: $0.id, parent: $0.transform, visited: []) }.map { $0.map { $0 * scale } }
    }

    private func resolve(id: Int, parent: [Double], visited: Set<Int>) -> [[SIMD3<Double>]] {
        guard !visited.contains(id), let object = objects[id] else { return [] }
        var seen = visited; seen.insert(id)
        let own = object.indices.compactMap { idx -> [SIMD3<Double>]? in
            guard idx.x >= 0, idx.y >= 0, idx.z >= 0, idx.x < object.vertices.count, idx.y < object.vertices.count, idx.z < object.vertices.count else { return nil }
            return [apply(parent, object.vertices[idx.x]), apply(parent, object.vertices[idx.y]), apply(parent, object.vertices[idx.z])]
        }
        let nested = object.components.flatMap { component in resolve(id: component.id, parent: multiply(parent, component.transform), visited: seen) }
        return own + nested
    }

    private var identity: [Double] { [1,0,0, 0,1,0, 0,0,1, 0,0,0] }
    private func transform(_ text: String?) -> [Double] {
        guard let text else { return identity }
        let values = text.split(whereSeparator: { $0 == " " || $0 == "\t" }).compactMap { Double($0) }
        return values.count == 12 ? values : identity
    }
    private func apply(_ m: [Double], _ p: SIMD3<Double>) -> SIMD3<Double> {
        SIMD3(p.x*m[0] + p.y*m[3] + p.z*m[6] + m[9], p.x*m[1] + p.y*m[4] + p.z*m[7] + m[10], p.x*m[2] + p.y*m[5] + p.z*m[8] + m[11])
    }
    private func multiply(_ a: [Double], _ b: [Double]) -> [Double] {
        let origin = apply(a, SIMD3(b[9], b[10], b[11]))
        let x = applyVector(a, SIMD3(b[0], b[1], b[2])), y = applyVector(a, SIMD3(b[3], b[4], b[5])), z = applyVector(a, SIMD3(b[6], b[7], b[8]))
        return [x.x,x.y,x.z, y.x,y.y,y.z, z.x,z.y,z.z, origin.x,origin.y,origin.z]
    }
    private func applyVector(_ m: [Double], _ p: SIMD3<Double>) -> SIMD3<Double> {
        SIMD3(p.x*m[0] + p.y*m[3] + p.z*m[6], p.x*m[1] + p.y*m[4] + p.z*m[7], p.x*m[2] + p.y*m[5] + p.z*m[8])
    }
}
