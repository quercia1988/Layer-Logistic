import SwiftUI
import UniformTypeIdentifiers

struct NewOrderView: View {
    @EnvironmentObject private var store: OrderStore
    @Environment(\.dismiss) private var dismiss
    @State private var title = ""
    @State private var customerID: UUID?
    @State private var material: Material = .pla
    @State private var color = ""
    @State private var quantity = 1
    @State private var price = 0.0
    @State private var dueDate = Date.now.addingTimeInterval(86400 * 7)
    @State private var notes = ""
    @State private var weightGrams = 100.0
    @State private var printHours = 2.0
    @State private var finishingCost = 0.0
    @State private var printerID: UUID?
    @State private var filamentID: UUID?
    @State private var filamentUsages: [FilamentUsage] = []
    @State private var showFilaments = false
    @State private var extraUsages: [ExtraUsage] = []
    @State private var showExtras = false
    @State private var showSTLImporter = false
    @State private var stlFileName: String?
    @State private var stlVolumeCM3: Double?
    @State private var stlDimensionsMM: String?
    @State private var previewPNG: Data?
    @State private var infillPercent = 20.0
    @State private var importError: String?
    @State private var marketplace: Marketplace = .direct
    @State private var storeOrderID = ""
    @State private var storeOrderURL = ""
    @State private var selectedProductID: UUID?
    @State private var packagingCost = 0.0
    @State private var shippingCost = 0.0
    @State private var packageLength = 20.0
    @State private var packageWidth = 15.0
    @State private var packageHeight = 10.0
    @State private var fragile = false

    private var breakdown: QuoteBreakdown {
        let spool = store.filaments.first { $0.id == filamentID }
        let printer = store.printers.first { $0.id == printerID }
        let totalHours = printHours * Double(quantity)
        let materialTotal = filamentUsages.isEmpty
            ? weightGrams * Double(quantity) * (spool?.pricePerGram ?? material.pricePerGram)
            : filamentUsages.reduce(0) { partial, usage in
                partial + usage.gramsPerPiece * Double(quantity) * (store.filaments.first { $0.id == usage.filamentID }?.pricePerGram ?? 0)
            }
        let extrasTotal = extraUsages.reduce(0) { partial, usage in
            partial + usage.quantity * (store.extraMaterials.first { $0.id == usage.materialID }?.unitCost ?? 0)
        }
        return QuoteBreakdown(material: materialTotal,
                              energy: (printer?.consumptionWatts ?? 0) / 1000 * totalHours * store.settings.electricityPricePerKWh,
                              wear: (printer?.wearCostPerHour ?? 0) * totalHours,
                              setup: 0, finishing: finishingCost, extras: extrasTotal, packaging: packagingCost, shipping: shippingCost,
                              vatPercent: store.settings.includeVAT == false ? 0 : store.settings.vatPercent,
                              profitPercent: store.settings.profitMarginPercent ?? 30)
    }

    var body: some View {
        VStack(spacing: 0) {
            HStack { Text("Nuovo ordine").font(.title2.bold()); Spacer(); Button { dismiss() } label: { Image(systemName: "xmark.circle.fill") }.buttonStyle(.plain).foregroundStyle(.secondary) }.padding(22)
            Divider()
            Form {
                Section("Dettagli") {
                    Picker("Prodotto preconfigurato", selection: $selectedProductID) {
                        Text("Ordine personalizzato").tag(UUID?.none)
                        ForEach(store.products) { Text("\($0.name) · \($0.sku)").tag(Optional($0.id)) }
                    }.onChange(of: selectedProductID) { _, id in if let id, let product = store.products.first(where: { $0.id == id }) { apply(product) } }
                    TextField("Nome del progetto", text: $title)
                    Picker("Provenienza", selection: $marketplace) { ForEach(Marketplace.allCases) { Label($0.rawValue, systemImage: $0.symbol).tag($0) } }
                    if marketplace != .direct {
                        TextField("ID ordine \(marketplace.rawValue)", text: $storeOrderID)
                        TextField("Link ordine", text: $storeOrderURL)
                        if marketplace == .vinted { Button("Apri Vinted", systemImage: "arrow.up.right.square") { NSWorkspace.shared.open(URL(string: "https://www.vinted.it")!) } }
                    }
                    Picker("Cliente", selection: $customerID) {
                        Text("Cliente generico").tag(UUID?.none)
                        ForEach(store.customers) { Text("\($0.company) — \($0.name)").tag(Optional($0.id)) }
                    }
                    if store.customers.isEmpty {
                        Label("Puoi creare l’ordine ora e completare la scheda cliente in seguito.", systemImage: "info.circle")
                            .font(.caption).foregroundStyle(.secondary)
                    }
                    HStack { Picker("Materiale", selection: $material) { ForEach(Material.allCases) { Text($0.rawValue).tag($0) } }; TextField("Colore", text: $color) }
                    Stepper("Quantità: \(quantity)", value: $quantity, in: 1...999)
                    DatePicker("Scadenza", selection: $dueDate, displayedComponents: .date)
                }
                Section("Modello 3D") {
                    Button(stlFileName == nil ? "Importa file STL o 3MF" : "Sostituisci \(stlFileName!)", systemImage: "cube.transparent") { showSTLImporter = true }
                    if let previewPNG, let image = NSImage(data: previewPNG) {
                        Image(nsImage: image).resizable().scaledToFit().frame(height: 130).clipShape(RoundedRectangle(cornerRadius: 8))
                    }
                    if let volume = stlVolumeCM3 {
                        LabeledContent("Volume geometrico", value: "\(volume.formatted(.number.precision(.fractionLength(2)))) cm³")
                        LabeledContent("Dimensioni", value: stlDimensionsMM ?? "-")
                        HStack { Text("Riempimento stimato"); Slider(value: $infillPercent, in: 0...100, step: 5); Text("\(infillPercent.formatted())%").frame(width: 45) }
                        Button("Usa la stima: \(estimatedSTLWeight.formatted(.number.precision(.fractionLength(1)))) g") { weightGrams = estimatedSTLWeight }
                        Text("Stima geometrica: verifica il consumo definitivo nello slicer.").font(.caption).foregroundStyle(.secondary)
                    }
                }
                Section("Preventivo automatico") {
                    Picker("Stampante", selection: $printerID) {
                        Text("Seleziona…").tag(UUID?.none)
                        ForEach(store.printers) { Text($0.displayName).tag(Optional($0.id)) }
                    }
                    Picker("Bobina di magazzino", selection: $filamentID) {
                        Text("Costo standard \(material.rawValue)").tag(UUID?.none)
                        ForEach(store.filaments.filter { $0.material == material }) { Text("\($0.name) - \($0.remainingGrams.formatted()) g").tag(Optional($0.id)) }
                    }
                    Button(filamentUsages.isEmpty ? "Configura stampa multifilamento" : "Multifilamento: \(filamentUsages.count) bobine", systemImage: "square.3.layers.3d") { showFilaments = true }
                    Button(extraUsages.isEmpty ? "Aggiungi colla, calamite o accessori" : "Materiali aggiuntivi: \(extraUsages.count)", systemImage: "screwdriver") { showExtras = true }
                    TextField("Peso per pezzo (g)", value: $weightGrams, format: .number)
                    TextField("Ore di stampa per pezzo", value: $printHours, format: .number)
                    TextField("Finitura totale (€)", value: $finishingCost, format: .number)
                    QuoteBreakdownView(breakdown: breakdown)
                }
                Section("Imballaggio e spedizione") {
                    HStack { TextField("Lunghezza cm", value: $packageLength, format: .number); TextField("Larghezza cm", value: $packageWidth, format: .number); TextField("Altezza cm", value: $packageHeight, format: .number) }
                    Toggle("Prodotto fragile", isOn: $fragile)
                    TextField("Costo imballaggio (€)", value: $packagingCost, format: .number)
                    TextField("Costo spedizione (€)", value: $shippingCost, format: .number)
                    Label(PackagingAdvisor.advice(length: packageLength, width: packageWidth, height: packageHeight, weightGrams: weightGrams * Double(quantity), fragile: fragile), systemImage: "sparkles")
                        .font(.callout).foregroundStyle(.secondary)
                }
                Section("Note di produzione") { TextEditor(text: $notes).frame(height: 70) }
            }.formStyle(.grouped)
            Divider()
            HStack { Text(title.trimmingCharacters(in: .whitespaces).isEmpty ? "Inserisci almeno il nome del progetto" : "Totale: \(breakdown.total.euro)").font(.caption).foregroundStyle(.secondary); Spacer(); Button("Annulla") { dismiss() }; Button("Crea ordine") { create() }.keyboardShortcut(.defaultAction).buttonStyle(.borderedProminent).controlSize(.large).tint(CleanWorkshopTheme.purple).disabled(title.trimmingCharacters(in: .whitespaces).isEmpty) }.padding(18)
        }.frame(width: 580, height: 740)
        .onAppear { customerID = store.customers.first?.id; printerID = store.printers.first?.id }
        .sheet(isPresented: $showFilaments) { MultiFilamentEditor(usages: $filamentUsages) }
        .sheet(isPresented: $showExtras) { ExtraUsageEditor(usages: $extraUsages) }
        .fileImporter(isPresented: $showSTLImporter, allowedContentTypes: [UTType(filenameExtension: "stl")!, UTType(filenameExtension: "3mf")!]) { result in importSTL(result) }
        .alert("Impossibile importare lo STL", isPresented: Binding(get: { importError != nil }, set: { if !$0 { importError = nil } })) { Button("OK") {} } message: { Text(importError ?? "") }
    }

    private func create() {
        let resolvedCustomerID: UUID
        if let customerID {
            resolvedCustomerID = customerID
        } else if let existing = store.customers.first(where: { $0.name == "Cliente generico" }) {
            resolvedCustomerID = existing.id
        } else {
            let generic = Customer(name: "Cliente generico", company: "Privato", email: "", phone: "")
            store.customers.append(generic)
            resolvedCustomerID = generic.id
        }
        let next = (store.orders.compactMap { Int($0.code.replacingOccurrences(of: "3D-", with: "")) }.max() ?? 1000) + 1
        store.add(PrintOrder(code: "3D-\(next)", title: title, customerID: resolvedCustomerID, material: material, color: color, quantity: quantity, price: breakdown.total, dueDate: dueDate, status: marketplace == .direct ? .confirmed : .quote, notes: notes, weightGrams: weightGrams, printHours: printHours, setupCost: 0, finishingCost: finishingCost, printerID: printerID, filamentID: filamentID, filamentUsages: filamentUsages, extraUsages: extraUsages, stlFileName: stlFileName, stlVolumeCM3: stlVolumeCM3, stlDimensionsMM: stlDimensionsMM, previewPNG: previewPNG, infillPercent: infillPercent, marketplace: marketplace, storeOrderID: storeOrderID.isEmpty ? nil : storeOrderID, storeOrderURL: storeOrderURL.isEmpty ? nil : storeOrderURL, packagingCost: packagingCost, shippingCost: shippingCost, packageLengthCM: packageLength, packageWidthCM: packageWidth, packageHeightCM: packageHeight, fragile: fragile))
        dismiss()
    }

    private func apply(_ product: ProductTemplate) {
        title = product.name; material = product.material; color = product.color; weightGrams = product.weightGrams
        printHours = product.printHours; quantity = product.defaultQuantity; finishingCost = product.finishingCost; notes = product.notes
    }

    private var estimatedSTLWeight: Double {
        guard let volume = stlVolumeCM3 else { return 0 }
        let fraction = 0.20 + 0.80 * infillPercent / 100
        return volume * material.densityGramsPerCM3 * fraction
    }

    private func importSTL(_ result: Result<URL, Error>) {
        do {
            let url = try result.get(); let access = url.startAccessingSecurityScopedResource(); defer { if access { url.stopAccessingSecurityScopedResource() } }
            let analysis = try (url.pathExtension.lowercased() == "3mf" ? STLAnalyzer.analyze3MF(url: url) : STLAnalyzer.analyze(url: url))
            stlFileName = analysis.fileName; stlVolumeCM3 = analysis.volumeCM3
            stlDimensionsMM = "\(analysis.dimensionsMM.x.formatted(.number.precision(.fractionLength(1)))) × \(analysis.dimensionsMM.y.formatted(.number.precision(.fractionLength(1)))) × \(analysis.dimensionsMM.z.formatted(.number.precision(.fractionLength(1)))) mm"
            previewPNG = analysis.previewPNG; weightGrams = analysis.estimatedGrams(material: material, infillPercent: infillPercent)
        } catch { importError = error.localizedDescription }
    }
}

struct EditOrderView: View {
    @EnvironmentObject private var store: OrderStore
    @Environment(\.dismiss) private var dismiss
    @State private var draft: PrintOrder
    @State private var showFilaments = false
    @State private var showExtras = false
    @State private var showSTLImporter = false
    @State private var importError: String?

    init(order: PrintOrder) { _draft = State(initialValue: order) }

    private var breakdown: QuoteBreakdown { store.quote(for: draft) }

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                VStack(alignment: .leading) {
                    Text("Modifica ordine").font(.title2.bold())
                    Text(draft.code).foregroundStyle(.secondary)
                }
                Spacer()
                Button { dismiss() } label: { Image(systemName: "xmark.circle.fill") }.buttonStyle(.plain).foregroundStyle(.secondary)
            }.padding(22)
            Divider()
            Form {
                Section("Dettagli") {
                    TextField("Nome del progetto", text: $draft.title)
                    Picker("Provenienza", selection: Binding(get: { draft.marketplace ?? .direct }, set: { draft.marketplace = $0 })) { ForEach(Marketplace.allCases) { Label($0.rawValue, systemImage: $0.symbol).tag($0) } }
                    if (draft.marketplace ?? .direct) != .direct {
                        TextField("ID ordine store", text: Binding(get: { draft.storeOrderID ?? "" }, set: { draft.storeOrderID = $0 }))
                        TextField("Link ordine store", text: Binding(get: { draft.storeOrderURL ?? "" }, set: { draft.storeOrderURL = $0 }))
                        if let text = draft.storeOrderURL, let url = URL(string: text), !text.isEmpty { Button("Apri ordine nello store", systemImage: "arrow.up.right.square") { NSWorkspace.shared.open(url) } }
                    }
                    Picker("Cliente", selection: $draft.customerID) {
                        ForEach(store.customers) { Text("\($0.company) — \($0.name)").tag($0.id) }
                    }
                    Picker("Stato", selection: $draft.status) { ForEach(OrderStatus.allCases) { Text($0.rawValue).tag($0) } }
                    HStack {
                        Picker("Materiale", selection: $draft.material) { ForEach(Material.allCases) { Text($0.rawValue).tag($0) } }
                        TextField("Colore", text: $draft.color)
                    }
                    Stepper("Quantità: \(draft.quantity)", value: $draft.quantity, in: 1...999)
                    DatePicker("Scadenza", selection: $draft.dueDate, displayedComponents: .date)
                }
                Section("Spedizione") {
                    Picker("Canale / corriere", selection: Binding(get: { draft.trackingCarrier ?? "Vinted" }, set: { draft.trackingCarrier = $0 })) {
                        ForEach(["Vinted", "Vinted Go", "Poste Italiane", "BRT", "GLS", "DHL", "UPS", "Altro"], id: \.self) { Text($0).tag($0) }
                    }
                    TextField("Codice tracking", text: Binding(get: { draft.trackingCode ?? "" }, set: { draft.trackingCode = $0 }))
                    TextField("Link di tracciamento", text: Binding(get: { draft.trackingURL ?? "" }, set: { draft.trackingURL = $0 }))
                    Picker("Stato spedizione", selection: Binding(get: { draft.shipmentStatus ?? .notShipped }, set: { draft.shipmentStatus = $0; if $0 == .delivered { draft.status = .delivered } })) {
                        ForEach(ShipmentStatus.allCases) { Text($0.rawValue).tag($0) }
                    }
                    HStack {
                        if draft.trackingCarrier?.localizedCaseInsensitiveContains("vinted") == true {
                            Button("Apri Vinted", systemImage: "safari") { if let url = URL(string: draft.trackingURL ?? "https://www.vinted.it") { NSWorkspace.shared.open(url) } }
                        } else if let text = draft.trackingURL, let url = URL(string: text), !text.isEmpty {
                            Button("Apri tracking", systemImage: "safari") { NSWorkspace.shared.open(url) }
                        }
                        Spacer()
                        if draft.shipmentStatus != .delivered { Button("Segna consegnato", systemImage: "checkmark.circle") { draft.shipmentStatus = .delivered; draft.status = .delivered } }
                    }
                    Text("Quando lo stato diventa Consegnato, l’ordine viene spostato automaticamente in Completati.").font(.caption).foregroundStyle(.secondary)
                }
                Section("Imballaggio e costi") {
                    HStack {
                        TextField("L cm", value: $draft.packageLengthCM, format: .number)
                        TextField("P cm", value: $draft.packageWidthCM, format: .number)
                        TextField("H cm", value: $draft.packageHeightCM, format: .number)
                    }
                    Toggle("Prodotto fragile", isOn: Binding(get: { draft.fragile ?? false }, set: { draft.fragile = $0 }))
                    TextField("Costo imballaggio (€)", value: $draft.packagingCost, format: .number)
                    TextField("Costo spedizione (€)", value: $draft.shippingCost, format: .number)
                    Label(PackagingAdvisor.advice(length: draft.packageLengthCM ?? 20, width: draft.packageWidthCM ?? 15, height: draft.packageHeightCM ?? 10, weightGrams: (draft.weightGrams ?? 0) * Double(draft.quantity), fragile: draft.fragile ?? false), systemImage: "sparkles")
                        .font(.callout).foregroundStyle(.secondary)
                }
                Section("Modello 3D") {
                    Button(draft.stlFileName == nil ? "Importa file STL o 3MF" : "Sostituisci \(draft.stlFileName!)", systemImage: "cube.transparent") { showSTLImporter = true }
                    if let data = draft.previewPNG, let image = NSImage(data: data) { Image(nsImage: image).resizable().scaledToFit().frame(height: 130).clipShape(RoundedRectangle(cornerRadius: 8)) }
                    if let volume = draft.stlVolumeCM3 {
                        LabeledContent("Volume geometrico", value: "\(volume.formatted(.number.precision(.fractionLength(2)))) cm³")
                        LabeledContent("Dimensioni", value: draft.stlDimensionsMM ?? "-")
                        HStack { Text("Riempimento"); Slider(value: Binding(get: { draft.infillPercent ?? 20 }, set: { draft.infillPercent = $0 }), in: 0...100, step: 5); Text("\((draft.infillPercent ?? 20).formatted())%") }
                        Button("Ricalcola peso dallo STL") { recalculateSTLWeight() }
                    }
                }
                Section("Preventivo automatico") {
                    Picker("Stampante", selection: $draft.printerID) {
                        Text("Seleziona…").tag(UUID?.none)
                        ForEach(store.printers) { Text($0.displayName).tag(Optional($0.id)) }
                    }
                    Picker("Bobina di magazzino", selection: $draft.filamentID) {
                        Text("Costo standard \(draft.material.rawValue)").tag(UUID?.none)
                        ForEach(store.filaments.filter { $0.material == draft.material }) { Text("\($0.name) - \($0.remainingGrams.formatted()) g").tag(Optional($0.id)) }
                    }
                    Button((draft.filamentUsages ?? []).isEmpty ? "Configura stampa multifilamento" : "Multifilamento: \((draft.filamentUsages ?? []).count) bobine", systemImage: "square.3.layers.3d") { showFilaments = true }
                    Button((draft.extraUsages ?? []).isEmpty ? "Aggiungi colla, calamite o accessori" : "Materiali aggiuntivi: \((draft.extraUsages ?? []).count)", systemImage: "screwdriver") { showExtras = true }
                    TextField("Peso per pezzo (g)", value: $draft.weightGrams, format: .number)
                    TextField("Ore di stampa per pezzo", value: $draft.printHours, format: .number)
                    TextField("Finitura totale (€)", value: $draft.finishingCost, format: .number)
                    QuoteBreakdownView(breakdown: breakdown)
                }
                Section("Note di produzione") { TextEditor(text: $draft.notes).frame(height: 65) }
            }.formStyle(.grouped)
            Divider()
            HStack {
                Spacer()
                Button("Annulla") { dismiss() }
                Button("Esporta PDF", systemImage: "arrow.down.doc") { QuotePDFExporter.export(order: draft, store: store) }
                Button("Salva modifiche") {
                    draft.price = breakdown.total
                    store.update(draft)
                    dismiss()
                }.buttonStyle(.borderedProminent).tint(.purple).disabled(draft.title.trimmingCharacters(in: .whitespaces).isEmpty)
            }.padding(18)
        }.frame(width: 590, height: 780)
        .sheet(isPresented: $showFilaments) {
            MultiFilamentEditor(usages: Binding(
                get: { draft.filamentUsages ?? [] },
                set: { draft.filamentUsages = $0 }
            ))
        }
        .sheet(isPresented: $showExtras) {
            ExtraUsageEditor(usages: Binding(get: { draft.extraUsages ?? [] }, set: { draft.extraUsages = $0 }))
        }
        .fileImporter(isPresented: $showSTLImporter, allowedContentTypes: [UTType(filenameExtension: "stl")!, UTType(filenameExtension: "3mf")!]) { result in importSTL(result) }
        .alert("Impossibile importare lo STL", isPresented: Binding(get: { importError != nil }, set: { if !$0 { importError = nil } })) { Button("OK") {} } message: { Text(importError ?? "") }
    }

    private func recalculateSTLWeight() {
        guard let volume = draft.stlVolumeCM3 else { return }
        let fraction = 0.20 + 0.80 * (draft.infillPercent ?? 20) / 100
        draft.weightGrams = volume * draft.material.densityGramsPerCM3 * fraction
    }
    private func importSTL(_ result: Result<URL, Error>) {
        do {
            let url = try result.get(); let access = url.startAccessingSecurityScopedResource(); defer { if access { url.stopAccessingSecurityScopedResource() } }
            let analysis = try (url.pathExtension.lowercased() == "3mf" ? STLAnalyzer.analyze3MF(url: url) : STLAnalyzer.analyze(url: url))
            draft.stlFileName = analysis.fileName; draft.stlVolumeCM3 = analysis.volumeCM3
            draft.stlDimensionsMM = "\(analysis.dimensionsMM.x.formatted(.number.precision(.fractionLength(1)))) × \(analysis.dimensionsMM.y.formatted(.number.precision(.fractionLength(1)))) × \(analysis.dimensionsMM.z.formatted(.number.precision(.fractionLength(1)))) mm"
            draft.previewPNG = analysis.previewPNG; draft.infillPercent = draft.infillPercent ?? 20; recalculateSTLWeight()
        } catch { importError = error.localizedDescription }
    }
}

struct MultiFilamentEditor: View {
    @EnvironmentObject private var store: OrderStore
    @Environment(\.dismiss) private var dismiss
    @Binding var usages: [FilamentUsage]

    var body: some View {
        VStack(spacing: 16) {
            HStack {
                VStack(alignment: .leading) {
                    Text("Stampa multifilamento").font(.title2.bold())
                    Text("Indica i grammi per pezzo usati da ciascuna bobina.").foregroundStyle(.secondary)
                }
                Spacer()
                Button("Aggiungi bobina", systemImage: "plus") {
                    if let first = store.filaments.first { usages.append(FilamentUsage(filamentID: first.id, gramsPerPiece: 10)) }
                }.disabled(store.filaments.isEmpty)
            }
            if usages.isEmpty {
                ContentUnavailableView("Una sola bobina", systemImage: "cylinder", description: Text("Aggiungi almeno due bobine per una stampa multifilamento."))
            } else {
                List {
                    ForEach($usages) { $usage in
                        HStack {
                            Picker("Bobina", selection: $usage.filamentID) {
                                ForEach(store.filaments) { Text("\($0.name) (\($0.material.rawValue))").tag($0.id) }
                            }
                            TextField("Grammi/pezzo", value: $usage.gramsPerPiece, format: .number).frame(width: 110)
                            Text("g/pezzo").foregroundStyle(.secondary)
                            Button(role: .destructive) { usages.removeAll { $0.id == usage.id } } label: { Image(systemName: "trash") }.buttonStyle(.borderless)
                        }
                    }
                }
            }
            HStack {
                Text("Peso totale per pezzo: \(usages.reduce(0) { $0 + $1.gramsPerPiece }.formatted()) g").fontWeight(.semibold)
                Spacer()
                Button("Fine") { dismiss() }.buttonStyle(.borderedProminent).tint(.purple)
            }
        }.padding(24).frame(width: 650, height: 430)
    }
}

struct QuoteBreakdownView: View {
    let breakdown: QuoteBreakdown
    var body: some View {
        Group {
            LabeledContent("Materiale", value: breakdown.material.euro)
            LabeledContent("Energia", value: breakdown.energy.euro)
            LabeledContent("Usura macchina", value: breakdown.wear.euro)
            LabeledContent("Finitura", value: breakdown.finishing.euro)
            LabeledContent("Materiali aggiuntivi", value: breakdown.extras.euro)
            LabeledContent("Imballaggio", value: breakdown.packaging.euro)
            LabeledContent("Spedizione", value: breakdown.shipping.euro)
            Divider()
            LabeledContent("Costi diretti", value: breakdown.directCosts.euro)
            LabeledContent("Guadagno ((breakdown.profitPercent.formatted())%)") { Text(breakdown.profit.euro).foregroundStyle(.green).fontWeight(.semibold) }
            LabeledContent("Imponibile", value: breakdown.subtotal.euro)
            LabeledContent("IVA (\(breakdown.vatPercent.formatted())%)", value: breakdown.vat.euro)
            LabeledContent("Totale preventivo") { Text(breakdown.total.euro).font(.title3.bold()).foregroundStyle(.purple) }
        }
    }
}

struct ExtraUsageEditor: View {
    @EnvironmentObject private var store: OrderStore
    @Environment(\.dismiss) private var dismiss
    @Binding var usages: [ExtraUsage]
    var body: some View {
        VStack(spacing: 16) {
            HStack {
                VStack(alignment: .leading) { Text("Materiali aggiuntivi").font(.title2.bold()); Text("Colla, calamite, anelli e altri consumabili.").foregroundStyle(.secondary) }
                Spacer()
                Button("Aggiungi", systemImage: "plus") { if let first = store.extraMaterials.first { usages.append(ExtraUsage(materialID: first.id, quantity: 1)) } }.disabled(store.extraMaterials.isEmpty)
            }
            List {
                ForEach($usages) { $usage in
                    HStack {
                        Picker("Materiale", selection: $usage.materialID) { ForEach(store.extraMaterials) { Text("\($0.name) - \($0.unitCost.euro)/\($0.unit)").tag($0.id) } }
                        TextField("Quantità", value: $usage.quantity, format: .number).frame(width: 100)
                        Button(role: .destructive) { usages.removeAll { $0.id == usage.id } } label: { Image(systemName: "trash") }.buttonStyle(.borderless)
                    }
                }
            }
            HStack { Text("Totale: \(usages.reduce(0) { result, usage in result + usage.quantity * (store.extraMaterials.first { $0.id == usage.materialID }?.unitCost ?? 0) }.euro)").fontWeight(.semibold); Spacer(); Button("Fine") { dismiss() }.buttonStyle(.borderedProminent).tint(.purple) }
        }.padding(24).frame(width: 650, height: 420)
    }
}
