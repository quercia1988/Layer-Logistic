import SwiftUI

enum CleanWorkshopTheme {
    static let purple = Color(red: 0.38, green: 0.25, blue: 0.91)
    static let violet = Color(red: 0.55, green: 0.38, blue: 0.96)
    static let cyan = Color(red: 0.08, green: 0.70, blue: 0.82)
    static let canvas = Color(nsColor: .underPageBackgroundColor)
    static let card = Color(nsColor: .textBackgroundColor)
    static let sidebar = Color(nsColor: .controlBackgroundColor)
    static let softPurple = purple.opacity(0.09)
    static let border = Color.secondary.opacity(0.14)
    static let strongBorder = purple.opacity(0.18)
    static let heroGradient = LinearGradient(colors: [purple, violet, cyan], startPoint: .topLeading, endPoint: .bottomTrailing)
}

extension View {
    func workshopCard(radius: CGFloat = 14) -> some View {
        background(CleanWorkshopTheme.card)
            .clipShape(RoundedRectangle(cornerRadius: radius, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: radius, style: .continuous).stroke(CleanWorkshopTheme.border))
            .shadow(color: CleanWorkshopTheme.purple.opacity(0.045), radius: 12, y: 5)
    }

    func workshopPage() -> some View {
        background(
            ZStack {
                CleanWorkshopTheme.canvas
                RadialGradient(colors: [CleanWorkshopTheme.purple.opacity(0.055), .clear], center: .topTrailing, startRadius: 0, endRadius: 520)
            }.ignoresSafeArea()
        )
    }
}

extension OrderStatus {
    var color: Color {
        switch self {
        case .quote: .gray
        case .confirmed: .blue
        case .printing: .purple
        case .finishing: .orange
        case .ready: .green
        case .delivered: .teal
        }
    }
}

extension Double {
    var euro: String { formatted(.currency(code: "EUR").locale(Locale(identifier: "it_IT"))) }
}
