import Foundation
import Vision

struct PrinterQRConfiguration {
    let type: PrinterConnectionType
    let url: String
    let apiKey: String?
}

enum PrinterQRCode {
    static func read(from imageURL: URL) throws -> PrinterQRConfiguration {
        let request = VNDetectBarcodesRequest()
        request.symbologies = [.qr]
        let handler = VNImageRequestHandler(url: imageURL)
        try handler.perform([request])
        guard let value = request.results?.first?.payloadStringValue, !value.isEmpty else {
            throw QRCodeError.notFound
        }
        return try parse(value)
    }

    static func parse(_ payload: String) throws -> PrinterQRConfiguration {
        let trimmed = payload.trimmingCharacters(in: .whitespacesAndNewlines)

        if let data = trimmed.data(using: .utf8),
           let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
            let url = (json["url"] ?? json["address"] ?? json["host"]) as? String
            guard let url, !url.isEmpty else { throw QRCodeError.unsupported }
            return PrinterQRConfiguration(type: type(from: json["protocol"] as? String ?? json["type"] as? String),
                                          url: normalized(url),
                                          apiKey: json["apiKey"] as? String ?? json["api_key"] as? String)
        }

        if let components = URLComponents(string: trimmed),
           components.scheme?.lowercased() == "layerlogistic" {
            let values = Dictionary(uniqueKeysWithValues: (components.queryItems ?? []).map { ($0.name.lowercased(), $0.value ?? "") })
            guard let url = values["url"] ?? values["address"] ?? values["host"], !url.isEmpty else { throw QRCodeError.unsupported }
            return PrinterQRConfiguration(type: type(from: values["type"] ?? values["protocol"]),
                                          url: normalized(url), apiKey: values["apikey"] ?? values["api_key"])
        }

        if trimmed.lowercased().hasPrefix("http://") || trimmed.lowercased().hasPrefix("https://") {
            return PrinterQRConfiguration(type: guessedType(from: trimmed), url: normalized(trimmed), apiKey: nil)
        }

        if isIPAddressOrHost(trimmed) {
            return PrinterQRConfiguration(type: .moonraker, url: normalized(trimmed), apiKey: nil)
        }
        throw QRCodeError.unsupported
    }

    private static func type(from value: String?) -> PrinterConnectionType {
        let value = value?.lowercased() ?? ""
        return value.contains("octo") ? .octoPrint : .moonraker
    }

    private static func guessedType(from value: String) -> PrinterConnectionType {
        value.lowercased().contains("octo") ? .octoPrint : .moonraker
    }

    private static func normalized(_ value: String) -> String {
        let clean = value.trimmingCharacters(in: .whitespacesAndNewlines)
        return clean.contains("://") ? clean : "http://" + clean
    }

    private static func isIPAddressOrHost(_ value: String) -> Bool {
        !value.contains(" ") && (value.contains(".") || value.contains(":"))
    }
}

private enum QRCodeError: LocalizedError {
    case notFound, unsupported
    var errorDescription: String? {
        switch self {
        case .notFound: "Nell’immagine non è stato trovato un QR code leggibile."
        case .unsupported: "Il QR è stato letto, ma non contiene un indirizzo LAN compatibile con Moonraker o OctoPrint. Potrebbe essere un codice proprietario del produttore."
        }
    }
}
