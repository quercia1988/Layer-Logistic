import Foundation
import Security

@MainActor
final class TelegramBotService: ObservableObject {
    @Published private(set) var isRunning = false
    @Published private(set) var botName: String?
    @Published private(set) var status = "Bot non configurato"
    @Published private(set) var lastChatID: String?

    private weak var store: OrderStore?
    private var pollingTask: Task<Void, Never>?
    private var offset: Int64 = 0
    private let keychain = TelegramTokenKeychain()

    var hasToken: Bool { keychain.read() != nil }

    func attach(_ store: OrderStore) { self.store = store }

    func saveAndVerify(token: String) async {
        let clean = token.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { status = "Inserisci il token ricevuto da BotFather"; return }
        do {
            try keychain.save(clean)
            let me: TGUser = try await call("getMe", token: clean)
            botName = me.username.map { "@\($0)" } ?? me.firstName
            status = "Connessione riuscita"
            objectWillChange.send()
            if store?.settings.telegramBotEnabled == true { start() }
        } catch {
            status = "Verifica non riuscita: \(error.localizedDescription)"
        }
    }

    func removeToken() {
        stop()
        keychain.remove()
        botName = nil
        status = "Token rimosso"
        objectWillChange.send()
    }

    func start() {
        guard pollingTask == nil else { return }
        guard keychain.read() != nil else { status = "Salva prima il token del bot"; return }
        isRunning = true
        status = "In ascolto degli ordini"
        pollingTask = Task { [weak self] in await self?.poll() }
    }

    func stop() {
        pollingTask?.cancel()
        pollingTask = nil
        isRunning = false
        status = hasToken ? "Bot in pausa" : "Bot non configurato"
    }

    private func poll() async {
        while !Task.isCancelled {
            guard let token = keychain.read() else { break }
            do {
                let updates: [TGUpdate] = try await call("getUpdates", token: token, query: [
                    URLQueryItem(name: "offset", value: String(offset)),
                    URLQueryItem(name: "timeout", value: "25"),
                    URLQueryItem(name: "allowed_updates", value: "[\"message\"]")
                ], timeout: 35)
                for update in updates {
                    offset = max(offset, update.updateID + 1)
                    if let message = update.message { await handle(message, token: token) }
                }
                if !Task.isCancelled { status = "In ascolto degli ordini" }
            } catch is CancellationError { break }
            catch {
                status = "Connessione interrotta, nuovo tentativo…"
                try? await Task.sleep(nanoseconds: 3_000_000_000)
            }
        }
        if Task.isCancelled { return }
        isRunning = false
        pollingTask = nil
    }

    private func handle(_ message: TGMessage, token: String) async {
        guard let text = message.text?.trimmingCharacters(in: .whitespacesAndNewlines) else { return }
        let chatID = String(message.chat.id)
        lastChatID = chatID
        if text.lowercased().hasPrefix("/id") {
            await reply("Il tuo Chat ID è: \(chatID)", chatID: chatID, token: token)
            return
        }
        let allowed = store?.settings.telegramAllowedChatID?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        guard !allowed.isEmpty, allowed == chatID else {
            await reply("Chat non autorizzata. In Layer Logistic inserisci questo Chat ID: \(chatID)", chatID: chatID, token: token)
            return
        }
        if text.lowercased().hasPrefix("/start") || text.lowercased().hasPrefix("/aiuto") {
            await reply(instructions, chatID: chatID, token: token)
        } else if text.lowercased().hasPrefix("/stato") {
            let waiting = store?.orders.filter { $0.status == .quote }.count ?? 0
            let active = store?.orders.filter { $0.status == .printing }.count ?? 0
            await reply("Layer Logistic: \(waiting) in attesa, \(active) in stampa.", chatID: chatID, token: token)
        } else if text.lowercased().hasPrefix("/ordine") {
            await createOrder(from: text, chatID: chatID, token: token)
        } else {
            await reply(instructions, chatID: chatID, token: token)
        }
    }

    private func createOrder(from text: String, chatID: String, token: String) async {
        guard let store else { return }
        let body = text.dropFirst(text.firstIndex(of: " ").map { text.distance(from: text.startIndex, to: $0) + 1 } ?? text.count)
        let fields = body.split(separator: "|", omittingEmptySubsequences: false).map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
        guard fields.count >= 4, !fields[0].isEmpty, !fields[1].isEmpty, let quantity = Int(fields[2]), quantity > 0 else {
            await reply("Formato non valido.\n\(instructions)", chatID: chatID, token: token); return
        }
        let customerName = fields[0]
        let customer: Customer
        if let existing = store.customers.first(where: { $0.name.localizedCaseInsensitiveCompare(customerName) == .orderedSame || $0.company.localizedCaseInsensitiveCompare(customerName) == .orderedSame }) {
            customer = existing
        } else {
            customer = Customer(name: customerName, company: customerName, email: "", phone: "")
            store.customers.append(customer)
        }
        let product = store.products.first { $0.name.localizedCaseInsensitiveCompare(fields[1]) == .orderedSame || $0.sku.localizedCaseInsensitiveCompare(fields[1]) == .orderedSame }
        let formatter = DateFormatter(); formatter.dateFormat = "dd/MM/yyyy"; formatter.locale = Locale(identifier: "it_IT")
        let dueDate = formatter.date(from: fields[3]) ?? Calendar.current.date(byAdding: .day, value: 7, to: .now)!
        let next = (store.orders.compactMap { Int($0.code.replacingOccurrences(of: "3D-", with: "")) }.max() ?? 1000) + 1
        var order = PrintOrder(code: "3D-\(next)", title: product?.name ?? fields[1], customerID: customer.id,
                               material: product?.material ?? .pla, color: product?.color ?? "Da definire", quantity: quantity,
                               price: 0, dueDate: dueDate, status: .quote, notes: "Ordine ricevuto tramite bot Telegram",
                               weightGrams: product?.weightGrams, printHours: product?.printHours, setupCost: 0,
                               finishingCost: product?.finishingCost, marketplace: .telegram, storeOrderID: "TG-\(chatID)")
        order.price = store.quote(for: order).total
        store.add(order)
        status = "Ricevuto \(order.code) da Telegram"
        await reply("✅ Ordine \(order.code) creato\n\(order.title) × \(quantity)\nPreventivo: \(order.price.formatted(.currency(code: "EUR")))\nScadenza: \(formatter.string(from: dueDate))", chatID: chatID, token: token)
    }

    private var instructions: String {
        "Invia:\n/ordine Cliente | Prodotto o SKU | Quantità | gg/mm/aaaa\n\nComandi: /id, /stato, /aiuto"
    }

    private func reply(_ text: String, chatID: String, token: String) async {
        var request = URLRequest(url: endpoint("sendMessage", token: token))
        request.httpMethod = "POST"; request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try? JSONEncoder().encode(TGSendMessage(chatID: chatID, text: text))
        _ = try? await URLSession.shared.data(for: request)
    }

    private func endpoint(_ method: String, token: String) -> URL {
        URL(string: "https://api.telegram.org/bot\(token)/\(method)")!
    }

    private func call<T: Decodable>(_ method: String, token: String, query: [URLQueryItem] = [], timeout: TimeInterval = 15) async throws -> T {
        var components = URLComponents(url: endpoint(method, token: token), resolvingAgainstBaseURL: false)!
        components.queryItems = query.isEmpty ? nil : query
        var request = URLRequest(url: components.url!); request.timeoutInterval = timeout
        let (data, response) = try await URLSession.shared.data(for: request)
        guard (response as? HTTPURLResponse)?.statusCode == 200 else { throw TelegramError.connection }
        let envelope = try JSONDecoder().decode(TGResponse<T>.self, from: data)
        guard envelope.ok, let result = envelope.result else { throw TelegramError.api(envelope.description ?? "Errore Telegram") }
        return result
    }
}

private enum TelegramError: LocalizedError {
    case connection, api(String)
    var errorDescription: String? { switch self { case .connection: "Connessione non riuscita"; case .api(let message): message } }
}
private struct TGResponse<T: Decodable>: Decodable { let ok: Bool; let result: T?; let description: String? }
private struct TGUpdate: Decodable { let updateID: Int64; let message: TGMessage?; enum CodingKeys: String, CodingKey { case updateID = "update_id", message } }
private struct TGMessage: Decodable { let chat: TGChat; let text: String? }
private struct TGChat: Decodable { let id: Int64 }
private struct TGUser: Decodable { let username: String?; let firstName: String; enum CodingKeys: String, CodingKey { case username; case firstName = "first_name" } }
private struct TGSendMessage: Encodable { let chatID: String; let text: String; enum CodingKeys: String, CodingKey { case chatID = "chat_id", text } }

private struct TelegramTokenKeychain {
    private let service = "it.layerlogistic.telegram"
    private let account = "bot-token"
    func read() -> String? {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: account, kSecReturnData as String: true, kSecMatchLimit as String: kSecMatchLimitOne]
        var item: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &item) == errSecSuccess, let data = item as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }
    func save(_ token: String) throws {
        let key: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: account]
        let data = Data(token.utf8)
        let status = SecItemUpdate(key as CFDictionary, [kSecValueData as String: data] as CFDictionary)
        if status == errSecItemNotFound {
            var add = key; add[kSecValueData as String] = data
            guard SecItemAdd(add as CFDictionary, nil) == errSecSuccess else { throw TelegramError.connection }
        } else if status != errSecSuccess { throw TelegramError.connection }
    }
    func remove() { SecItemDelete([kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: account] as CFDictionary) }
}
