// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "PrintFlow",
    platforms: [.macOS(.v14)],
    products: [.executable(name: "PrintFlow", targets: ["PrintFlow"])],
    targets: [.executableTarget(name: "PrintFlow")]
)
