import Foundation

enum OrderStatus: String, Codable, CaseIterable, Identifiable {
    case quote = "Preventivo"
    case confirmed = "Confermato"
    case printing = "In stampa"
    case finishing = "Finitura"
    case ready = "Pronto"
    case delivered = "Consegnato"

    var id: String { rawValue }
    var symbol: String {
        switch self {
        case .quote: "doc.text"
        case .confirmed: "checkmark.seal"
        case .printing: "printer.fill"
        case .finishing: "wand.and.stars"
        case .ready: "shippingbox.fill"
        case .delivered: "checkmark.circle.fill"
        }
    }
}

enum Material: String, Codable, CaseIterable, Identifiable {
    case pla = "PLA", petg = "PETG", abs = "ABS", resin = "Resina", tpu = "TPU", other = "Altro"
    var id: String { rawValue }

    var pricePerGram: Double {
        switch self {
        case .pla: 0.06
        case .petg: 0.075
        case .abs: 0.08
        case .resin: 0.16
        case .tpu: 0.12
        case .other: 0.10
        }
    }

    var densityGramsPerCM3: Double {
        switch self {
        case .pla: 1.24
        case .petg: 1.27
        case .abs: 1.04
        case .resin: 1.10
        case .tpu: 1.21
        case .other: 1.20
        }
    }
}

struct Customer: Identifiable, Codable, Hashable {
    var id = UUID()
    var name: String
    var company: String
    var email: String
    var phone: String
    var address: String?
    var city: String?
    var postalCode: String?
    var province: String?
    var vatNumber: String?
    var taxCode: String?
    var notes: String?
}

struct PrintOrder: Identifiable, Codable, Hashable {
    var id = UUID()
    var code: String
    var title: String
    var customerID: UUID
    var material: Material
    var color: String
    var quantity: Int
    var price: Double
    var dueDate: Date
    var status: OrderStatus
    var notes: String
    var createdAt = Date()
    var weightGrams: Double?
    var printHours: Double?
    var setupCost: Double?
    var finishingCost: Double?
    var printerID: UUID?
    var filamentID: UUID?
    var filamentUsages: [FilamentUsage]?
    var extraUsages: [ExtraUsage]?
    var stlFileName: String?
    var stlVolumeCM3: Double?
    var stlDimensionsMM: String?
    var previewPNG: Data?
    var infillPercent: Double?
    var trackingCarrier: String?
    var trackingCode: String?
    var trackingURL: String?
    var shipmentStatus: ShipmentStatus?
    var marketplace: Marketplace?
    var storeOrderID: String?
    var storeOrderURL: String?
    var packagingCost: Double?
    var shippingCost: Double?
    var packageLengthCM: Double?
    var packageWidthCM: Double?
    var packageHeightCM: Double?
    var fragile: Bool?

    var calculatedQuote: Double {
        QuoteCalculator.total(material: material,
                              weightGrams: weightGrams ?? 0,
                              printHours: printHours ?? 0,
                              quantity: quantity,
                              setupCost: setupCost ?? 0,
                              finishingCost: finishingCost ?? 0)
    }
}

struct FilamentUsage: Identifiable, Codable, Hashable {
    var id = UUID()
    var filamentID: UUID
    var gramsPerPiece: Double
}

struct ExtraMaterial: Identifiable, Codable, Hashable {
    var id = UUID()
    var name: String
    var unit: String
    var stockQuantity: Double
    var unitCost: Double
    var minimumStock: Double?
}

struct ExtraUsage: Identifiable, Codable, Hashable {
    var id = UUID()
    var materialID: UUID
    var quantity: Double
}

enum ShipmentStatus: String, Codable, CaseIterable, Identifiable {
    case notShipped = "Non spedito"
    case shipped = "Spedito"
    case inTransit = "In transito"
    case readyForPickup = "In consegna/ritiro"
    case delivered = "Consegnato"
    var id: String { rawValue }
}

enum Marketplace: String, Codable, CaseIterable, Identifiable {
    case direct = "Diretto"
    case etsy = "Etsy"
    case vinted = "Vinted"
    case telegram = "Telegram"
    var id: String { rawValue }
    var symbol: String {
        switch self { case .direct: "person.crop.circle"; case .etsy: "storefront"; case .vinted: "tag"; case .telegram: "paperplane.fill" }
    }
}

struct PrinterProfile: Identifiable, Codable, Hashable {
    var id = UUID()
    var manufacturer: String
    var model: String
    var consumptionWatts: Double
    var wearCostPerHour: Double
    var isCustom = false
    var imagePNG: Data?
    var totalWorkHours: Double?
    var maintenanceIntervalHours: Double?
    var lastMaintenanceAtHours: Double?
    var maintenanceNotes: String?
    var connectionType: PrinterConnectionType?
    var connectionURL: String?
    var connectionAPIKey: String?
    var smartPlugProvider: SmartPlugProvider?
    var smartPlugURL: String?
    var smartPlugToken: String?
    var smartPlugPowerEntityID: String?
    var smartPlugEnergyEntityID: String?

    var displayName: String { "\(manufacturer) \(model)" }
    var hoursUntilMaintenance: Double {
        (lastMaintenanceAtHours ?? 0) + (maintenanceIntervalHours ?? 500) - (totalWorkHours ?? 0)
    }
    var maintenanceProgress: Double {
        let interval = max(maintenanceIntervalHours ?? 500, 1)
        return min(max(((totalWorkHours ?? 0) - (lastMaintenanceAtHours ?? 0)) / interval, 0), 1)
    }
}

enum SmartPlugProvider: String, Codable, CaseIterable, Identifiable {
    case none = "Nessuna"
    case merossHomeAssistant = "Meross via Home Assistant"
    case shellyLocal = "Shelly diretta (IP locale)"
    var id: String { rawValue }
}

enum PrinterConnectionType: String, Codable, CaseIterable, Identifiable {
    case none = "Non collegata"
    case moonraker = "Klipper / Moonraker"
    case octoPrint = "OctoPrint"
    var id: String { rawValue }
}

struct ProductTemplate: Identifiable, Codable, Hashable {
    var id = UUID()
    var name: String
    var sku: String
    var material: Material
    var color: String
    var weightGrams: Double
    var printHours: Double
    var defaultQuantity: Int
    var finishingCost: Double
    var notes: String
    var listingTitle: String? = nil
    var listingDescription: String? = nil
    var linkedFileAssetID: UUID? = nil
    var infillPercent: Double? = 20
    var salePrice: Double? = nil
    var filamentID: UUID? = nil
}

enum ExpenseCategory: String, Codable, CaseIterable, Identifiable {
    case spareParts = "Ricambi"
    case supplies = "Forniture"
    case maintenance = "Manutenzione"
    case energy = "Energia"
    case packaging = "Imballaggi e spedizioni"
    case software = "Software e servizi"
    case printerReplacement = "Sostituzione stampanti"
    case other = "Altro"
    var id: String { rawValue }
    var symbol: String {
        switch self {
        case .spareParts: "wrench.and.screwdriver"
        case .supplies: "shippingbox"
        case .maintenance: "gearshape.2"
        case .energy: "bolt"
        case .packaging: "box.truck"
        case .software: "desktopcomputer"
        case .printerReplacement: "printer.fill"
        case .other: "ellipsis.circle"
        }
    }
}

struct BusinessExpense: Identifiable, Codable, Hashable {
    var id = UUID()
    var date: Date
    var title: String
    var category: ExpenseCategory
    var amount: Double
    var supplier: String
    var notes: String
}

enum BankTransactionKind: String, Codable, CaseIterable, Identifiable {
    case income = "Entrata", expense = "Uscita", transfer = "Trasferimento"
    var id: String { rawValue }
}

struct BankTransaction: Identifiable, Codable, Hashable {
    var id = UUID()
    var sourceID: String
    var bookingDate: Date
    var description: String
    var amount: Double
    var currency: String = "EUR"
    var kind: BankTransactionKind
    var source: String
}

struct FilamentSpool: Identifiable, Codable, Hashable {
    var id = UUID()
    var name: String
    var material: Material
    var brand: String
    var color: String
    var initialGrams: Double
    var remainingGrams: Double
    var purchasePrice: Double
    var minimumStockGrams: Double?
    var colorHex: String? = nil
    var sku: String? = nil

    var pricePerGram: Double { initialGrams > 0 ? purchasePrice / initialGrams : 0 }
}

struct AppSettings: Codable, Hashable {
    var electricityPricePerKWh: Double = 0.30
    var companyName: String = "Layer Logistic"
    var vatPercent: Double = 22
    var includeVAT: Bool? = true
    var appearance: String? = "light"
    var companyLogoPNG: Data?
    var expenseBudgets: [String: Double]?
    var revenueAllocationPercentages: [String: Double]?
    var telegramBotEnabled: Bool?
    var telegramAllowedChatID: String?
    var profitMarginPercent: Double?
    var revenueAllocationCategories: [String]?
    var connectedMailAccount: String?
    var etsyAPIKey: String?
    var etsyShopID: String?
    var etsyTaxonomyID: String?
    var etsyShippingProfileID: String?
    var etsyReturnPolicyID: String?
}

struct QuoteBreakdown {
    var material: Double
    var energy: Double
    var wear: Double
    var setup: Double
    var finishing: Double
    var extras: Double = 0
    var packaging: Double = 0
    var shipping: Double = 0
    var vatPercent: Double
    var profitPercent: Double = 30
    var directCosts: Double { material + energy + wear + setup + finishing + extras + packaging + shipping }
    var profit: Double { directCosts * max(profitPercent, 0) / 100 }
    var subtotal: Double { directCosts + profit }
    var vat: Double { subtotal * vatPercent / 100 }
    var total: Double { subtotal + vat }
}

enum QuoteCalculator {
    static let machineHourlyRate = 4.50

    static func total(material: Material, weightGrams: Double, printHours: Double,
                      quantity: Int, setupCost: Double, finishingCost: Double) -> Double {
        let unitCost = weightGrams * material.pricePerGram + printHours * machineHourlyRate
        return ((unitCost * Double(max(quantity, 1))) + setupCost + finishingCost).rounded(toPlaces: 2)
    }
}

private extension Double {
    func rounded(toPlaces places: Int) -> Double {
        let divisor = pow(10, Double(places))
        return (self * divisor).rounded() / divisor
    }
}

struct StoreData: Codable {
    var customers: [Customer]
    var orders: [PrintOrder]
    var printers: [PrinterProfile]?
    var filaments: [FilamentSpool]?
    var settings: AppSettings?
    var extraMaterials: [ExtraMaterial]?
    var products: [ProductTemplate]?
    var expenses: [BusinessExpense]?
    var suppliers: [Supplier]?
    var purchases: [PurchaseOrder]?
    var supportTickets: [SupportTicket]?
    var returnIssues: [ReturnIssue]?
    var fileAssets: [ProductionFileAsset]?
    var bankTransactions: [BankTransaction]?
}

struct Supplier: Identifiable, Codable, Hashable {
    var id = UUID(); var name: String; var contactName: String; var email: String; var phone: String; var website: String; var notes: String
}

enum PurchaseStatus: String, Codable, CaseIterable, Identifiable { case draft = "Bozza", ordered = "Ordinato", received = "Ricevuto"; var id: String { rawValue } }
struct PurchaseOrder: Identifiable, Codable, Hashable {
    var id = UUID(); var code: String; var supplierID: UUID?; var title: String; var amount: Double; var orderDate: Date; var expectedDate: Date; var status: PurchaseStatus; var notes: String
}

enum TicketStatus: String, Codable, CaseIterable, Identifiable { case open = "Da rispondere", waiting = "In attesa cliente", resolved = "Risolto"; var id: String { rawValue } }
struct SupportTicket: Identifiable, Codable, Hashable {
    var id = UUID(); var customerID: UUID? = nil; var orderID: UUID? = nil; var subject: String; var channel: String; var summary: String; var suggestedReply: String; var receivedAt: Date; var reminderAt: Date? = nil; var status: TicketStatus
}

enum IssueStatus: String, Codable, CaseIterable, Identifiable { case reported = "Segnalato", investigating = "In verifica", remake = "Rifacimento", refunded = "Rimborsato", closed = "Chiuso"; var id: String { rawValue } }
struct ReturnIssue: Identifiable, Codable, Hashable {
    var id = UUID(); var orderID: UUID? = nil; var title: String; var reason: String; var cost: Double; var createdAt: Date; var status: IssueStatus; var notes: String
}

enum ProductionFileKind: String, Codable, CaseIterable, Identifiable { case stl = "STL", threeMF = "3MF", gcode = "G-code", photo = "Foto", other = "Altro"; var id: String { rawValue } }
struct ProductionFileAsset: Identifiable, Codable, Hashable {
    var id = UUID(); var name: String; var kind: ProductionFileKind; var localPath: String; var sizeBytes: Int64; var createdAt: Date; var licenseName: String; var commercialUseAllowed: Bool; var sourceURL: String; var notes: String
    var volumeCM3: Double? = nil
    var dimensionsMM: String? = nil
    var triangleCount: Int? = nil
    var previewPNG: Data? = nil
}
