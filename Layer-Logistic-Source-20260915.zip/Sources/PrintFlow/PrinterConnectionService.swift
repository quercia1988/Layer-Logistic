import Foundation

struct LivePrinterData: Sendable {
    var state: String
    var fileName: String?
    var progress: Double
    var nozzleTemperature: Double?
    var nozzleTarget: Double?
    var bedTemperature: Double?
    var bedTarget: Double?
    var elapsedSeconds: Double?
    var remainingSeconds: Double?
    var updatedAt = Date()
}

struct SmartPlugData: Sendable {
    var powerWatts: Double
    var energyKWh: Double?
    var updatedAt = Date()
}

@MainActor
final class PrinterConnectionService: ObservableObject {
    @Published private(set) var data: [UUID: LivePrinterData] = [:]
    @Published private(set) var errors: [UUID: String] = [:]
    @Published private(set) var loading: Set<UUID> = []
    @Published private(set) var smartPlugData: [UUID: SmartPlugData] = [:]
    @Published private(set) var smartPlugErrors: [UUID: String] = [:]
    @Published private(set) var smartPlugLoading: Set<UUID> = []

    func refresh(_ printer: PrinterProfile) {
        guard !loading.contains(printer.id) else { return }
        loading.insert(printer.id); errors[printer.id] = nil
        Task {
            do { data[printer.id] = try await fetch(printer); errors[printer.id] = nil }
            catch { errors[printer.id] = error.localizedDescription }
            loading.remove(printer.id)
        }
    }

    func refreshSmartPlug(_ printer: PrinterProfile) {
        guard !smartPlugLoading.contains(printer.id) else { return }
        smartPlugLoading.insert(printer.id); smartPlugErrors[printer.id] = nil
        Task {
            do { smartPlugData[printer.id] = try await fetchSmartPlug(printer); smartPlugErrors[printer.id] = nil }
            catch { smartPlugErrors[printer.id] = error.localizedDescription }
            smartPlugLoading.remove(printer.id)
        }
    }

    private func fetchSmartPlug(_ printer: PrinterProfile) async throws -> SmartPlugData {
        guard let provider = printer.smartPlugProvider, provider != .none,
              let rawURL = printer.smartPlugURL?.trimmingCharacters(in: .whitespacesAndNewlines), !rawURL.isEmpty else { throw ConnectionError.missingSmartPlugConfiguration }
        switch provider {
        case .merossHomeAssistant:
            guard let token = printer.smartPlugToken, !token.isEmpty,
                  let powerEntity = printer.smartPlugPowerEntityID, !powerEntity.isEmpty else { throw ConnectionError.missingSmartPlugConfiguration }
            let power = try await fetchHomeAssistantState(base: rawURL, entityID: powerEntity, token: token)
            let energy: Double?
            if let entity = printer.smartPlugEnergyEntityID, !entity.isEmpty { energy = try? await fetchHomeAssistantState(base: rawURL, entityID: entity, token: token) }
            else { energy = nil }
            return SmartPlugData(powerWatts: power, energyKWh: energy)
        case .shellyLocal:
            return try await fetchShelly(base: rawURL)
        case .none:
            throw ConnectionError.missingSmartPlugConfiguration
        }
    }

    private func fetchShelly(base rawBase: String) async throws -> SmartPlugData {
        var base = rawBase
        if !base.contains("://") { base = "http://" + base }
        while base.hasSuffix("/") { base.removeLast() }
        guard let url = URL(string: "\(base)/rpc/Shelly.GetStatus") else { throw ConnectionError.invalidURL }
        let (payload, response) = try await URLSession.shared.data(from: url)
        try validate(response)
        let status = try JSONDecoder().decode(ShellyStatus.self, from: payload)
        guard let meter = status.switch0 ?? status.pm10, let power = meter.apower else { throw ConnectionError.invalidPowerValue }
        return SmartPlugData(powerWatts: power, energyKWh: meter.aenergy.map { $0.total / 1000 })
    }

    private func fetchHomeAssistantState(base rawBase: String, entityID: String, token: String) async throws -> Double {
        var base = rawBase
        if !base.contains("://") { base = "http://" + base }
        while base.hasSuffix("/") { base.removeLast() }
        guard let encoded = entityID.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed),
              let url = URL(string: "\(base)/api/states/\(encoded)") else { throw ConnectionError.invalidURL }
        var request = URLRequest(url: url)
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        let (payload, response) = try await URLSession.shared.data(for: request)
        try validate(response)
        let state = try JSONDecoder().decode(HomeAssistantState.self, from: payload)
        guard let value = Double(state.state.replacingOccurrences(of: ",", with: ".")) else { throw ConnectionError.invalidPowerValue }
        return value
    }

    private func fetch(_ printer: PrinterProfile) async throws -> LivePrinterData {
        guard let type = printer.connectionType, type != .none,
              let rawURL = printer.connectionURL?.trimmingCharacters(in: .whitespacesAndNewlines), !rawURL.isEmpty else {
            throw ConnectionError.missingConfiguration
        }
        var base = rawURL
        if !base.contains("://") { base = "http://" + base }
        while base.hasSuffix("/") { base.removeLast() }
        switch type {
        case .moonraker: return try await fetchMoonraker(base: base)
        case .octoPrint: return try await fetchOctoPrint(base: base, apiKey: printer.connectionAPIKey)
        case .none: throw ConnectionError.missingConfiguration
        }
    }

    private func fetchMoonraker(base: String) async throws -> LivePrinterData {
        guard let url = URL(string: base + "/printer/objects/query?print_stats&extruder&heater_bed&display_status") else { throw ConnectionError.invalidURL }
        let (payload, response) = try await URLSession.shared.data(from: url)
        try validate(response)
        let root = try JSONDecoder().decode(MoonrakerResponse.self, from: payload).result.status
        return LivePrinterData(state: root.printStats?.state.capitalized ?? "Online", fileName: root.printStats?.filename,
                               progress: (root.displayStatus?.progress ?? 0) * 100,
                               nozzleTemperature: root.extruder?.temperature, nozzleTarget: root.extruder?.target,
                               bedTemperature: root.heaterBed?.temperature, bedTarget: root.heaterBed?.target,
                               elapsedSeconds: root.printStats?.printDuration, remainingSeconds: nil)
    }

    private func fetchOctoPrint(base: String, apiKey: String?) async throws -> LivePrinterData {
        guard let url = URL(string: base + "/api/job") else { throw ConnectionError.invalidURL }
        var request = URLRequest(url: url)
        if let apiKey, !apiKey.isEmpty { request.setValue(apiKey, forHTTPHeaderField: "X-Api-Key") }
        let (payload, response) = try await URLSession.shared.data(for: request)
        try validate(response)
        let root = try JSONDecoder().decode(OctoPrintJob.self, from: payload)
        return LivePrinterData(state: root.state, fileName: root.job?.file?.name,
                               progress: root.progress?.completion ?? 0,
                               nozzleTemperature: nil, nozzleTarget: nil, bedTemperature: nil, bedTarget: nil,
                               elapsedSeconds: root.progress?.printTime, remainingSeconds: root.progress?.printTimeLeft)
    }

    private func validate(_ response: URLResponse) throws {
        guard let http = response as? HTTPURLResponse, 200..<300 ~= http.statusCode else { throw ConnectionError.server }
    }
}

private enum ConnectionError: LocalizedError {
    case missingConfiguration, missingSmartPlugConfiguration, invalidURL, server, invalidPowerValue
    var errorDescription: String? {
        switch self {
        case .missingConfiguration: "Configura protocollo e indirizzo della stampante."
        case .missingSmartPlugConfiguration: "Completa indirizzo, token ed Entity ID della presa smart."
        case .invalidURL: "Indirizzo della stampante non valido."
        case .server: "La stampante non ha risposto correttamente. Verifica indirizzo e API key."
        case .invalidPowerValue: "Il sensore collegato non restituisce un valore numerico."
        }
    }
}

private struct HomeAssistantState: Decodable { let state: String }
private struct ShellyStatus: Decodable {
    struct Meter: Decodable { struct Energy: Decodable { let total: Double }; let apower: Double?; let aenergy: Energy? }
    let switch0: Meter?
    let pm10: Meter?
    enum CodingKeys: String, CodingKey { case switch0 = "switch:0"; case pm10 = "pm1:0" }
}

private struct MoonrakerResponse: Decodable {
    struct Result: Decodable { let status: Status }
    struct Status: Decodable {
        let printStats: PrintStats?; let extruder: Heater?; let heaterBed: Heater?; let displayStatus: DisplayStatus?
        enum CodingKeys: String, CodingKey { case printStats = "print_stats", extruder, heaterBed = "heater_bed", displayStatus = "display_status" }
    }
    struct PrintStats: Decodable { let state: String; let filename: String?; let printDuration: Double?; enum CodingKeys: String, CodingKey { case state, filename, printDuration = "print_duration" } }
    struct Heater: Decodable { let temperature: Double?; let target: Double? }
    struct DisplayStatus: Decodable { let progress: Double? }
    let result: Result
}

private struct OctoPrintJob: Decodable {
    struct Job: Decodable { struct File: Decodable { let name: String? }; let file: File? }
    struct Progress: Decodable { let completion: Double?; let printTime: Double?; let printTimeLeft: Double? }
    let state: String; let job: Job?; let progress: Progress?
}
