import SwiftUI
import UniformTypeIdentifiers

struct InventoryView: View {
    @EnvironmentObject private var store: OrderStore
    @State private var editing: FilamentSpool?
    @State private var showNew = false
    @State private var section = 0

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                VStack(alignment: .leading) {
                    Text("Magazzino filamenti").font(.largeTitle.bold())
                    Text("Il costo al grammo alimenta automaticamente i preventivi.").foregroundStyle(.secondary)
                }
                Spacer()
                Picker("Categoria", selection: $section) { Text("Filamenti").tag(0); Text("Altri materiali").tag(1) }.pickerStyle(.segmented).frame(width: 240)
                if section == 0 { Button("Nuova bobina", systemImage: "plus") { showNew = true }.buttonStyle(.borderedProminent).tint(.purple) }
            }.padding(24)
            if section == 0 { Table(store.filaments) {
                TableColumn("Bobina") { item in VStack(alignment: .leading) { Text(item.name).fontWeight(.semibold); Text(item.brand).font(.caption).foregroundStyle(.secondary); if let sku = item.sku, !sku.isEmpty { Text("SKU \(sku)").font(.caption2.monospaced()).foregroundStyle(.secondary) } } }
                TableColumn("Materiale") { Text($0.material.rawValue) }.width(80)
                TableColumn("Colore") { item in
                    HStack(spacing: 8) {
                        FilamentColorDot(hex: item.colorHex, name: item.color)
                        VStack(alignment: .leading, spacing: 1) {
                            Text(item.color.isEmpty ? "Senza nome" : item.color)
                            if let hex = item.colorHex, !hex.isEmpty { Text(hex).font(.caption2.monospaced()).foregroundStyle(.secondary) }
                        }
                    }
                }
                TableColumn("Disponibile") { item in
                    VStack(alignment: .leading) {
                        Text("\(item.remainingGrams.formatted(.number.precision(.fractionLength(0)))) g")
                        ProgressView(value: item.initialGrams > 0 ? item.remainingGrams / item.initialGrams : 0).tint(item.remainingGrams < 200 ? .red : .purple)
                    }
                }
                TableColumn("Costo/kg") { Text((($0.purchasePrice / max($0.initialGrams, 1)) * 1000).euro) }
                TableColumn("") { item in Button("Modifica") { editing = item }.buttonStyle(.borderless) }.width(75)
            } } else { ExtraMaterialsView() }
        }
        .sheet(isPresented: $showNew) { FilamentEditor(item: nil) }
        .sheet(item: $editing) { FilamentEditor(item: $0) }
    }
}

struct ExtraMaterialsView: View {
    @EnvironmentObject private var store: OrderStore
    @State private var editing: ExtraMaterial?
    @State private var showNew = false
    var body: some View {
        VStack(spacing: 0) {
            HStack { Spacer(); Button("Nuovo materiale", systemImage: "plus") { showNew = true }.padding(.horizontal, 24) }
            Table(store.extraMaterials) {
                TableColumn("Materiale") { Text($0.name).fontWeight(.semibold) }
                TableColumn("Unità") { Text($0.unit) }.width(80)
                TableColumn("Disponibilità") { Text($0.stockQuantity.formatted()) }
                TableColumn("Costo unitario") { Text($0.unitCost.euro) }
                TableColumn("") { item in Button("Modifica") { editing = item }.buttonStyle(.borderless) }.width(75)
            }
        }.sheet(isPresented: $showNew) { ExtraMaterialEditor(item: nil) }.sheet(item: $editing) { ExtraMaterialEditor(item: $0) }
    }
}

struct ExtraMaterialEditor: View {
    @EnvironmentObject private var store: OrderStore
    @Environment(\.dismiss) private var dismiss
    @State private var draft: ExtraMaterial
    init(item: ExtraMaterial?) { _draft = State(initialValue: item ?? ExtraMaterial(name: "", unit: "pz", stockQuantity: 0, unitCost: 0)) }
    var body: some View {
        VStack {
            Text("Materiale di consumo").font(.title2.bold()).frame(maxWidth: .infinity, alignment: .leading)
            Form {
                TextField("Nome", text: $draft.name)
                TextField("Unità (pz, g, ml…)", text: $draft.unit)
                TextField("Quantità disponibile", value: $draft.stockQuantity, format: .number)
                TextField("Costo per unità (€)", value: $draft.unitCost, format: .number)
                TextField("Avvisa sotto", value: $draft.minimumStock, format: .number)
            }
            HStack { Button("Elimina", role: .destructive) { store.extraMaterials.removeAll { $0.id == draft.id }; dismiss() }; Spacer(); Button("Annulla") { dismiss() }; Button("Salva") { save() }.buttonStyle(.borderedProminent).tint(.purple) }
        }.padding(24).frame(width: 460, height: 340)
    }
    private func save() {
        if let i = store.extraMaterials.firstIndex(where: { $0.id == draft.id }) { store.extraMaterials[i] = draft } else { store.extraMaterials.append(draft) }
        dismiss()
    }
}

struct FilamentEditor: View {
    @EnvironmentObject private var store: OrderStore
    @Environment(\.dismiss) private var dismiss
    @State private var draft: FilamentSpool
    private let isNew: Bool

    init(item: FilamentSpool?) {
        isNew = item == nil
        _draft = State(initialValue: item ?? FilamentSpool(name: "", material: .pla, brand: "", color: "", initialGrams: 1000, remainingGrams: 1000, purchasePrice: 20, colorHex: "#6B7280"))
    }

    var body: some View {
        VStack {
            Text(isNew ? "Nuova bobina" : "Modifica bobina").font(.title2.bold()).frame(maxWidth: .infinity, alignment: .leading)
            Form {
                TextField("Nome", text: $draft.name)
                TextField("Marca", text: $draft.brand)
                TextField("Codice SKU", text: filamentSKU).font(.system(.body, design: .monospaced))
                Picker("Materiale", selection: $draft.material) { ForEach(Material.allCases) { Text($0.rawValue).tag($0) } }
                LabeledContent("Colore") {
                    HStack(spacing: 10) {
                        ColorPicker("Scegli", selection: filamentColor, supportsOpacity: false).labelsHidden()
                        TextField("Nome colore", text: $draft.color).frame(width: 190)
                    }
                }
                LabeledContent("Codice HEX") {
                    HStack(spacing: 8) {
                        TextField("EF3340", text: filamentHex).font(.system(.body, design: .monospaced)).frame(width: 110)
                        FilamentColorDot(hex: draft.colorHex, name: draft.color)
                        Text("es. EF3340").font(.caption).foregroundStyle(.secondary)
                    }
                }
                TextField("Peso iniziale (g)", value: $draft.initialGrams, format: .number)
                TextField("Peso residuo (g)", value: $draft.remainingGrams, format: .number)
                TextField("Prezzo acquisto (€)", value: $draft.purchasePrice, format: .number)
                TextField("Avvisa sotto (g)", value: $draft.minimumStockGrams, format: .number)
                LabeledContent("Costo calcolato") { Text("\((draft.pricePerGram * 1000).euro)/kg").fontWeight(.semibold) }
            }
            HStack { if !isNew { Button("Elimina", role: .destructive) { store.filaments.removeAll { $0.id == draft.id }; dismiss() } }; Spacer(); Button("Annulla") { dismiss() }; Button("Salva") { save() }.buttonStyle(.borderedProminent).tint(.purple).disabled(draft.name.isEmpty) }
        }.padding(24).frame(width: 480, height: 480)
    }

    private func save() {
        if let index = store.filaments.firstIndex(where: { $0.id == draft.id }) { store.filaments[index] = draft }
        else { store.filaments.append(draft) }
        dismiss()
    }

    private var filamentColor: Binding<Color> {
        Binding(
            get: { Color(hex: draft.colorHex) ?? Color.filamentFallback(named: draft.color) },
            set: { draft.colorHex = NSColor($0).hexString }
        )
    }

    private var filamentHex: Binding<String> {
        Binding(
            get: { (draft.colorHex ?? "").replacingOccurrences(of: "#", with: "") },
            set: { value in
                let clean = value.uppercased().filter { $0.isHexDigit }.prefix(6)
                draft.colorHex = clean.isEmpty ? nil : "#\(clean)"
            }
        )
    }

    private var filamentSKU: Binding<String> {
        Binding(
            get: { draft.sku ?? "" },
            set: { value in
                let clean = value.uppercased().trimmingCharacters(in: .whitespacesAndNewlines)
                draft.sku = clean.isEmpty ? nil : clean
            }
        )
    }
}

private struct FilamentColorDot: View {
    let hex: String?
    let name: String
    var body: some View {
        Circle()
            .fill(Color(hex: hex) ?? Color.filamentFallback(named: name))
            .frame(width: 18, height: 18)
            .overlay(Circle().stroke(.primary.opacity(0.18), lineWidth: 1))
            .accessibilityLabel("Colore \(name.isEmpty ? "non specificato" : name)")
    }
}

private extension Color {
    init?(hex: String?) {
        guard var value = hex?.trimmingCharacters(in: .whitespacesAndNewlines), !value.isEmpty else { return nil }
        if value.hasPrefix("#") { value.removeFirst() }
        guard value.count == 6, let rgb = Int(value, radix: 16) else { return nil }
        self.init(red: Double((rgb >> 16) & 0xFF) / 255, green: Double((rgb >> 8) & 0xFF) / 255, blue: Double(rgb & 0xFF) / 255)
    }

    static func filamentFallback(named name: String) -> Color {
        let value = name.lowercased()
        if value.contains("nero") { return .black }
        if value.contains("bianco") { return .white }
        if value.contains("rosso") { return .red }
        if value.contains("verde") { return .green }
        if value.contains("blu") { return .blue }
        if value.contains("giall") { return .yellow }
        if value.contains("aranc") { return .orange }
        if value.contains("viola") { return .purple }
        if value.contains("rosa") { return .pink }
        if value.contains("grigi") { return .gray }
        return .secondary
    }
}

private extension NSColor {
    var hexString: String? {
        guard let rgb = usingColorSpace(.sRGB) else { return nil }
        return String(format: "#%02X%02X%02X", Int(rgb.redComponent * 255), Int(rgb.greenComponent * 255), Int(rgb.blueComponent * 255))
    }
}

struct PrintersView: View {
    @EnvironmentObject private var store: OrderStore
    @EnvironmentObject private var connection: PrinterConnectionService
    @State private var editing: PrinterProfile?
    @State private var showNew = false
    @State private var section = 0
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                VStack(alignment: .leading) { Text("Stampanti").font(.largeTitle.bold()); Text("Potenza e usura sono modificabili per riflettere i consumi reali.").foregroundStyle(.secondary) }
                Spacer(); Picker("Vista", selection: $section) { Text("Parco macchine").tag(0); Text("Manutenzione").tag(1) }.pickerStyle(.segmented).frame(width: 270); Button("Aggiungi stampante", systemImage: "plus") { showNew = true }.buttonStyle(.borderedProminent).tint(.purple)
            }.padding(24)
            if section == 0 { Table(store.printers) {
                TableColumn("Stampante") { printer in HStack { PrinterThumbnail(printer: printer, size: 44); VStack(alignment: .leading) { Text(printer.model).fontWeight(.semibold); Text(printer.manufacturer).font(.caption).foregroundStyle(.secondary) } } }
                TableColumn("Modello") { Text($0.model).fontWeight(.semibold) }
                TableColumn("Stato live") { printer in
                    if let live = connection.data[printer.id] {
                        VStack(alignment: .leading, spacing: 2) {
                            HStack(spacing: 5) { Circle().fill(.green).frame(width: 7, height: 7); Text(live.state).fontWeight(.medium) }
                            if let file = live.fileName, !file.isEmpty { Text("\(live.progress.formatted(.number.precision(.fractionLength(0))))% · \(file)").font(.caption).foregroundStyle(.secondary).lineLimit(1) }
                        }
                    } else if connection.loading.contains(printer.id) { ProgressView().controlSize(.small) }
                    else { Text((printer.connectionType ?? PrinterConnectionType.none) == PrinterConnectionType.none ? "Non collegata" : "Da aggiornare").foregroundStyle(.secondary) }
                }.width(min: 130, ideal: 180)
                TableColumn("Consumo") { printer in
                    if let plug = connection.smartPlugData[printer.id] {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("\(plug.powerWatts.formatted(.number.precision(.fractionLength(1)))) W").fontWeight(.semibold).foregroundStyle(.green)
                            Text(printer.smartPlugProvider == .shellyLocal ? "Shelly · live" : "Meross · live").font(.caption2).foregroundStyle(.secondary)
                        }
                    } else {
                        Text("\(printer.consumptionWatts.formatted(.number.precision(.fractionLength(0)))) W")
                    }
                }
                TableColumn("Usura/ora") { Text($0.wearCostPerHour.euro) }
                TableColumn("Ore totali") { Text("\(($0.totalWorkHours ?? 0).formatted()) h") }
                TableColumn("") { item in HStack { if (item.connectionType ?? PrinterConnectionType.none) != PrinterConnectionType.none { Button { connection.refresh(item) } label: { Image(systemName: "arrow.clockwise") }.buttonStyle(.borderless).help("Aggiorna dati di stampa") }; if (item.smartPlugProvider ?? SmartPlugProvider.none) != .none { Button { connection.refreshSmartPlug(item) } label: { Image(systemName: "bolt.fill") }.buttonStyle(.borderless).help("Aggiorna consumo Meross") }; Button("Modifica") { editing = item }.buttonStyle(.borderless) } }.width(125)
            } } else { MaintenanceOverview(editing: $editing) }
        }.sheet(isPresented: $showNew) { PrinterEditor(item: nil) }.sheet(item: $editing) { PrinterEditor(item: $0) }
    }
}

struct PrinterThumbnail: View {
    let printer: PrinterProfile
    var size: CGFloat = 64
    var body: some View {
        Group {
            if let image = resolvedImage { Image(nsImage: image).resizable().scaledToFit().padding(4) }
            else { Image(systemName: "printer.fill").resizable().scaledToFit().padding(size * 0.24).foregroundStyle(.purple) }
        }
            .frame(width: size, height: size).background(Color(nsColor: .controlBackgroundColor)).clipShape(RoundedRectangle(cornerRadius: size * 0.2)).overlay(RoundedRectangle(cornerRadius: size * 0.2).stroke(.secondary.opacity(0.13)))
    }

    private var resolvedImage: NSImage? {
        if let data = printer.imagePNG, let image = NSImage(data: data) { return image }
        let key: String?
        switch (printer.manufacturer.lowercased(), printer.model.lowercased()) {
        case let (maker, model) where maker.contains("bambu") && model == "a1": key = "bambu-a1.jpg"
        case let (maker, model) where maker.contains("bambu") && model.contains("p1s"): key = "bambu-p1s.jpg"
        case let (maker, model) where maker.contains("bambu") && model.contains("x1"): key = "bambu-x1.jpg"
        case let (maker, model) where maker.contains("prusa") && model.contains("mk4"): key = "prusa-mk4s.jpg"
        case let (maker, model) where maker.contains("prusa") && model.contains("core"): key = "prusa-core-one.jpg"
        case let (maker, model) where maker.contains("anycubic") && model.contains("kobra x"): key = "anycubic-kobra-x.jpg"
        default: key = nil
        }
        guard let key, let url = Bundle.main.resourceURL?.appendingPathComponent("Printers").appendingPathComponent(key) else { return nil }
        return NSImage(contentsOf: url)
    }
}

struct MaintenanceOverview: View {
    @EnvironmentObject private var store: OrderStore
    @Binding var editing: PrinterProfile?
    var body: some View {
        ScrollView {
            LazyVGrid(columns: [GridItem(.adaptive(minimum: 310), spacing: 14)], spacing: 14) {
                ForEach(store.printers) { printer in
                    VStack(alignment: .leading, spacing: 14) {
                        HStack { PrinterThumbnail(printer: printer, size: 62); VStack(alignment: .leading) { Text(printer.displayName).font(.headline); Text("\((printer.totalWorkHours ?? 0).formatted()) ore totali").foregroundStyle(.secondary) }; Spacer(); Circle().fill(printer.hoursUntilMaintenance <= 0 ? .red : printer.hoursUntilMaintenance < 50 ? .orange : .green).frame(width: 11, height: 11) }
                        ProgressView(value: printer.maintenanceProgress).tint(printer.hoursUntilMaintenance <= 0 ? .red : .purple)
                        HStack { Label(printer.hoursUntilMaintenance <= 0 ? "Manutenzione scaduta" : "Tra \(printer.hoursUntilMaintenance.formatted()) ore", systemImage: "wrench.and.screwdriver").font(.callout).foregroundStyle(printer.hoursUntilMaintenance <= 0 ? .red : .secondary); Spacer(); Button("Dettagli") { editing = printer } }
                        if let notes = printer.maintenanceNotes, !notes.isEmpty { Text(notes).font(.caption).foregroundStyle(.secondary).lineLimit(2) }
                    }.padding(18).background(Color(nsColor: .textBackgroundColor)).clipShape(RoundedRectangle(cornerRadius: 15)).overlay(RoundedRectangle(cornerRadius: 15).stroke(.secondary.opacity(0.15)))
                }
            }.padding(24)
        }
    }
}

struct PrinterEditor: View {
    @EnvironmentObject private var store: OrderStore
    @EnvironmentObject private var connection: PrinterConnectionService
    @Environment(\.dismiss) private var dismiss
    @State private var draft: PrinterProfile
    @State private var importImage = false
    @State private var importConnectionQR = false
    @State private var qrMessage: String?
    init(item: PrinterProfile?) { _draft = State(initialValue: item ?? PrinterProfile(manufacturer: "", model: "", consumptionWatts: 300, wearCostPerHour: 0.50, isCustom: true)) }
    var body: some View {
        VStack {
            Text("Dati stampante").font(.title2.bold()).frame(maxWidth: .infinity, alignment: .leading)
            Form {
                HStack { PrinterThumbnail(printer: draft, size: 86); VStack(alignment: .leading) { Button(draft.imagePNG == nil ? "Carica miniatura" : "Sostituisci miniatura", systemImage: "photo") { importImage = true }; if draft.imagePNG != nil { Button("Rimuovi immagine", role: .destructive) { draft.imagePNG = nil } } } }
                TextField("Produttore", text: $draft.manufacturer)
                TextField("Modello", text: $draft.model)
                TextField("Consumo medio (W)", value: $draft.consumptionWatts, format: .number)
                TextField("Costo usura orario (€)", value: $draft.wearCostPerHour, format: .number)
                Section("Collegamento dati di stampa") {
                    Picker("Protocollo", selection: Binding(get: { draft.connectionType ?? PrinterConnectionType.none }, set: { draft.connectionType = $0 })) {
                        ForEach(PrinterConnectionType.allCases) { Text($0.rawValue).tag($0) }
                    }
                    Button("Collega tramite QR code", systemImage: "qrcode.viewfinder") { importConnectionQR = true }
                    if (draft.connectionType ?? PrinterConnectionType.none) != PrinterConnectionType.none {
                        TextField("Indirizzo (es. http://192.168.1.50)", text: Binding(get: { draft.connectionURL ?? "" }, set: { draft.connectionURL = $0 }))
                        if draft.connectionType == .octoPrint {
                            SecureField("API key OctoPrint", text: Binding(get: { draft.connectionAPIKey ?? "" }, set: { draft.connectionAPIKey = $0 }))
                        }
                        HStack {
                            Button("Verifica collegamento", systemImage: "antenna.radiowaves.left.and.right") { connection.refresh(draft) }
                                .disabled(connection.loading.contains(draft.id) || (draft.connectionURL ?? "").isEmpty)
                            if connection.loading.contains(draft.id) { ProgressView().controlSize(.small) }
                            if let live = connection.data[draft.id] { Label("Connessa · \(live.state)", systemImage: "checkmark.circle.fill").foregroundStyle(.green) }
                            if let error = connection.errors[draft.id] { Label(error, systemImage: "exclamationmark.triangle.fill").font(.caption).foregroundStyle(.red) }
                        }
                        if let live = connection.data[draft.id] {
                            VStack(alignment: .leading, spacing: 7) {
                                if let file = live.fileName { LabeledContent("File in stampa", value: file) }
                                LabeledContent("Avanzamento", value: "\(live.progress.formatted(.number.precision(.fractionLength(1))))%")
                                if let nozzle = live.nozzleTemperature { LabeledContent("Ugello", value: "\(nozzle.formatted(.number.precision(.fractionLength(1)))) °C") }
                                if let bed = live.bedTemperature { LabeledContent("Piatto", value: "\(bed.formatted(.number.precision(.fractionLength(1)))) °C") }
                            }.padding(12).background(CleanWorkshopTheme.softPurple).clipShape(RoundedRectangle(cornerRadius: 10))
                        }
                    }
                    if let qrMessage { Text(qrMessage).font(.caption).foregroundStyle(qrMessage.hasPrefix("QR acquisito") ? .green : .orange) }
                }
                Section("Presa smart e consumi") {
                    Picker("Presa", selection: Binding(get: { draft.smartPlugProvider ?? SmartPlugProvider.none }, set: { draft.smartPlugProvider = $0 })) {
                        ForEach(SmartPlugProvider.allCases) { Text($0.rawValue).tag($0) }
                    }
                    if (draft.smartPlugProvider ?? .none) == .merossHomeAssistant {
                        TextField("Home Assistant (es. http://homeassistant.local:8123)", text: Binding(get: { draft.smartPlugURL ?? "" }, set: { draft.smartPlugURL = $0 }))
                        SecureField("Token di accesso Home Assistant", text: Binding(get: { draft.smartPlugToken ?? "" }, set: { draft.smartPlugToken = $0 }))
                        TextField("Entity ID potenza (es. sensor.presa_stampante_power)", text: Binding(get: { draft.smartPlugPowerEntityID ?? "" }, set: { draft.smartPlugPowerEntityID = $0 }))
                        TextField("Entity ID energia, opzionale", text: Binding(get: { draft.smartPlugEnergyEntityID ?? "" }, set: { draft.smartPlugEnergyEntityID = $0 }))
                        HStack {
                            Button("Verifica presa Meross", systemImage: "bolt.horizontal.circle") { connection.refreshSmartPlug(draft) }
                                .disabled(connection.smartPlugLoading.contains(draft.id))
                            if connection.smartPlugLoading.contains(draft.id) { ProgressView().controlSize(.small) }
                            if let reading = connection.smartPlugData[draft.id] {
                                Label("\(reading.powerWatts.formatted(.number.precision(.fractionLength(1)))) W", systemImage: "checkmark.circle.fill").foregroundStyle(.green)
                                if let energy = reading.energyKWh { Text("· \(energy.formatted(.number.precision(.fractionLength(2)))) kWh").foregroundStyle(.secondary) }
                            }
                        }
                        if let error = connection.smartPlugErrors[draft.id] { Label(error, systemImage: "exclamationmark.triangle.fill").font(.caption).foregroundStyle(.red) }
                        Text("La presa Meross deve essere già presente in Home Assistant e avere un sensore di potenza. Il collegamento è in sola lettura: l’app non accende o spegne la stampante.").font(.caption).foregroundStyle(.secondary)
                    } else if draft.smartPlugProvider == .shellyLocal {
                        TextField("Indirizzo IP (es. 192.168.1.80)", text: Binding(get: { draft.smartPlugURL ?? "" }, set: { draft.smartPlugURL = $0 }))
                        HStack {
                            Button("Verifica presa Shelly", systemImage: "bolt.horizontal.circle") { connection.refreshSmartPlug(draft) }
                                .disabled(connection.smartPlugLoading.contains(draft.id) || (draft.smartPlugURL ?? "").isEmpty)
                            if connection.smartPlugLoading.contains(draft.id) { ProgressView().controlSize(.small) }
                            if let reading = connection.smartPlugData[draft.id] {
                                Label("\(reading.powerWatts.formatted(.number.precision(.fractionLength(1)))) W", systemImage: "checkmark.circle.fill").foregroundStyle(.green)
                                if let energy = reading.energyKWh { Text("· \(energy.formatted(.number.precision(.fractionLength(3)))) kWh").foregroundStyle(.secondary) }
                            }
                        }
                        if let error = connection.smartPlugErrors[draft.id] { Label(error, systemImage: "exclamationmark.triangle.fill").font(.caption).foregroundStyle(.red) }
                        Text("Compatibile con Shelly Gen2/Gen3 dotate di misurazione. La lettura avviene direttamente sulla rete locale tramite API ufficiale; non serve il cloud.").font(.caption).foregroundStyle(.secondary)
                    }
                }
                Section("Ore e manutenzione") {
                    TextField("Ore di lavoro totali", value: $draft.totalWorkHours, format: .number)
                    TextField("Intervallo manutenzione (ore)", value: $draft.maintenanceIntervalHours, format: .number)
                    TextField("Note manutenzione", text: Binding(get: { draft.maintenanceNotes ?? "" }, set: { draft.maintenanceNotes = $0 }))
                    LabeledContent("Prossima manutenzione") { Text(draft.hoursUntilMaintenance <= 0 ? "Scaduta" : "tra \(draft.hoursUntilMaintenance.formatted()) h").foregroundStyle(draft.hoursUntilMaintenance <= 0 ? .red : .secondary) }
                    Button("Segna manutenzione eseguita", systemImage: "checkmark.circle") { draft.lastMaintenanceAtHours = draft.totalWorkHours ?? 0 }
                }
                Text("Per la massima precisione inserisci il consumo medio misurato con una presa wattmetro durante una stampa tipica.").font(.caption).foregroundStyle(.secondary)
            }
            HStack { Button("Elimina", role: .destructive) { store.printers.removeAll { $0.id == draft.id }; dismiss() }; Spacer(); Button("Annulla") { dismiss() }; Button("Salva") { save() }.buttonStyle(.borderedProminent).tint(.purple) }
        }.padding(24).frame(width: 620, height: 850)
        .fileImporter(isPresented: $importImage, allowedContentTypes: [.png, .jpeg, .image]) { result in if case let .success(url) = result { let access = url.startAccessingSecurityScopedResource(); defer { if access { url.stopAccessingSecurityScopedResource() } }; draft.imagePNG = try? Data(contentsOf: url) } }
        .fileImporter(isPresented: $importConnectionQR, allowedContentTypes: [.png, .jpeg, .image]) { result in
            do {
                let url = try result.get(); let access = url.startAccessingSecurityScopedResource(); defer { if access { url.stopAccessingSecurityScopedResource() } }
                let configuration = try PrinterQRCode.read(from: url)
                draft.connectionType = configuration.type; draft.connectionURL = configuration.url
                if let key = configuration.apiKey { draft.connectionAPIKey = key }
                qrMessage = "QR acquisito: verifica ora il collegamento."
                connection.refresh(draft)
            } catch { qrMessage = error.localizedDescription }
        }
    }
    private func save() {
        if let i = store.printers.firstIndex(where: { $0.id == draft.id }) { store.printers[i] = draft } else { store.printers.append(draft) }
        dismiss()
    }
}

struct SettingsView: View {
    @EnvironmentObject private var store: OrderStore
    @EnvironmentObject private var telegram: TelegramBotService
    @EnvironmentObject private var listingAssistant: ListingAssistantService
    @EnvironmentObject private var etsy: EtsyService
    @State private var importLogo = false
    @State private var telegramToken = ""
    @State private var openAIKey = ""
    @State private var aiKeyMessage: String?
    @State private var etsyToken = ""
    var body: some View {
        Form {
            Section("Aspetto") {
                Picker("Tema", selection: Binding(get: { store.settings.appearance ?? "system" }, set: { store.settings.appearance = $0 })) {
                    Text("Automatico").tag("system"); Text("Chiaro").tag("light"); Text("Scuro").tag("dark")
                }.pickerStyle(.segmented)
            }
            Section("Azienda") {
                TextField("Ragione sociale", text: $store.settings.companyName)
                HStack {
                    if let data = store.settings.companyLogoPNG, let logo = NSImage(data: data) { Image(nsImage: logo).resizable().scaledToFit().frame(width: 72, height: 72).background(.quaternary.opacity(0.3)).clipShape(RoundedRectangle(cornerRadius: 12)) }
                    Button(store.settings.companyLogoPNG == nil ? "Carica logo" : "Sostituisci logo", systemImage: "photo") { importLogo = true }
                    if store.settings.companyLogoPNG != nil { Button("Rimuovi", role: .destructive) { store.settings.companyLogoPNG = nil } }
                }
            }
            Section("Tariffe") {
                TextField("Prezzo energia (€/kWh)", value: $store.settings.electricityPricePerKWh, format: .number)
                TextField("Margine di guadagno sui costi (%)", value: Binding(
                    get: { store.settings.profitMarginPercent ?? 30 },
                    set: { store.settings.profitMarginPercent = max(0, $0) }
                ), format: .number)
                Toggle("Includi IVA nel preventivo", isOn: Binding(
                    get: { store.settings.includeVAT != false },
                    set: { store.settings.includeVAT = $0 }
                ))
                if store.settings.includeVAT != false {
                    TextField("IVA (%)", value: $store.settings.vatPercent, format: .number)
                }
                Text("Il costo energia per ordine è: kW della stampante × ore di stampa × prezzo €/kWh.").font(.caption).foregroundStyle(.secondary)
                Text("Il guadagno viene aggiunto ai costi diretti prima dell'IVA e aggiornato automaticamente nel preventivo.").font(.caption).foregroundStyle(.secondary)
            }
            Section("Connessioni store") {
                VStack(alignment: .leading, spacing: 9) {
                    HStack { Label("Assistente descrizioni IA", systemImage: "sparkles").font(.headline); Spacer(); Text(listingAssistant.isConfigured ? "Configurato" : "Da configurare").foregroundStyle(listingAssistant.isConfigured ? .green : .orange) }
                    SecureField("Chiave API OpenAI", text: $openAIKey)
                    HStack { Button("Salva nel Portachiavi", systemImage: "key.fill") { do { try listingAssistant.saveAPIKey(openAIKey); openAIKey = ""; aiKeyMessage = "Chiave salvata in modo sicuro." } catch { aiKeyMessage = error.localizedDescription } }; if listingAssistant.isConfigured { Button("Rimuovi", role: .destructive) { listingAssistant.removeAPIKey(); aiKeyMessage = "Chiave rimossa." } }; Button("Credito e fatturazione", systemImage: "creditcard") { NSWorkspace.shared.open(URL(string: "https://platform.openai.com/settings/organization/billing")!) } }
                    Button("Apri fatturazione API OpenAI", systemImage: "creditcard") { NSWorkspace.shared.open(URL(string: "https://platform.openai.com/settings/organization/billing")!) }
                    if let aiKeyMessage { Text(aiKeyMessage).font(.caption).foregroundStyle(.secondary) }
                }
                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        Label("Ordini Telegram", systemImage: "paperplane.fill").font(.headline)
                        Spacer()
                        Label(telegram.isRunning ? "Attivo" : "In pausa", systemImage: telegram.isRunning ? "checkmark.circle.fill" : "pause.circle")
                            .font(.caption).foregroundStyle(telegram.isRunning ? .green : .secondary)
                    }
                    SecureField("Token ricevuto da @BotFather", text: $telegramToken)
                    HStack {
                        Button("Salva e verifica", systemImage: "checkmark.shield") { Task { await telegram.saveAndVerify(token: telegramToken); telegramToken = "" } }
                            .buttonStyle(.borderedProminent).tint(.purple)
                        Button("Apri BotFather", systemImage: "arrow.up.right.square") { NSWorkspace.shared.open(URL(string: "https://t.me/BotFather")!) }
                        if telegram.hasToken { Button("Rimuovi token", role: .destructive) { telegram.removeToken() } }
                    }
                    Toggle("Bot attivo mentre Layer Logistic è aperto", isOn: Binding(
                        get: { store.settings.telegramBotEnabled == true },
                        set: { store.settings.telegramBotEnabled = $0; $0 ? telegram.start() : telegram.stop() }
                    ))
                    TextField("Chat ID autorizzata", text: Binding(get: { store.settings.telegramAllowedChatID ?? "" }, set: { store.settings.telegramAllowedChatID = $0 }))
                    if let detected = telegram.lastChatID { Text("Ultima Chat ID rilevata: \(detected)").font(.caption).textSelection(.enabled) }
                    Text(telegram.status + (telegram.botName.map { " · \($0)" } ?? "")).font(.caption).foregroundStyle(.secondary)
                    Text("/ordine Cliente | Prodotto o SKU | Quantità | gg/mm/aaaa").font(.system(.caption, design: .monospaced)).textSelection(.enabled)
                    Text("Invia /id al bot, copia la Chat ID qui sopra e attivalo. Il token viene conservato nel Portachiavi macOS.").font(.caption).foregroundStyle(.secondary)
                }
                VStack(alignment: .leading, spacing: 8) {
                    HStack { Label("Etsy", systemImage: "storefront").font(.headline); Spacer(); Text(etsy.hasToken ? "Token presente" : "Da configurare").foregroundStyle(etsy.hasToken ? .green : .orange) }
                    TextField("API key Etsy (keystring:shared_secret)", text: Binding(get: { store.settings.etsyAPIKey ?? "" }, set: { store.settings.etsyAPIKey = $0 }))
                    TextField("Shop ID", text: Binding(get: { store.settings.etsyShopID ?? "" }, set: { store.settings.etsyShopID = $0 }))
                    SecureField("Access token OAuth Etsy", text: $etsyToken).onSubmit { saveEtsyToken() }
                    HStack { Button("Salva token", systemImage: "key.fill") { saveEtsyToken() }.buttonStyle(.borderedProminent).disabled(etsyToken.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty); if etsy.hasToken { Button("Rimuovi token", role: .destructive) { etsy.removeToken() } } }
                    DisclosureGroup("Parametri per pubblicare le bozze") {
                        TextField("Taxonomy ID", text: Binding(get: { store.settings.etsyTaxonomyID ?? "" }, set: { store.settings.etsyTaxonomyID = $0 }))
                        TextField("Shipping profile ID", text: Binding(get: { store.settings.etsyShippingProfileID ?? "" }, set: { store.settings.etsyShippingProfileID = $0 }))
                        TextField("Return policy ID", text: Binding(get: { store.settings.etsyReturnPolicyID ?? "" }, set: { store.settings.etsyReturnPolicyID = $0 }))
                    }
                    Button("Apri portale sviluppatori Etsy", systemImage: "arrow.up.right.square") { NSWorkspace.shared.open(URL(string: "https://www.etsy.com/developers/your-apps")!) }
                    Text(etsy.message).font(.caption).foregroundStyle(.secondary)
                    Text("Il token viene conservato nel Portachiavi macOS. Servono i permessi listings_w e transactions_r; non inserire la password Etsy.").font(.caption).foregroundStyle(.secondary)
                }
                VStack(alignment: .leading, spacing: 8) {
                    HStack { Label("Vinted", systemImage: "tag").font(.headline); Spacer(); Text("Account normale").foregroundStyle(.teal) }
                    Button("Apri Vinted", systemImage: "arrow.up.right.square") { NSWorkspace.shared.open(URL(string: "https://www.vinted.it/member/general/login")!) }
                    Text("Gli ordini Vinted normali vengono inseriti tramite ID e link dalla schermata Nuovo ordine. Vinted non offre un accesso API pubblico per sincronizzare automaticamente un account personale.").font(.caption).foregroundStyle(.secondary)
                }
            }
        }.formStyle(.grouped).navigationTitle("Impostazioni preventivo").padding(10)
        .fileImporter(isPresented: $importLogo, allowedContentTypes: [.png, .jpeg, .image]) { result in
            if case let .success(url) = result { let access = url.startAccessingSecurityScopedResource(); defer { if access { url.stopAccessingSecurityScopedResource() } }; store.settings.companyLogoPNG = try? Data(contentsOf: url) }
        }
    }
    private func saveEtsyToken() { do { try etsy.saveToken(etsyToken); etsyToken = "" } catch { etsy.report(error) } }
}
