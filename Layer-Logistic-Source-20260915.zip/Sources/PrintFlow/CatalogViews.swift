import SwiftUI

struct ProductsView: View {
    @EnvironmentObject private var store: OrderStore
    @State private var editing: ProductTemplate?
    @State private var showNew = false
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                VStack(alignment: .leading, spacing: 4) { Text("Prodotti").font(.largeTitle.bold()); Text("Modelli riutilizzabili per creare preventivi in pochi secondi.").foregroundStyle(.secondary) }
                Spacer(); Button("Nuovo prodotto", systemImage: "plus") { showNew = true }.buttonStyle(.borderedProminent)
            }.padding(24)
            Table(store.products) {
                TableColumn("Prodotto") { p in VStack(alignment: .leading) { Text(p.name).fontWeight(.semibold); Text(p.sku).font(.caption).foregroundStyle(.secondary) } }
                TableColumn("File") { p in Text(store.fileAssets.first { $0.id == p.linkedFileAssetID }?.name ?? "—").lineLimit(1) }
                TableColumn("Materiale") { Text($0.material.rawValue) }.width(90)
                TableColumn("Colore") { p in Text(store.filaments.first { $0.id == p.filamentID }?.color ?? p.color) }.width(100)
                TableColumn("Peso") { Text("\($0.weightGrams.formatted()) g") }.width(90)
                TableColumn("Stampa") { Text("\($0.printHours.formatted()) h") }.width(90)
                TableColumn("Prezzo") { Text(($0.salePrice ?? 0).euro) }.width(90)
                TableColumn("") { p in Button("Modifica") { editing = p }.buttonStyle(.borderless) }.width(75)
            }
        }.sheet(isPresented: $showNew) { ProductEditor(product: nil) }.sheet(item: $editing) { ProductEditor(product: $0) }
    }
}

struct ProductEditor: View {
    @EnvironmentObject private var store: OrderStore
    @EnvironmentObject private var listingAssistant: ListingAssistantService
    @EnvironmentObject private var etsy: EtsyService
    @Environment(\.dismiss) private var dismiss
    @State private var draft: ProductTemplate
    @State private var analysisMessage: String?
    private let isNew: Bool
    init(product: ProductTemplate?) {
        isNew = product == nil
        _draft = State(initialValue: product ?? ProductTemplate(name: "", sku: "", material: .pla, color: "", weightGrams: 0, printHours: 0, defaultQuantity: 1, finishingCost: 0, notes: ""))
    }
    var body: some View {
        VStack(spacing: 16) {
            Text(isNew ? "Nuovo prodotto" : "Modifica prodotto").font(.title2.bold()).frame(maxWidth: .infinity, alignment: .leading)
            Form {
                TextField("Nome", text: $draft.name); TextField("SKU", text: $draft.sku)
                Section("File di produzione") {
                    Picker("STL / 3MF archiviato", selection: linkedFileBinding) {
                        Text("Nessun file").tag(UUID?.none)
                        ForEach(store.fileAssets.filter { $0.kind == .stl || $0.kind == .threeMF }) { asset in
                            Text(asset.name).tag(Optional(asset.id))
                        }
                    }
                    if let asset = linkedFile {
                        HStack(spacing: 12) {
                            Group { if let data=asset.previewPNG,let image=NSImage(data:data){Image(nsImage:image).resizable().scaledToFit()}else{Image(systemName:"cube.transparent.fill").font(.title).foregroundStyle(.purple)} }.frame(width:64,height:52).background(.secondary.opacity(0.08)).clipShape(RoundedRectangle(cornerRadius:9))
                            VStack(alignment:.leading,spacing:3){Text(asset.name).fontWeight(.semibold);if let volume=asset.volumeCM3{Text("Volume \(volume.formatted(.number.precision(.fractionLength(2)))) cm³ · \(asset.dimensionsMM ?? "")").font(.caption).foregroundStyle(.secondary)}}
                        }
                        Slider(value: infillBinding, in: 0...100, step: 5) { Text("Riempimento") } minimumValueLabel: { Text("0%") } maximumValueLabel: { Text("100%") }
                        LabeledContent("Riempimento", value: "\((draft.infillPercent ?? 20).formatted())%")
                        LabeledContent("Peso stimato dal modello", value: "\(draft.weightGrams.formatted(.number.precision(.fractionLength(1)))) g")
                        Button("Ricalcola dati dal file", systemImage: "arrow.triangle.2.circlepath") { applyLinkedFile(asset) }
                        if let analysisMessage { Text(analysisMessage).font(.caption).foregroundStyle(.orange) }
                    }
                }
                Section("Filamento dal magazzino") {
                    if store.filaments.isEmpty {
                        Label("Aggiungi prima una bobina in Magazzino → Filamenti.", systemImage: "exclamationmark.triangle.fill").foregroundStyle(.orange)
                        Picker("Materiale provvisorio", selection: $draft.material) { ForEach(Material.allCases) { Text($0.rawValue).tag($0) } }
                    } else {
                        Picker("Bobina e colore", selection: selectedFilamentBinding) {
                            Text("Seleziona una bobina").tag(UUID?.none)
                            ForEach(store.filaments) { spool in
                                Text("\(spool.color) · \(spool.material.rawValue) · \(spool.name) (\(spool.remainingGrams.formatted()) g)").tag(Optional(spool.id))
                            }
                        }
                        if let spool = selectedFilament {
                            LabeledContent("SKU bobina", value: spool.sku ?? "—")
                            LabeledContent("Costo", value: "\((spool.pricePerGram * 1000).euro)/kg")
                        }
                    }
                }
                TextField("Peso stimato per pezzo (g)", value: $draft.weightGrams, format: .number)
                TextField("Ore per pezzo", value: $draft.printHours, format: .number)
                Stepper("Quantità predefinita: \(draft.defaultQuantity)", value: $draft.defaultQuantity, in: 1...999)
                TextField("Finitura (€)", value: $draft.finishingCost, format: .number)
                Section("Prezzo di vendita") {
                    LabeledContent("Costo materiale stimato", value: materialCost.euro)
                    LabeledContent("Costo stampa stimato", value: machineCost.euro)
                    LabeledContent("Prezzo suggerito", value: suggestedPrice.euro)
                    TextField("Prezzo finale (€)", value: $draft.salePrice, format: .number)
                    Button("Usa prezzo suggerito", systemImage: "eurosign.circle") { draft.salePrice = suggestedPrice }.buttonStyle(.borderedProminent)
                    Text("La stima usa peso ricavato dal volume STL, costo del filamento, tempo di stampa, finitura, margine e IVA configurati.").font(.caption).foregroundStyle(.secondary)
                }
                TextField("Note", text: $draft.notes)
                Section("Annuncio di vendita") {
                    HStack {
                        Button(listingAssistant.isGenerating ? "Generazione…" : "Genera con IA", systemImage: "sparkles") { generateListing() }
                            .buttonStyle(.borderedProminent).tint(CleanWorkshopTheme.purple).disabled(listingAssistant.isGenerating || draft.name.isEmpty)
                        if let error = listingAssistant.errorMessage {
                            Text(error).font(.caption).foregroundStyle(.red)
                            if error.localizedCaseInsensitiveContains("credito") {
                                Button("Aggiungi credito", systemImage: "creditcard.fill") { NSWorkspace.shared.open(URL(string: "https://platform.openai.com/settings/organization/billing")!) }
                            }
                        }
                    }
                    TextField("Titolo annuncio", text: Binding(get: { draft.listingTitle ?? "" }, set: { draft.listingTitle = $0 }))
                    TextEditor(text: Binding(get: { draft.listingDescription ?? "" }, set: { draft.listingDescription = $0 })).frame(height: 115)
                    HStack {
                        Button("Copia annuncio", systemImage: "doc.on.doc") { copyListing() }.disabled((draft.listingDescription ?? "").isEmpty)
                        Button("Apri Etsy", systemImage: "arrow.up.right.square") { copyListing(); NSWorkspace.shared.open(URL(string: "https://www.etsy.com/your/shops/me/listing-editor")!) }
                        Button(etsy.isWorking ? "Pubblicazione…" : "Pubblica bozza Etsy", systemImage: "paperplane.fill") { Task { _ = await etsy.publishDraft(product: draft, settings: store.settings) } }.disabled(etsy.isWorking || (draft.listingDescription ?? "").isEmpty)
                        Button("Apri Vinted", systemImage: "arrow.up.right.square") { copyListing(); NSWorkspace.shared.open(URL(string: "https://www.vinted.it/items/new")!) }
                    }
                    Text(etsy.message).font(.caption).foregroundStyle(.secondary)
                    Text("Per Vinted normale l’annuncio viene copiato e si apre la pagina ufficiale: Vinted non offre un’API pubblica per la pubblicazione automatica.").font(.caption).foregroundStyle(.secondary)
                }
            }
            HStack { if !isNew { Button("Elimina", role: .destructive) { store.products.removeAll { $0.id == draft.id }; dismiss() } }; Spacer(); Button("Annulla") { dismiss() }; Button("Salva") { save() }.buttonStyle(.borderedProminent).disabled(draft.name.isEmpty) }
        }.padding(24).frame(width: 680, height: 860)
    }
    private func save() { if let i = store.products.firstIndex(where: { $0.id == draft.id }) { store.products[i] = draft } else { store.products.append(draft) }; dismiss() }
    private func generateListing() { Task { if let result = await listingAssistant.generate(for: draft) { draft.listingTitle = result.title; draft.listingDescription = result.description } } }
    private func copyListing() { NSPasteboard.general.clearContents(); NSPasteboard.general.setString([draft.listingTitle, draft.listingDescription].compactMap { $0 }.joined(separator: "\n\n"), forType: .string) }
    private var linkedFile: ProductionFileAsset? { store.fileAssets.first { $0.id == draft.linkedFileAssetID } }
    private var selectedFilament: FilamentSpool? { store.filaments.first { $0.id == draft.filamentID } }
    private var selectedFilamentBinding: Binding<UUID?> { Binding(get:{draft.filamentID},set:{id in draft.filamentID=id;if let spool=store.filaments.first(where:{$0.id==id}){draft.material=spool.material;draft.color=spool.color;if let asset=linkedFile{applyLinkedFile(asset)}}}) }
    private var linkedFileBinding: Binding<UUID?> { Binding(get: { draft.linkedFileAssetID }, set: { id in draft.linkedFileAssetID=id;if let asset=store.fileAssets.first(where:{$0.id==id}){applyLinkedFile(asset)} }) }
    private var infillBinding: Binding<Double> { Binding(get:{draft.infillPercent ?? 20},set:{draft.infillPercent=$0;if let asset=linkedFile{applyLinkedFile(asset)}}) }
    private func applyLinkedFile(_ asset: ProductionFileAsset) {
        var resolved=asset
        if resolved.volumeCM3 == nil {
            do {
                let url=URL(fileURLWithPath:resolved.localPath)
                let analysis=try (resolved.kind == .threeMF ? STLAnalyzer.analyze3MF(url:url) : STLAnalyzer.analyze(url:url))
                resolved.volumeCM3=analysis.volumeCM3;resolved.dimensionsMM="\(analysis.dimensionsMM.x.formatted(.number.precision(.fractionLength(1)))) × \(analysis.dimensionsMM.y.formatted(.number.precision(.fractionLength(1)))) × \(analysis.dimensionsMM.z.formatted(.number.precision(.fractionLength(1)))) mm";resolved.triangleCount=analysis.triangleCount;resolved.previewPNG=analysis.previewPNG
                if let index=store.fileAssets.firstIndex(where:{$0.id==resolved.id}){store.fileAssets[index]=resolved}
            } catch { analysisMessage="Peso non disponibile: \(error.localizedDescription)";return }
        }
        guard let volume=resolved.volumeCM3, volume > 0 else { analysisMessage="Peso non disponibile: il modello non racchiude un volume valido.";return }
        let fraction=0.20+0.80*max(0,min(draft.infillPercent ?? 20,100))/100
        draft.weightGrams=volume*draft.material.densityGramsPerCM3*fraction
        draft.printHours=max(draft.weightGrams/12,0.1)
        analysisMessage="Peso ricalcolato dal volume STL: \(draft.weightGrams.formatted(.number.precision(.fractionLength(1)))) g."
    }
    private var materialCost: Double { let rate=selectedFilament?.pricePerGram ?? store.filaments.first(where:{$0.material==draft.material})?.pricePerGram ?? draft.material.pricePerGram;return draft.weightGrams*rate*Double(max(draft.defaultQuantity,1)) }
    private var machineCost: Double { draft.printHours*QuoteCalculator.machineHourlyRate*Double(max(draft.defaultQuantity,1)) }
    private var suggestedPrice: Double { let direct=materialCost+machineCost+draft.finishingCost;let margin=direct*(store.settings.profitMarginPercent ?? 30)/100;let vat=store.settings.includeVAT == false ? 0 : (direct+margin)*store.settings.vatPercent/100;return ((direct+margin+vat)*100).rounded()/100 }
}

enum PackagingAdvisor {
    static func advice(length: Double, width: Double, height: Double, weightGrams: Double, fragile: Bool) -> String {
        let maxSide = max(length, max(width, height))
        var parts: [String] = []
        if maxSide <= 20 && weightGrams < 500 { parts.append("Usa una scatola a onda singola con 2-3 cm di margine.") }
        else { parts.append("Usa una scatola a doppia onda dimensionata con 4-5 cm di margine.") }
        if fragile { parts.append("Avvolgi il pezzo con pluriball e bloccalo su tutti i lati con riempitivo antiurto.") }
        else { parts.append("Proteggi spigoli e superfici con carta alveolare o pluriball leggero.") }
        if weightGrams > 2000 { parts.append("Rinforza fondo e chiusura con nastro telato a schema H.") }
        parts.append("Esegui la prova di scuotimento: il contenuto non deve muoversi.")
        return parts.joined(separator: " ")
    }
}
