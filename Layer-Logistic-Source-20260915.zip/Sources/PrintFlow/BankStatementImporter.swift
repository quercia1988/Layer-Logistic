import Foundation

enum BankImportError: LocalizedError {
    case unreadableFile, emptyFile, unsupportedColumns
    var errorDescription: String? {
        switch self {
        case .unreadableFile: "Impossibile leggere il file selezionato."
        case .emptyFile: "Il file non contiene movimenti."
        case .unsupportedColumns: "Colonne non riconosciute: servono data, descrizione e importo."
        }
    }
}

enum BankStatementImporter {
    static func parse(url: URL, source: String = "Trade Republic") throws -> [BankTransaction] {
        guard let text = try? String(contentsOf: url, encoding: .utf8) else { throw BankImportError.unreadableFile }
        let lines = text.components(separatedBy: .newlines).filter { !$0.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
        guard let first = lines.first, lines.count > 1 else { throw BankImportError.emptyFile }
        let separator: Character = first.filter { $0 == ";" }.count > first.filter { $0 == "," }.count ? ";" : ","
        let headers = split(first, separator: separator).map(normalize)
        guard let dateIndex = index(in: headers, matching: ["date", "bookingdate", "data", "datum"]),
              let descriptionIndex = index(in: headers, matching: ["description", "descrizione", "reference", "name", "note", "type", "tipo"]),
              let amountIndex = index(in: headers, matching: ["amount", "importo", "value", "valore", "cashchange"]) else { throw BankImportError.unsupportedColumns }
        let currencyIndex = index(in: headers, matching: ["currency", "valuta", "waehrung"])
        let typeIndex = index(in: headers, matching: ["type", "tipo", "transactiontype"])
        let parsers = dateFormatters

        return lines.dropFirst().compactMap { line in
            let fields = split(line, separator: separator)
            guard fields.indices.contains(dateIndex), fields.indices.contains(descriptionIndex), fields.indices.contains(amountIndex),
                  let date = parsers.lazy.compactMap({ $0.date(from: fields[dateIndex].trimmingCharacters(in: .whitespacesAndNewlines)) }).first,
                  let amount = number(fields[amountIndex]) else { return nil }
            let description = fields[descriptionIndex].trimmingCharacters(in: .whitespacesAndNewlines)
            let type = typeIndex.flatMap { fields.indices.contains($0) ? fields[$0].lowercased() : nil } ?? ""
            let kind: BankTransactionKind = type.contains("transfer") || type.contains("trasfer") ? .transfer : amount >= 0 ? .income : .expense
            let fingerprint = "\(Int(date.timeIntervalSince1970))|\(description)|\(amount)".data(using: .utf8)!.base64EncodedString()
            return BankTransaction(sourceID: fingerprint, bookingDate: date, description: description.isEmpty ? "Movimento bancario" : description, amount: amount, currency: currencyIndex.flatMap { fields.indices.contains($0) ? fields[$0] : nil } ?? "EUR", kind: kind, source: source)
        }
    }

    private static func index(in headers: [String], matching candidates: [String]) -> Int? { headers.firstIndex { candidates.contains($0) } }
    private static func normalize(_ value: String) -> String { value.lowercased().folding(options: .diacriticInsensitive, locale: .current).filter { $0.isLetter || $0.isNumber } }
    private static func number(_ value: String) -> Double? {
        var clean = value.replacingOccurrences(of: "€", with: "").replacingOccurrences(of: " ", with: "")
        if clean.contains(",") && clean.contains(".") { clean = clean.replacingOccurrences(of: ".", with: "").replacingOccurrences(of: ",", with: ".") }
        else if clean.contains(",") { clean = clean.replacingOccurrences(of: ",", with: ".") }
        return Double(clean)
    }
    private static func split(_ line: String, separator: Character) -> [String] {
        var result: [String] = [], current = "", quoted = false
        for character in line {
            if character == "\"" { quoted.toggle() }
            else if character == separator && !quoted { result.append(current); current = "" }
            else { current.append(character) }
        }
        result.append(current)
        return result.map { $0.trimmingCharacters(in: CharacterSet(charactersIn: "\"")) }
    }
    private static var dateFormatters: [DateFormatter] {
        ["yyyy-MM-dd", "dd/MM/yyyy", "dd.MM.yyyy", "yyyy-MM-dd'T'HH:mm:ss.SSSZ"].map {
            let formatter = DateFormatter(); formatter.locale = Locale(identifier: "en_US_POSIX"); formatter.dateFormat = $0; return formatter
        }
    }
}
