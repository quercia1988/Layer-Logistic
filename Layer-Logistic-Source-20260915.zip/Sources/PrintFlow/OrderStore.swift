import Foundation
import SwiftUI

@MainActor
final class OrderStore: ObservableObject {
    @Published var customers: [Customer] = [] { didSet { save() } }
    @Published var orders: [PrintOrder] = [] { didSet { save() } }
    @Published var printers: [PrinterProfile] = [] { didSet { save() } }
    @Published var filaments: [FilamentSpool] = [] { didSet { save() } }
    @Published var settings = AppSettings() { didSet { save() } }
    @Published var extraMaterials: [ExtraMaterial] = [] { didSet { save() } }
    @Published var products: [ProductTemplate] = [] { didSet { save() } }
    @Published var expenses: [BusinessExpense] = [] { didSet { save() } }
    @Published var suppliers: [Supplier] = [] { didSet { save() } }
    @Published var purchases: [PurchaseOrder] = [] { didSet { save() } }
    @Published var supportTickets: [SupportTicket] = [] { didSet { save() } }
    @Published var returnIssues: [ReturnIssue] = [] { didSet { save() } }
    @Published var fileAssets: [ProductionFileAsset] = [] { didSet { save() } }
    @Published var bankTransactions: [BankTransaction] = [] { didSet { save() } }

    private let fileURL: URL
    private var isLoading = true

    init() {
        let directory = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("LayerLogisticEmpty", isDirectory: true)
        try? FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        fileURL = directory.appendingPathComponent("orders.json")
        load()
        isLoading = false
    }

    func customer(for order: PrintOrder) -> Customer? {
        customers.first { $0.id == order.customerID }
    }

    func add(_ order: PrintOrder) { orders.insert(order, at: 0) }
    func update(_ order: PrintOrder) {
        guard let index = orders.firstIndex(where: { $0.id == order.id }) else { return }
        let wasDelivered = orders[index].status == .delivered
        var updated = order
        if updated.shipmentStatus == .delivered { updated.status = .delivered }
        orders[index] = updated
        if !wasDelivered && updated.status == .delivered { recordWorkHours(for: updated) }
    }
    var lowStockFilaments: [FilamentSpool] { filaments.filter { $0.remainingGrams <= ($0.minimumStockGrams ?? 150) } }
    var lowStockExtras: [ExtraMaterial] { extraMaterials.filter { $0.stockQuantity <= ($0.minimumStock ?? 10) } }
    func delete(at offsets: IndexSet, from visibleOrders: [PrintOrder]) {
        let ids = Set(offsets.map { visibleOrders[$0].id })
        orders.removeAll { ids.contains($0.id) }
    }

    func updateStatus(orderID: UUID, to status: OrderStatus) {
        guard let index = orders.firstIndex(where: { $0.id == orderID }) else { return }
        let wasDelivered = orders[index].status == .delivered
        orders[index].status = status
        if !wasDelivered && status == .delivered { recordWorkHours(for: orders[index]) }
    }

    func markMaintenanceCompleted(printerID: UUID) {
        guard let index = printers.firstIndex(where: { $0.id == printerID }) else { return }
        printers[index].lastMaintenanceAtHours = printers[index].totalWorkHours ?? 0
    }

    private func recordWorkHours(for order: PrintOrder) {
        guard let printerID = order.printerID, let index = printers.firstIndex(where: { $0.id == printerID }) else { return }
        printers[index].totalWorkHours = (printers[index].totalWorkHours ?? 0) + (order.printHours ?? 0) * Double(max(order.quantity, 1))
    }

    func quote(for order: PrintOrder) -> QuoteBreakdown {
        let qty = Double(max(order.quantity, 1))
        let grams = (order.weightGrams ?? 0) * qty
        let hours = (order.printHours ?? 0) * qty
        let spool = filaments.first { $0.id == order.filamentID }
        let printer = printers.first { $0.id == order.printerID }
        let usages = order.filamentUsages ?? []
        let materialCost: Double
        if usages.isEmpty {
            materialCost = grams * (spool?.pricePerGram ?? order.material.pricePerGram)
        } else {
            materialCost = usages.reduce(0) { result, usage in
                let selected = filaments.first { $0.id == usage.filamentID }
                return result + usage.gramsPerPiece * qty * (selected?.pricePerGram ?? 0)
            }
        }
        let energyCost = (printer?.consumptionWatts ?? 0) / 1000 * hours * settings.electricityPricePerKWh
        let wearCost = (printer?.wearCostPerHour ?? 0) * hours
        let extrasCost = (order.extraUsages ?? []).reduce(0) { result, usage in
            result + usage.quantity * (extraMaterials.first { $0.id == usage.materialID }?.unitCost ?? 0)
        }
        return QuoteBreakdown(material: materialCost, energy: energyCost, wear: wearCost,
                              setup: 0, finishing: order.finishingCost ?? 0,
                              extras: extrasCost, packaging: order.packagingCost ?? 0, shipping: order.shippingCost ?? 0,
                              vatPercent: settings.includeVAT == false ? 0 : settings.vatPercent,
                              profitPercent: settings.profitMarginPercent ?? 30)
    }

    func profit(for order: PrintOrder) -> Double {
        let quote = quote(for: order)
        let vatRate = settings.includeVAT == false ? 0 : settings.vatPercent
        let netRevenue = order.price / (1 + max(vatRate, 0) / 100)
        return netRevenue - quote.directCosts
    }

    private func load() {
        if let data = try? Data(contentsOf: fileURL),
           let saved = try? JSONDecoder().decode(StoreData.self, from: data) {
            customers = saved.customers
            orders = saved.orders
            printers = saved.printers ?? Self.defaultPrinters
            if !printers.contains(where: { $0.manufacturer == "Anycubic" && $0.model == "Kobra X" }),
               let kobra = Self.defaultPrinters.first(where: { $0.manufacturer == "Anycubic" && $0.model == "Kobra X" }) {
                printers.append(kobra)
            }
            filaments = saved.filaments ?? Self.defaultFilaments
            settings = saved.settings ?? AppSettings()
            if settings.appearance == nil { settings.appearance = "light" }
            extraMaterials = saved.extraMaterials ?? Self.defaultExtraMaterials
            products = saved.products ?? Self.defaultProducts
            expenses = saved.expenses ?? []
            suppliers = saved.suppliers ?? []
            purchases = saved.purchases ?? []
            supportTickets = saved.supportTickets ?? []
            returnIssues = saved.returnIssues ?? []
            fileAssets = saved.fileAssets ?? []
            bankTransactions = saved.bankTransactions ?? []
        } else {
            seedDemoData()
        }
    }

    private func save() {
        guard !isLoading,
              let data = try? JSONEncoder().encode(StoreData(customers: customers, orders: orders, printers: printers, filaments: filaments, settings: settings, extraMaterials: extraMaterials, products: products, expenses: expenses, suppliers: suppliers, purchases: purchases, supportTickets: supportTickets, returnIssues: returnIssues, fileAssets: fileAssets, bankTransactions: bankTransactions)) else { return }
        try? data.write(to: fileURL, options: .atomic)
    }

    private func seedDemoData() {
        customers = []
        printers = []
        filaments = []
        extraMaterials = []
        products = []
        expenses = []
        suppliers = []
        purchases = []
        supportTickets = []
        returnIssues = []
        fileAssets = []
        bankTransactions = []
        orders = []
    }


    static let defaultPrinters: [PrinterProfile] = [
        PrinterProfile(manufacturer: "Bambu Lab", model: "A1", consumptionWatts: 350, wearCostPerHour: 0.55),
        PrinterProfile(manufacturer: "Bambu Lab", model: "P1S", consumptionWatts: 350, wearCostPerHour: 0.75),
        PrinterProfile(manufacturer: "Bambu Lab", model: "X1 Carbon", consumptionWatts: 350, wearCostPerHour: 1.10),
        PrinterProfile(manufacturer: "Creality", model: "Ender-3 V3", consumptionWatts: 350, wearCostPerHour: 0.35),
        PrinterProfile(manufacturer: "Creality", model: "K1 Max", consumptionWatts: 1000, wearCostPerHour: 0.85),
        PrinterProfile(manufacturer: "Prusa", model: "MK4S", consumptionWatts: 240, wearCostPerHour: 0.70),
        PrinterProfile(manufacturer: "Prusa", model: "CORE One", consumptionWatts: 240, wearCostPerHour: 0.95),
        PrinterProfile(manufacturer: "UltiMaker", model: "S5", consumptionWatts: 500, wearCostPerHour: 1.40),
        PrinterProfile(manufacturer: "Anycubic", model: "Kobra X", consumptionWatts: 475, wearCostPerHour: 0.70)
    ]

    static let defaultFilaments: [FilamentSpool] = [
        FilamentSpool(name: "PLA Nero", material: .pla, brand: "Generico", color: "Nero", initialGrams: 1000, remainingGrams: 820, purchasePrice: 22.90, minimumStockGrams: 150),
        FilamentSpool(name: "PETG Bianco", material: .petg, brand: "Generico", color: "Bianco", initialGrams: 1000, remainingGrams: 640, purchasePrice: 27.50, minimumStockGrams: 150),
        FilamentSpool(name: "Resina grigia", material: .resin, brand: "Generico", color: "Grigio", initialGrams: 1000, remainingGrams: 510, purchasePrice: 39.90, minimumStockGrams: 150)
    ]

    static let defaultExtraMaterials: [ExtraMaterial] = [
        ExtraMaterial(name: "Colla", unit: "g", stockQuantity: 500, unitCost: 0.03, minimumStock: 50),
        ExtraMaterial(name: "Calamita 6×3 mm", unit: "pz", stockQuantity: 100, unitCost: 0.22, minimumStock: 20),
        ExtraMaterial(name: "Anello portachiavi", unit: "pz", stockQuantity: 100, unitCost: 0.18, minimumStock: 20)
    ]

    static let defaultProducts: [ProductTemplate] = [
        ProductTemplate(name: "Portachiavi personalizzato", sku: "KEY-01", material: .pla, color: "A scelta", weightGrams: 18, printHours: 0.7, defaultQuantity: 1, finishingCost: 1.50, notes: "Anello portachiavi incluso"),
        ProductTemplate(name: "Supporto smartphone", sku: "PHONE-01", material: .petg, color: "Nero", weightGrams: 85, printHours: 3.2, defaultQuantity: 1, finishingCost: 2, notes: "")
    ]

}
